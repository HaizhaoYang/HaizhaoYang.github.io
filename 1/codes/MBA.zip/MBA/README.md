Multiscale Butterfly Algorithm (MBA)

Multiscale Butterfly Algorithm is a algorithm designed for fast evaluation of Fourier Integral Operators.
Both 2D and 3D code are provided.
Examples are in test folders.

References:
[1] Y. Li, H. Yang, and L. Ying. A multiscale butterfly algorithm for multidimensional Fourier integral operators. arXiv:1411.7418 [math.NA].
[2] E. Candes, L. Demanet and L. Ying. A fast butterfly algorithm for the computation of Fourier integral operators. SIAM Multiscale Modeling and Simulation 7 (2009). 
[3] Sparse Fourier transform via butterfly algorithm. SIAM Journal on Scientific Computing 31 (2009). 

Copyright @ Stanford University
