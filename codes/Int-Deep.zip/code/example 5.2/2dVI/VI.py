import math
import numpy as np
import numpy.random as npr
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import matplotlib.pyplot as plt
import scipy.io as sio
import time


torch.set_default_tensor_type('torch.DoubleTensor')

"""
define neutral network 
"""
class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(2, m)
        self.fc2 = nn.Linear(m, m)
        
        self.fc3 = nn.Linear(m, m)
        self.fc4 = nn.Linear(m, m)
        
        self.fc5 = nn.Linear(m, m)
        self.fc6 = nn.Linear(m, m)
        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc3(y)     
        y = F.relu(y**3)
        y = self.fc4(y)       
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc5(y)      
        y = F.relu(y**3)
        y = self.fc6(y)    
        y = F.relu(y**3)
        y = y+s
                
        output = self.outlayer(y)
        return output
    
"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner = npr.rand(BatchSize,d)
        self.bound = npr.rand(BatchSize,d)
        perbd = int(BatchSize/4.)
        self.bound[0:perbd,1]=0.
        self.bound[perbd:2*perbd,0]=0.
        self.bound[2*perbd:3*perbd,1]=1.
        self.bound[3*perbd:4*perbd,0]=1.
    
    def __getitem__(self, index):
        P = self.inner[index,:]
        Q = self.bound[index,:]
        return P,Q

    def __len__(self):
        return min(self.inner.shape[0],self.bound.shape[0])


"""
define function 
"""
def rightterm(P): 
    temp_f = A * ( (2.+4.*math.pi**2)*torch.sin(P[:,0]) - (1.+4.*math.pi**2)*P[:,0]*math.sin(1.) ) \
             *torch.sin(2*math.pi*P[:,1])  
    f = temp_f.reshape([P.size()[0],1])
    return f
    
def truthvalue(h): 
    points = np.arange(0, 1+h, h)
    s = len(points)
    u = np.zeros(s*s)
    for j in range(s):
        for i in range(s):            
            u[i+j*s] = A * ( np.sin(points[i]) - points[i]*math.sin(1.) ) * np.sin(2.*math.pi*points[j])
    return u
    
def numericalvalue(h):
    points = np.arange(0, 1+h, h)
    s = len(points)
    uh = np.zeros(s*s)
    P = np.zeros(2)
    for j in range(s):
        for i in range(s):
            P[0] = points[i]
            P[1] = points[j]
            x_input = torch.tensor(P)
            uh[i+j*s] = model(x_input).data
    return uh
    
def absolute_err(u,uh): 
    e = uh - u
    ab_err = np.max(abs(e))
    return ab_err


if __name__ == '__main__':   
    m = 50
    h = 2**(-7)
    d = 2
    A = 1
    beta = 500.
    g = 1. * A 
    epoch = 10000
    
    learning_rate = 1e-3
    
    BATCH_SIZE = 1024
    
    Ix = torch.zeros([2,m])
    Ix[0,0] = 1.
    Ix[1,1] = 1.
    
    model = ResNet(m)
#    model.load_state_dict(torch.load('VI_ResNet.pth'))

    u = truthvalue(h)     
    
    Loss_value = np.zeros(epoch)
    AbErr_value = np.zeros(epoch)
    error=np.zeros(100)
    cputime=np.zeros(100)
        
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999))
    
#    optimizer = optim.SGD(model.parameters(), lr=learning_rate)
#    optimizer = LS_SGD(model.parameters(), lr=0.005, sigma=0.1,betas=(0.9, 0.999))
                  
    print("VI ResNet")

    tstart=time.time()
    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),batch_size = BATCH_SIZE,
                                      shuffle=False,num_workers=1, drop_last= False)
                                      
        for step,batch_p in enumerate(data_loader): 
            batch_pin = batch_p[0]
            tem_pbd = batch_p[1]
            perbd=int(BATCH_SIZE/4.)
            batch_pbd = tem_pbd[0:3*perbd,:]
            batch_pbdc = tem_pbd[3*perbd:4*perbd,:]
            batch_pin.requires_grad = True
            batch_pbd.requires_grad = True
            batch_pbdc.requires_grad = True
            
            uin_out = model(batch_pin)
            ubd_out = model(batch_pbd)
            ubdc_out = model(batch_pbdc)
               
            v = torch.ones(uin_out.shape)
            grad = torch.autograd.grad(uin_out,batch_pin,v,create_graph=True)[0]            
            loss_in = 0.5*( grad**2 @ torch.ones([2,1]) + uin_out**2 ) - rightterm(batch_pin) * uin_out 
                        
            loss_bd = 3*beta * ubd_out**2
            
            loss_bdc = g * abs(ubdc_out)
            
            loss = loss_in.mean() + loss_bdc.mean() + loss_bd.mean()
            loss = loss.mean()
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            uh = numericalvalue(h) 
            ab_error = absolute_err(u,uh)  
            Loss_value[k] = loss.data
            AbErr_value[k] = ab_error
            
            if (k+1)% 100 == 0:
#                print(k+1,"epoch train loss: ", loss.data) 
                print(k+1,"epoch absolute error: ",ab_error)
                error[(k+1)//100 -1]=ab_error 
                
                tend=time.time()
                cputime[(k+1)//100 -1]=tend-tstart
                print(k+1,"epoch time:",cputime[(k+1)//100 -1])
           
    torch.save(model.state_dict(), 'VI_ResNet.pth')  
    
    uh = numericalvalue(h)
#    ab_error = absolute_err(u,uh)
#    print(ab_error)

    np.savetxt('VI ResNet error',error,fmt='%0.8f');
    np.savetxt('VI ResNet cputime',cputime,fmt='%0.8f');
     
    sio.savemat('VI_ResNet_loss',mdict={'loss':Loss_value})
    sio.savemat('VI_ResNet_error',mdict={'error':AbErr_value})


    sio.savemat('VI_ResNet_sol',mdict={'udr':uh})
#    sio.savemat('VI_ResNet_sol_A',mdict={'udl':uh})
    

#处理边界不如不处理边界
