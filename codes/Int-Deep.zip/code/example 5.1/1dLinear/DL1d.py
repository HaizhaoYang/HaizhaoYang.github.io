import math
import numpy as np
import numpy.random as npr
from numpy import linalg
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import matplotlib.pyplot as plt
import scipy.io as sio
import time

torch.set_default_tensor_type('torch.DoubleTensor')

"""
define neutral network 
"""

class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(1, m)
        self.fc2 = nn.Linear(m, m)
        
        self.fc3 = nn.Linear(m, m)
        self.fc4 = nn.Linear(m, m)
        
        self.fc5 = nn.Linear(m, m)
        self.fc6 = nn.Linear(m, m)
                        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc3(y)
        y = F.relu(y**3)
        y = self.fc4(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc5(y)
        y = F.relu(y**3)
        y = self.fc6(y)
        y = F.relu(y**3)
        y = y+s

        output = self.outlayer(y)
        return output
    
"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner = (npr.rand(BatchSize,d)-0.5)*2.
    
    def __getitem__(self, index):
        P = self.inner[index,:]
        return P

    def __len__(self):
        return self.inner.shape[0]

"""
define function 
"""
def rightterm(P): 
    f=w**2*(1+P**2)*torch.sin(w*P)-2*w*P*torch.cos(w*P)+P**2*torch.sin(w*P)
    f=f.cuda()
    return f
    
def truthvalue(h): 
    points = np.arange(-1, 1+h, h)
    u = A*np.sin(w*points)
    return u
    
def numericalvalue(h):
    points = np.arange(-1, 1+h, h)
    uh = np.zeros(len(points))
    for i in range(len(points)):
        x_input = np.zeros(1)
        x_input[0] = points[i]
        x_input = torch.tensor(x_input).cuda()
        uh[i] = model(x_input).data
    return uh
   

def absolute_err(u,uh): 
    e = uh - u
    ab_err = np.max(abs(e))
    return ab_err



if __name__ == '__main__':   
    m = 50
    h = 2**(-9)
    d = 1
    A = 1
    w = 1*math.pi
    beta = 500
    
    epoch = 10000
    
    learning_rate = 1e-3
    BATCH_SIZE = 512
     
    Ix = torch.zeros([1,m]).cuda()
    Ix[0,0] = 1
    
    model = ResNet(m).cuda()
    
    criterion = nn.MSELoss()    
    u = truthvalue(h)
    
    Loss_value = np.zeros(epoch)
    AbErr_value = np.zeros(epoch)
    error=np.zeros(100)

    optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999), eps=1e-8,)
    
    print("PINN ResNet")
    
    tstart=time.time()

    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),batch_size = BATCH_SIZE,
                                      shuffle=False, num_workers=1, drop_last= False)
        
        for step,batch_pin in enumerate(data_loader):
            batch_pin = batch_pin.cuda()
            batch_pin.requires_grad = True
            uin_out = model(batch_pin)
            
            v = torch.ones(uin_out.shape).cuda()
            grad = torch.autograd.grad(uin_out,batch_pin,v,create_graph=True)[0]
            px = (1+batch_pin**2)*grad
            laplace = torch.autograd.grad(px,batch_pin,v,create_graph=True)[0]

            fh = -laplace + batch_pin**2*uin_out
            f =  rightterm(batch_pin)

            a = -torch.ones(1).cuda()
            b = torch.ones(1).cuda()
            a.requires_grad = True
            b.requires_grad = True
            batch_pbd = torch.tensor([[a],[b]]).cuda()
            ubd_out = model(batch_pbd)
            
            loss = 2*criterion(fh, f) + 2*beta*criterion(ubd_out, torch.zeros(ubd_out.shape,device='cuda'))
            
            optimizer.zero_grad()
            loss.backward(retain_graph=True)
            optimizer.step() 

            uh = numericalvalue(h)
            ab_error = absolute_err(u,uh)
            Loss_value[k] = loss.data
            AbErr_value[k] = ab_error

            if (k+1)% 100 == 0:
                #uh = numericalvalue(h)
                #ab_error = absolute_err(u,uh)
                print(k+1,"epoch train loss: ", loss.data)
                print(k+1,"epoch absolute error: ",ab_error)
                error[(k+1)//100 -1]=ab_error

    torch.save(model.state_dict(), '1d_nonlinear_PI_ResNet_hybrid.pth')
    tend=time.time()
    print("PINN time",tend-tstart)
    
    np.savetxt('1d linear DL ResNet error',np.array([error]),fmt='%0.8f');
    np.savetxt('1d linear DL ResNet gputime',np.array([gputime]),fmt='%0.8f');
    
    sio.savemat('DL_ResNet_loss',mdict={'loss':Loss_value})
    sio.savemat('DL_ResNet_AbError',mdict={'AbErr':AbErr_value})
    
    uh = numericalvalue(h)
    error = absolute_err(u,uh)
    print(error)

    sio.savemat('non_PI_sol',mdict={'udl':uh})
