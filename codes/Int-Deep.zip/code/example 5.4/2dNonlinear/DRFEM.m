function [udf,error] = DRFEM(ne,a,b,c,d,u0)
ca=-1;
cc=-1;

u=truth(ne,a,b);
E=zeros(15,1);

[p,e,t]=femmesh(ne,a,b,c,d);

gne=size(t,2);
nnpe=size(t,1);
nn=(ne+1)*(ne+1);
dofpn=1;
sdof=nn*dofpn;

elm=femelm_P1(p,t,gne,nnpe,1);
LM=femMatrix(t,elm,gne,sdof,nnpe);
LM=fembcM_D(LM,e);

tic

ek=femek_P1(p,t,gne,nnpe,ca);
K=femMatrix(t,ek,gne,sdof,nnpe);
K=fembcM_D(K,e);

index=e(1,:)';
u0(index,1)=0;

o=1;
error = MaxError(u0,u);
E(o,1) = 1;
%disp(o-1);
disp(error);

% L2error = MatrixError(u0,u,LM);
% disp(L2error);

err=E(o,1);
eps=0.01*((b-a)/ne)*((d-c)/ne);

while err > eps && o<=15
    em=femem_P1(p,t,gne,nnpe,cc,u0);
    M=femMatrix(t,em,gne,sdof,nnpe);
    M=fembcM_D(M,e);
    KM=K+M;
    ef=femef_P1(p,t,gne,nnpe,cc,u0);
    F0=femVector(t,ef,gne,sdof,nnpe);
    F=F0-K*u0;
    F=fembcV_D(F,e);
    v1=KM\F;
    u1=u0+v1;
 
%    err=MaxError(u1,u0)/max(abs(u0));
%    error=MatrixError(u1,u,LM);
    error=MaxError(u1,u);
    err=MatrixError(u1,u0,LM)/sqrt(u0'*LM*u0);
    
    u0=u1;
    o=o+1;
    E(o,1)=error;  
end
udf=u0;
toc

error=E(o,1);
disp(o-1);
disp(error);
%disp(E);

% L2error = MatrixError(udf,u,LM);
% disp(L2error)
end

