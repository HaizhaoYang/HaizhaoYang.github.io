function [u] = truth(ne,a,b)
h=(b-a)/ne;
x=(a:h:b)';
s=size(x,1);
u=zeros(s*s,1);
w=2*pi;
A=3;
for j=1:1:s
    for i=1:1:s
        u(i+(j-1)*s,1)=A*sin(w*x(i))*sin(w*x(j));
    end
end
end
