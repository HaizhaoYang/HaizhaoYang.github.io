function [Err] = test()

% load('PI_DL_4.mat')
% load('PI_DL_5.mat')
% load('PI_DL_6.mat')
% load('PI_DL_7.mat')
% load('PI_DL_8.mat')

load('dr_w3_4.mat');
load('dr_w3_5.mat');
load('dr_w3_6.mat');
load('dr_w3_7.mat');
load('dr_w3_8.mat');


n=(4:1:8);
N=2.^n;
s=size(N,2);
Err=zeros(s,1);


% [udf1,Err(1)] = DRFEM(N(1),0,1,0,1,udl4');
% [udf2,Err(2)] = DRFEM(N(2),0,1,0,1,udl5');
% [udf3,Err(3)] = DRFEM(N(3),0,1,0,1,udl6');
% [udf4,Err(4)] = DRFEM(N(4),0,1,0,1,udl7');
% [udf5,Err(5)] = DRFEM(N(5),0,1,0,1,udl8');


[udf1,Err(1)] = DRFEM(N(1),0,1,0,1,udr4');
[udf2,Err(2)] = DRFEM(N(2),0,1,0,1,udr5');
[udf3,Err(3)] = DRFEM(N(3),0,1,0,1,udr6');
[udf4,Err(4)] = DRFEM(N(4),0,1,0,1,udr7');
[udf5,Err(5)] = DRFEM(N(5),0,1,0,1,udr8');


end

