function [ F ] = femVector(t,ef,gne,sdof,nnpe)
F=zeros(sdof,1);
for i=1:1:gne
    index=t(:,i);
    F(index,1)=F(index,1)+ef(nnpe*(i-1)+1:nnpe*(i-1)+nnpe,1);
end
end