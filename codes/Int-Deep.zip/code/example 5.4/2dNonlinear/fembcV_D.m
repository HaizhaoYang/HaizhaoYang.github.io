function [F] = fembcV_D(F,e)
s=size(e,2);
for i=1:1:s
    index=e(1,i);
    F(index,1)=0;
end
end
