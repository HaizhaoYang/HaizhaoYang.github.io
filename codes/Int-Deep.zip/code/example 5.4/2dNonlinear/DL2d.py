import math
import numpy as np
import numpy.random as npr
from numpy import linalg
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import matplotlib.pyplot as plt
import scipy.io as sio
import time

torch.set_default_tensor_type('torch.DoubleTensor')
torch.manual_seed(2)
"""
define neutral network 
"""

class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(2, m)
        self.fc2 = nn.Linear(m, m)
        
        self.fc3 = nn.Linear(m, m)
        self.fc4 = nn.Linear(m, m)
        
        self.fc5 = nn.Linear(m, m)
        self.fc6 = nn.Linear(m, m)
        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc3(y)
        y = F.relu(y**3)
        y = self.fc4(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc5(y)
        y = F.relu(y**3)
        y = self.fc6(y)
        y = F.relu(y**3)
        y = y+s
        
        output = self.outlayer(y)
        return output
    

"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner = npr.rand(BatchSize,d)
        self.bound = npr.rand(BatchSize,d)
        perbd = int(BatchSize/4)
        self.bound[0:perbd,1]=0.
        self.bound[perbd:2*perbd,0]=1.
        self.bound[2*perbd:3*perbd,1]=1.
        self.bound[3*perbd:4*perbd,0]=0.
    
    def __getitem__(self, index):
        P = self.inner[index,:]
        Q = self.bound[index,:]
        return P,Q

    def __len__(self):
        return min(self.inner.shape[0],self.bound.shape[0])


"""
define function 
"""
def rightterm(P): 
    temp_f = A*2*w**2*torch.sin(w*P[:,0])*torch.sin(w*P[:,1])\
        -(A*torch.sin(w*P[:,0])*torch.sin(w*P[:,1])-1)**3+(A*torch.sin(w*P[:,0])*torch.sin(w*P[:,1])+2)**2
    f = temp_f.reshape([P.size()[0],1])
    f = f.cuda()
    return f
    
def truthvalue(h): 
    points = np.arange(0, 1+h, h)
    s = len(points)
    u = np.zeros(s*s)
    for j in range(s):
        for i in range(s):
            u[i+j*s] =A*np.sin(w*points[i])*np.sin(w*points[j])
    return u
    
def numericalvalue(h):
    points = np.arange(0, 1+h, h)
    s = len(points)
    uh = np.zeros(s*s)
    P = np.zeros(2)
    for j in range(s):
        for i in range(s):
            P[0] = points[i]
            P[1] = points[j]
            x_input = torch.tensor(P).cuda()
            uh[i+j*s] =  model(x_input).data
    return uh
    
def absolute_err(u,uh): 
    e = uh - u
    ab_err = np.max(abs(e))
    return ab_err

    
if __name__ == '__main__':   
    m = 50
    h = 2**(-7)
    d = 2
    w = 2*math.pi
    A = 3
            
    epoch = 400
    
    BATCH_SIZE = 1024
    
    Ix = torch.zeros([2,m]).cuda()
    Ix[0,0] = 1
    Ix[1,1] = 1
    
    model = ResNet(m).cuda()
    
    u = truthvalue(h)     
    
    criterion = nn.MSELoss()    
    optimizer = optim.Adam(model.parameters(), lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0)
    
    print("2d PI ResNet 6 50")
    
    tstart=time.time()
    
    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),
                                      batch_size = BATCH_SIZE,shuffle=False,
                                      num_workers=1, drop_last= False)
                                      
        for step,batch_p in enumerate(data_loader): 
            pin = batch_p[0].cuda()
            batch_pbd = batch_p[1].cuda()
            
            tx = pin[:,0]
            x = tx.reshape([tx.size()[0],1])
            ty = pin[:,1]
            y = ty.reshape([ty.size()[0],1])
            x.requires_grad = True
            y.requires_grad = True
            batch_pin = torch.cat((x,y),1).cuda()
            
            uin_out = model(batch_pin)
            ubd_out = model(batch_pbd)
               
            v = torch.ones(uin_out.shape).cuda()
            ux = torch.autograd.grad(uin_out,x,grad_outputs=v,create_graph=True)[0]
            uxx = torch.autograd.grad(ux,x,grad_outputs=v,create_graph=True)[0]
            uy = torch.autograd.grad(uin_out,y,grad_outputs=v,create_graph=True)[0]
            uyy = torch.autograd.grad(uy,y,grad_outputs=v,create_graph=True)[0]
            
            fh = - (uxx + uyy) - (uin_out-1)**3 +(uin_out+2)**2
            f = rightterm(batch_pin) 
            
            loss = criterion(fh, f) + 4*500*criterion(ubd_out, torch.zeros(ubd_out.shape,device='cuda'))

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()


    
    torch.save(model.state_dict(), '2d_nonlinear_PI_ResNet_6_50.pth')
    tend=time.time()
    print("deep learning time",tend-tstart)
        
    uh = numericalvalue(h)
    ab_error = absolute_err(u,uh)
    print(ab_error)

    sio.savemat('non_PI_6_50',mdict={'udl':uh})

