function [ ek ] = femek_P1(p,t,gne,nnpe,ca)
ek=zeros(nnpe*gne,nnpe);
for i=1:1:gne
    in1=t(1,i);
    in2=t(2,i);
    in3=t(3,i);
    x1=p(in1,1);
    x2=p(in2,1);
    x3=p(in3,1);
    y1=p(in1,2);
    y2=p(in2,2);
    y3=p(in3,2);
    S=det([1 x1 y1;1 x2 y2;1 x3 y3])/2;
    k11=((x3-x2)^2+(y2-y3)^2)/(4*S);
    k12=((x3-x2)*(x1-x3)+(y2-y3)*(y3-y1))/(4*S);
    k13=((x3-x2)*(x2-x1)+(y2-y3)*(y1-y2))/(4*S);
    k21=k12;
    k22=((x1-x3)^2+(y3-y1)^2)/(4*S);
    k23=((x1-x3)*(x2-x1)+(y3-y1)*(y1-y2))/(4*S);
    k31=k13;
    k32=k23;
    k33=((x2-x1)^2+(y2-y1)^2)/(4*S);
    eka=[k11,k12,k13;k21,k22,k23;k31,k32,k33]*(-ca);
    iesi=nnpe*(i-1);
    ek(iesi+1:nnpe*i,1:nnpe)=eka;
end
end