function [ ef ] = femef_P1(p,t,gne,nnpe,ncc,u0)
ef=zeros(nnpe*gne,1);
w=2*pi;
A=3;
for i=1:1:gne
    in1=t(1,i);
    in2=t(2,i);
    in3=t(3,i);
    x1=p(in1,1);
    x2=p(in2,1);
    x3=p(in3,1);
    y1=p(in1,2);
    y2=p(in2,2);
    y3=p(in3,2);
    u1=u0(in1);
    u2=u0(in2);
    u3=u0(in3);
        
    x12=(x1+x2)/2;
    x13=(x1+x3)/2;
    x23=(x2+x3)/2;
    y12=(y1+y2)/2;
    y13=(y1+y3)/2;
    y23=(y2+y3)/2;
    u12=(u1+u2)/2;
    u13=(u1+u3)/2;
    u23=(u2+u3)/2;
    
    S=det([1 x1 y1;1 x2 y2;1 x3 y3])/2;

    p12=-ncc*2*A*w^2*sin(w*x12)*sin(w*y12)-(A*sin(w*x12)*sin(w*y12)-1)^3+(A*sin(w*x12)*sin(w*y12)+2)^2;
    p13=-ncc*2*A*w^2*sin(w*x13)*sin(w*y13)-(A*sin(w*x13)*sin(w*y13)-1)^3+(A*sin(w*x13)*sin(w*y13)+2)^2;
    p23=-ncc*2*A*w^2*sin(w*x23)*sin(w*y23)-(A*sin(w*x23)*sin(w*y23)-1)^3+(A*sin(w*x23)*sin(w*y23)+2)^2;
    
    iesi=nnpe*(i-1);

    ef(iesi+1,1)=((p12-ncc*((u12-1)^3-(u12+2)^2))*1/2+(p13-ncc*((u13-1)^3-(u13+2)^2))*1/2)*S/3;
    ef(iesi+2,1)=((p12-ncc*((u12-1)^3-(u12+2)^2))*1/2+(p23-ncc*((u23-1)^3-(u23+2)^2))*1/2)*S/3;
    ef(iesi+3,1)=((p23-ncc*((u23-1)^3-(u23+2)^2))*1/2+(p13-ncc*((u13-1)^3-(u13+2)^2))*1/2)*S/3;
end
end

