function [error] = MatrixError(u,uh,A)
err=u-uh;
error=sqrt(err'*A*err);

end

