function [ error ] = MaxError( uh,u )
error=u-uh;
error=max(abs(error));

end