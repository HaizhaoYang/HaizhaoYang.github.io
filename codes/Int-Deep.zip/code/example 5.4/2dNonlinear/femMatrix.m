function [ A ] = femMatrix(t,ea,gne,sdof,nnpe)
A=sparse(sdof,sdof);
for i=1:1:gne
    index=t(:,i);
    A(index,index)=A(index,index)+ea(nnpe*(i-1)+1:nnpe*(i-1)+nnpe,:);
end
end