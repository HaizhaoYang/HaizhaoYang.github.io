function [p,e,t] = femmesh( ne,a,b,c,d )
g=[2 2 2 2;a b b a;b b a a;c c d d;c d d c;1 1 1 1;0 0 0 0];
[p,e,t]=poimesh(g,ne,ne);
p=p';
e=e(1:2,:);
t=t(1:3,:);
end

