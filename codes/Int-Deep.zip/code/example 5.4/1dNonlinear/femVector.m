function [ F ] = femVector( ef,ne,sdof,nnpe )
F=zeros(sdof,1);
for i=1:1:ne
    iesis=(i-1);
    for j=1:1:nnpe
        F(iesis+j,1)=F(iesis+j,1)+ef(nnpe*(i-1)+j,1);
    end
end

