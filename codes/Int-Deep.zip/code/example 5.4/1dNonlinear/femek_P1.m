function [ ek ] = femek_P1(nodcoor,ean,ne,nnpe,ca)
ek=zeros(nnpe*ne,nnpe);
for i=1:1:ne
    nl=ean(i,1);
    nr=ean(i,2);
    len=nodcoor(nr)-nodcoor(nl);
    eka=[1,-1;-1,1]*(-ca/len);
    iesi=nnpe*(i-1);
    ek(iesi+1:nnpe*i,1:nnpe)=eka;
end
end

