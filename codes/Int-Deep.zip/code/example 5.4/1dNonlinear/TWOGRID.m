function [uh,err] = TWOGRID(NE,ne,a,b,u0)
ca=-1;
cc=0;
ncc=-1;

nnpe=2;
NN=(nnpe-1)*NE+1;
nn=(nnpe-1)*ne+1;
dofpn=1;
SDOF=NN*dofpn;
sdof=nn*dofpn;

[NODCOOR,EAN]=femmesh(NE,NN,a,b,nnpe);
[nodcoor,ean]=femmesh(ne,nn,a,b,nnpe);

tru_uH=truth(NE,a,b);
tru_uh=truth(ne,a,b);


% step 1
ekH=femek_P1(NODCOOR,EAN,NE,nnpe,ca);
KH=femMatrix(ekH,NE,SDOF,nnpe);
KH=fembcM_D(KH,SDOF);

elmH=femelm_P1(NODCOOR,EAN,NE,nnpe,1);
LMH=femMatrix(elmH,NE,SDOF,nnpe);
LMH=fembcM_D(LMH,SDOF);

intdof=size(u0,1);
u0(1,1)=0;
u0(intdof,1)=0;
error=MaxError(u0,tru_uH);
disp(error);

o=1;
e=1;
eps=0.01*((b-a)/NE)^2;
while o<=10 && e > eps 
    emH=femem_P1(NODCOOR,EAN,NE,nnpe,ncc,u0);
    MH=femMatrix(emH,NE,SDOF,nnpe);
    MH=fembcM_D(MH,SDOF);
    KMH=KH+MH;
    
    efH=femef_P1(NODCOOR,EAN,NE,nnpe,ca,cc,ncc,u0);
    F0H=femVector(efH,NE,SDOF,nnpe);
    FH=F0H-KH*u0;
    FH=fembcV_D(FH,SDOF);
    
    v1=KMH\FH;
    u1=u0+v1;
%    e=MaxError(u1,u0)/max(abs(u0));
%    error=MatrixError(u1,u,LMH);
    error=MaxError(u1,tru_uH);
    e=MatrixError(u1,u0,LMH)/sqrt(u0'*LMH*u0); 
    u0=u1;
    o=o+1;
end
uH=u0;
disp(o-1);
disp(error);


%step 2
ekh=femek_P1(nodcoor,ean,ne,nnpe,ca);
Kh=femMatrix(ekh,ne,sdof,nnpe);
Kh=fembcM_D(Kh,sdof);

% elmh=femelm_P1(nodcoor,ean,ne,nnpe,1);
% LMh=femMatrix(elmh,ne,sdof,nnpe);
% LMh=fembcM_D(LMh,sdof);

uHf=fine(NODCOOR,EAN,nodcoor,ean,NE,ne,sdof,SDOF,uH);

emh=femem_P1(nodcoor,ean,ne,nnpe,ncc,uHf);
Mh=femMatrix(emh,ne,sdof,nnpe);
Mh=fembcM_D(Mh,sdof);

KMh=Kh+Mh;

efh=femef_P1(nodcoor,ean,ne,nnpe,ca,cc,ncc,uHf);
F0h=femVector(efh,ne,sdof,nnpe);
Fh=F0h-Kh*uHf;
Fh=fembcV_D(Fh,sdof);

eh=KMh\Fh;
error=MaxError(uHf+eh,tru_uh); 
disp(error);


%step 3
ehc=coarse(NE,ne,sdof,SDOF,eh);

emH=femem_P1(NODCOOR,EAN,NE,nnpe,ncc,uH);
MH=femMatrix(emH,NE,SDOF,nnpe);
MH=fembcM_D(MH,SDOF);

KMH=KH+MH;

enfH=femenf_P1(NODCOOR,EAN,NE,nnpe,ncc,uH,ehc);
FnH=femVector(enfH,NE,SDOF,nnpe);
FnH=fembcV_D(FnH,SDOF);

eH=KMH\FnH;
eHf=fine(NODCOOR,EAN,nodcoor,ean,NE,ne,sdof,SDOF,eH);

uh=uHf+eh+eHf;
error=MaxError(uh,tru_uh); 
disp(error);
err=error;
end

