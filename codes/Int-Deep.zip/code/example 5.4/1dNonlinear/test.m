function [Err] = test()
n=(7:1:14);
N=2.^n;
Err=zeros(size(n,2),1);

load('UDL7.mat');
load('UDL8.mat');
load('UDL9.mat');
load('UDL10.mat');
load('UDL11.mat');
load('UDL12.mat');
load('UDL13.mat');
load('UDL14.mat');

[udf1,Err(1)] = DRFEM(N(1),0,1,udl7');
[udf2,Err(2)] = DRFEM(N(2),0,1,udl8');
[udf3,Err(3)] = DRFEM(N(3),0,1,udl9');
[udf4,Err(4)] = DRFEM(N(4),0,1,udl10');
[udf5,Err(5)] = DRFEM(N(5),0,1,udl11');
[udf6,Err(6)] = DRFEM(N(6),0,1,udl12');
[udf7,Err(7)] = DRFEM(N(7),0,1,udl13');
[udf7,Err(8)] = DRFEM(N(8),0,1,udl14');

end

