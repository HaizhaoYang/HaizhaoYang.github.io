function [ ef ] = femenf_P1( nodcoor,ean,ne,nnpe,ncc,uH,eh)
ef=zeros(nnpe*ne,1);

for i=1:1:ne    
    nl=ean(i,1);
    nr=ean(i,2);
    xl=nodcoor(nl);
    xr=nodcoor(nr);
    ul=uH(nl);
    ur=uH(nr);
    el=eh(nl);
    er=eh(nr);
    len=xr-xl;
    iesi=nnpe*(i-1);
        
    fl=3/2*len*(ul-1)*el^2-1/2*len*el^2;
    fr=3/2*len*(ur-1)*er^2-1/2*len*er^2;
    
    ef(iesi+1,1)=-ncc*fl;
    ef(nnpe*i,1)=-ncc*fr;
end
end

