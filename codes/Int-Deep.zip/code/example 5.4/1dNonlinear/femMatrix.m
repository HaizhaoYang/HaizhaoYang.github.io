% iesis i-th element start index in system 

function [ K ] = femMatrix( ek,ne,sdof,nnpe )
K=zeros(sdof,sdof);
for i=1:1:ne
    iesis=(i-1);
    for j=1:1:nnpe
        K(iesis+j,iesis+1:iesis+nnpe)=K(iesis+j,iesis+1:iesis+nnpe)+ek(nnpe*(i-1)+j,1:nnpe);
    end
end
end

