function [udf,err] = DRFEM(ne,a,b,u0)
ca=-1;
cc=0;
ncc=-1;

u=truth(ne,a,b);
Err=zeros(10,1);

nnpe=2;
nn=(nnpe-1)*ne+1;
dofpn=1;
sdof=nn*dofpn;

[nodcoor,ean]=femmesh(ne,nn,a,b,nnpe);

ek=femek_P1(nodcoor,ean,ne,nnpe,ca);
K=femMatrix(ek,ne,sdof,nnpe);
K=fembcM_D(K,sdof);

elm=femelm_P1(nodcoor,ean,ne,nnpe,1);
LM=femMatrix(elm,ne,sdof,nnpe);
LM=fembcM_D(LM,sdof);

tic

dldof=size(u0,1);
u0(1,1)=0;
u0(dldof,1)=0;

o=1;
error=MaxError(u0,u);
%error=MatrixError(u0,u,K+LM);

Err(o,1)=error;
%disp(o-1);
disp(error);

e=1;
eps=0.01*(b-a)/ne^2;

while o<=15 && e > eps 
    em=femem_P1(nodcoor,ean,ne,nnpe,ncc,u0);
    M=femMatrix(em,ne,sdof,nnpe);
    M=fembcM_D(M,sdof);
    KM=K+M;
    ef=femef_P1(nodcoor,ean,ne,nnpe,ca,cc,ncc,u0);
    F0=femVector(ef,ne,sdof,nnpe);
    F=F0-K*u0;
    F=fembcV_D(F,sdof);
    v1=KM\F;
    u1=u0+v1;
    
%    e=MaxError(u1,u0)/max(abs(u0));
%    error=MatrixError(u1,u,KM);
    error=MaxError(u1,u);
    e=MatrixError(u1,u0,LM)/sqrt(u0'*LM*u0);
    
    u0=u1;
    o=o+1;
    Err(o,1)=error;
%     disp(o-1);
%     disp(error);
end
udf=u0;

toc

err=Err(o,1);
disp(o-1);
disp(err);
% disp(Err);
end

