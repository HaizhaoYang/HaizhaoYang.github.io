function [ uh ] = fine(NODCOOR,EAN,nodcoor,ean,NE,ne,sdof,SDOF,UH)
Ene=ne/NE;
uh=zeros(sdof,1);
for i=1:1:NE
    NL=EAN(i,1);
    NR=EAN(i,2);
    XL=NODCOOR(NL);
    XR=NODCOOR(NR);
    H=XR-XL;
    for j=1:1:Ene
        n=ean((i-1)*Ene+j,1);
        x=nodcoor(n);
        uh((i-1)*Ene+j,1)=UH(i,1)*(XR-x)/H+UH(i+1,1)*(x-XL)/H;
    end
end
uh(sdof,1)=UH(SDOF,1);
        
end