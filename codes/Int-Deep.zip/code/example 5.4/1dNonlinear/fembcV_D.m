function [ F ] = fembcV_D( F,sdof )
F(1,1)=0;
F(sdof,1)=0;
end

