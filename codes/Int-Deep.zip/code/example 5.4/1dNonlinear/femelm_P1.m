function [ elm ] = femelm_P1(nodcoor,ean,ne,nnpe,cc)
elm=zeros(nnpe*ne,nnpe);
for i=1:1:ne
    nl=ean(i,1);
    nr=ean(i,2);
    plen=nodcoor(nr)-nodcoor(nl);
    ema=[2,1;1,2]*(cc*plen)/6;
    iesi=nnpe*(i-1);
    elm(iesi+1:nnpe*i,1:nnpe)=ema;
end
end

