% iesn: i-th element start node;
% len: length of element
% plen: part of element length

function [ nodcoor, ean] = femmesh( ne,nn,a,b,nnpe )
nodcoor = zeros(nn,1);
len=(b-a)/ne;
for i=1:1:nn
    nodcoor(i,1)=a+len*(i-1);
end
ean=zeros(ne,nnpe);
for i=1:1:ne
    iesn=(i-1);
    for j=1:1:nnpe
        ean(i,j)=iesn+j;
    end
end

