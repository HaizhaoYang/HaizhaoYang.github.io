function [uf,error] =Picard(ne,a,b)
ca=-1;
u=truth(ne,a,b);

nnpe=2;
nn=(nnpe-1)*ne+1;
dofpn=1;
sdof=nn*dofpn;

o=0;
u0=randn(sdof,1);
%u0=ones(sdof,1);
%u0=zeros(sdof,1);
%u0=u+randn(sdof,1);

error=MaxError(u0,u);
disp(error);
e=1;
eps=0.01*(b-a)/ne^2;

[nodcoor,ean]=femmesh(ne,nn,a,b,nnpe);
ek=femek_P1(nodcoor,ean,ne,nnpe,ca);
K=femMatrix(ek,ne,sdof,nnpe);
K=fembcM_D(K,sdof);

elm=femelm_P1(nodcoor,ean,ne,nnpe,1);
LM=femMatrix(elm,ne,sdof,nnpe);
LM=fembcM_D(LM,sdof);

while e>eps && o<15
    ef=femef_P1(nodcoor,ean,ne,nnpe,-1,0,-1,u0);
    F=femVector(ef,ne,sdof,nnpe);
    K=fembcM_D(K,sdof);
    F=fembcV_D(F,sdof);
    u1=K\F;
    e=MatrixError(u1,u0,LM)/sqrt(u0'*LM*u0);
    error=MaxError(u1,u);
    %disp(o+1)
    %disp(error);
    u0=u1;
    o=o+1;
end
uf=u0;

disp(o);
error = MaxError(uf,u);
disp(error);
end

