import math
import numpy as np
import numpy.random as npr
from numpy import linalg
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import matplotlib.pyplot as plt
import scipy.io as sio
import time


torch.set_default_tensor_type('torch.DoubleTensor')
torch.manual_seed(2)

"""
define neutral network 
"""

class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(1, m)
        self.fc2 = nn.Linear(m, m)
        
        self.fc3 = nn.Linear(m, m)
        self.fc4 = nn.Linear(m, m)
        
        self.fc5 = nn.Linear(m, m)
        self.fc6 = nn.Linear(m, m)
                        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc3(y)
        y = F.relu(y**3)
        y = self.fc4(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc5(y)
        y = F.relu(y**3)
        y = self.fc6(y)
        y = F.relu(y**3)
        y = y+s

        output = self.outlayer(y)
        return output
    
"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner = npr.rand(BatchSize,d)
    
    def __getitem__(self, index): 
        P = self.inner[index,:]
        return P
               
    def __len__(self):
        return self.inner.shape[0]

"""
define function 
"""
def rightterm(P): 
    f=A*w**2*torch.sin(w*P) - (A*torch.sin(w*P)-1)**3 + (A*torch.sin(w*P)+2)**2
    f=f.cuda()
    return f
    
def truthvalue(h): 
    points = np.arange(0, 1+h, h)
    u = A*np.sin(w*points)
    return u
    
def numericalvalue(h):
    points = np.arange(0, 1+h, h)
    uh = np.zeros(len(points))
    for i in range(len(points)):
        x_input = np.zeros(1)
        x_input[0] = points[i]
        x_input = torch.tensor(x_input).cuda()
        uh[i] = model(x_input).data
    return uh
   

def absolute_err(u,uh): 
    e = uh - u
    ab_err = np.max(abs(e))
    return ab_err



if __name__ == '__main__':   
    m = 50
    h = 2**(-10)
    d = 1
    A = 3
    w = 2*math.pi
    beta=500
    
    epoch = 400
    
    learning_rate = 1e-3
    BATCH_SIZE = 512
     
    Ix = torch.zeros([1,m]).cuda()
    Ix[0,0] = 1
    
    model = ResNet(m).cuda()
    criterion = nn.MSELoss()    
    u = truthvalue(h)

    optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999), eps=1e-8,)
    
    print("PINN ResNet 6 50")
    
    tstart=time.time()

    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),batch_size = BATCH_SIZE,
                                      shuffle=False, num_workers=1, drop_last= False)
        
        for step,batch_pin in enumerate(data_loader):
            batch_pin = batch_pin.cuda()
            batch_pin.requires_grad = True
            uin_out = model(batch_pin) 

            v = torch.ones(uin_out.shape).cuda()
            grad = torch.autograd.grad(uin_out,batch_pin,v,create_graph=True)[0] 
            laplace = torch.autograd.grad(grad,batch_pin,v,create_graph=True)[0]

            fh = -laplace - (uin_out-1)**3 + (uin_out+2)**2
            f =  rightterm(batch_pin)

            a = torch.zeros(1).cuda()
            b = torch.ones(1).cuda()
            a.requires_grad = True
            b.requires_grad = True
            batch_pbd = torch.tensor([[a],[b]]).cuda()
            ubd_out = model(batch_pbd)
            
            loss = criterion(fh, f) + 2*beta*criterion(ubd_out, torch.zeros(ubd_out.shape,device='cuda'))
            
            optimizer.zero_grad()
            loss.backward(retain_graph=True)
            optimizer.step() 

#    torch.save(model.state_dict(), '1d_nonlinear_PI_ResNet_hybrid.pth')   
#    torch.save(model.state_dict(), '1d_nonlinear_PI_ResNet_6_50.pth')
    tend=time.time()
    print("PINN time",tend-tstart)
                
    uh = numericalvalue(h)
    error = absolute_err(u,uh)
    print(error)

#    plt.plot(uh)
#    plt.show() 
    
#    sio.savemat('non_PI_sol',mdict={'udl':uh})
#    sio.savemat('UDL14',mdict={'udl14':uh})
#    sio.savemat('non_udl_6_50',mdict={'udl':uh})
