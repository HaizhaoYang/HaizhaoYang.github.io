function [ UH ] = coarse(NE,ne,sdof,SDOF,uh)
Ene=ne/NE;
UH=zeros(SDOF,1);
for i=1:1:NE
    UH(i,1)=uh((i-1)*Ene+1,1);
end
UH(SDOF,1)=uh(sdof,1);
        
end