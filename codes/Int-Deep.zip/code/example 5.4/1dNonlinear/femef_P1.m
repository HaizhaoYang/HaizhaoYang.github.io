function [ ef ] = femef_P1( nodcoor,ean,ne,nnpe,ca,cc,ncc,u0 )
ef=zeros(nnpe*ne,1);

A=3;
w=2*pi;

for i=1:1:ne    
    nl=ean(i,1);
    nr=ean(i,2);
    xl=nodcoor(nl);
    xr=nodcoor(nr);
    ul=u0(nl);
    ur=u0(nr);
    len=xr-xl;
    iesi=nnpe*(i-1);
        
    u0l=len*(ul-1)^3/2-len*(ul+2)^2/2;
    u0r=len*(ur-1)^3/2-len*(ur+2)^2/2;
    
    ef(iesi+1,1)=len*(-ca*A*w^2*sin(w*xl) + ncc*((A*sin(w*xl)-1)^3 - (A*sin(w*xl)+2).^2 ))/2 - ncc*u0l;
    ef(nnpe*i,1)=len*(-ca*A*w^2*sin(w*xr) + ncc*((A*sin(w*xr)-1)^3 - (A*sin(w*xr)+2).^2 ))/2 - ncc*u0r;
end
end

