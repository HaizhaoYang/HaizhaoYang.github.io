function [ em ] = femem_P1(nodcoor,ean,ne,nnpe,ncc,u0)
em=zeros(nnpe*ne,nnpe);
for i=1:1:ne
    nl=ean(i,1);
    nr=ean(i,2);
    xl=nodcoor(nl);
    xr=nodcoor(nr);
    ul=u0(nl);
    ur=u0(nr);
    len=xr-xl;
    emc=zeros(2,2);    
 
    emc(1,1)=3*(ul-1)^2*len/2-2*(ul+2)*len/2;
    emc(1,2)=0;
    emc(2,1)=0;
    emc(2,2)=3*(ur-1)^2*len/2-2*(ur+2)*len/2;
    
    emc=emc*ncc;
    iesi=nnpe*(i-1);
    em(iesi+1:nnpe*i,1:nnpe)=emc;
end
end

