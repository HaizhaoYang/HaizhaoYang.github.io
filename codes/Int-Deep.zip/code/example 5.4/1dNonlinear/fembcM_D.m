function [A] = fembcM_D( A,sdof )
for j=1:1:sdof
    A(1,j)=0;
    A(sdof,j)=0;
end
A(1,1)=1;
A(sdof,sdof)=1;
end

