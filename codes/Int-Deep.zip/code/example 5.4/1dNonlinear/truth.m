function [u] = truth(ne,a,b)
h=(b-a)/ne;
x=(a:h:b)';

A=3;
w=2*pi;

u=A*sin(w*x);

end


