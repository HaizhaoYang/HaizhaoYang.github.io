function [Order] = order(Error)
s=size(Error,1);
Order=zeros(s-1,1);
for i=1:1:s-1
    Order(i,1)=Error(i+1,1)/Error(i,1);
end
Order=-log(Order)/log(2);
end

