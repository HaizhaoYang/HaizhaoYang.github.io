function [u] = funcnormlize(u)
syms x;
f=@(x) sin(pi.*(x-1)).^2;
norm=quadgk(f,0,1);
u=u/sqrt(norm);
end

