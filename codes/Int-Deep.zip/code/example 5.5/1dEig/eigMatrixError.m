function [errlam,errfun] = eigMatrixError(lambda,eigfun,lam,uh,A)
errlam=abs(lambda-lam);

errfun=eigfun-uh;
errfun=sqrt(errfun'*A*errfun);

end

