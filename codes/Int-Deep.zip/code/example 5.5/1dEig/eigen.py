import math
import numpy as np
from numpy import linalg
import numpy.random as npr
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import scipy.io as sio
import matplotlib.pyplot as plt
import time

torch.set_default_tensor_type('torch.DoubleTensor')

"""
define neutral network 
"""

class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(1, m)
        self.fc2 = nn.Linear(m, m)
        
        self.fc3 = nn.Linear(m, m)
        self.fc4 = nn.Linear(m, m)
        
        self.fc5 = nn.Linear(m, m)
        self.fc6 = nn.Linear(m, m)
        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc3(y)
        y = F.relu(y**3)
        y = self.fc4(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc5(y)
        y = F.relu(y**3)
        y = self.fc6(y)
        y = F.relu(y**3)
        y = y+s
        
        output = self.outlayer(y)
        return output
"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner1 = npr.rand(BatchSize,d)
        self.inner2 = npr.rand(BatchSize,d)

    def __getitem__(self, index):
        P = self.inner1[index,:]
        R = self.inner2[index,:]
        return P,R

    def __len__(self):
        return min(self.inner1.shape[0],self.inner2.shape[0])


"""
define function 
"""    
def truthvalue(h): 
    points = np.arange(0, 1+h, h)
    u = np.sin(math.pi*(points-1.))
    return u 

def absolute_err(u,uh): 
    e = uh - u
    ab_err = np.max(abs(e))
    return ab_err

def numericalvalue(h):
    points = np.arange(0, 1+h, h)
    uh = np.zeros(len(points))
    for i in range(len(points)):
        x_input = np.zeros(1)
        x_input[0] = points[i]
        x_input = torch.tensor(x_input).cuda()
        uh[i] = (x_input*(1-x_input)*model(x_input)).data
    return uh


if __name__ == '__main__':   
    m = 50
    h = 2**(-9)
    d = 1
    beta = 100
    
    epoch = 400
    
    learning_rate = 1e-3
    
    BATCH_SIZE = 512
    
    Ix = torch.zeros([1,m]).cuda()
    Ix[0,0] = 1
    
    model = ResNet(m).cuda()

    u=truthvalue(h)
    eiglam = d*math.pi**2
    
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999), eps=1e-8)
                      
    print("Eigen value ResNet 6 50")

    tstart=time.time()
    
    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),batch_size = BATCH_SIZE,
                                      shuffle=False,num_workers=1, drop_last= False)
                                      
        for step,batch_p in enumerate(data_loader): 
            batch_pin = batch_p[0].cuda()
            batch_ppt = batch_p[1].cuda()
            
            batch_pin.requires_grad = True
            batch_ppt.requires_grad = True
                        
            x0 = torch.tensor([0.5]).cuda()
            
            uin_out = model(batch_pin)
            upt_out = model(batch_ppt)
               
            v = torch.ones(uin_out.shape).cuda()
            grad = torch.autograd.grad(uin_out,batch_pin,grad_outputs=v,create_graph=True)[0]
            
            ux = (1-2*batch_pin)*uin_out + batch_pin*(1-batch_pin)*grad
            
            int_in1 = (ux**2).mean()
            int_in2 = ((batch_ppt*(1-batch_ppt)*upt_out)**2).mean()

            loss_in = int_in1/int_in2
            loss_pt = beta*(1./4.*model(x0)-1)**2
            
            loss = loss_in + loss_pt
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step() 

    torch.save(model.state_dict(), '1d_eigen_ResNet_6_50.pth')
            
    tend=time.time()
    print("deel learning time",tend-tstart)

    uh = numericalvalue(h)
    print(absolute_err(-u,uh))


#    sio.savemat('eig_sol',mdict={'udl':uh})
    sio.savemat('eig_sol_6_50',mdict={'udl':uh})
    
  
  
