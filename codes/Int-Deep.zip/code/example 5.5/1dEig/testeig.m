function [El,Ef] = testeig()

load('DL_sol_5.mat');
load('DL_sol_6.mat');
load('DL_sol_7.mat');
load('DL_sol_8.mat');
load('DL_sol_9.mat');
%load('DL_sol_10.mat');
%load('DL_sol.mat');


n=(5:1:9);
N=2.^n;
El=zeros(5,1);
Ef=zeros(5,1);

[lambda6,fun6,El(1),Ef(1)] = hybric(N(1),0,1,udl_5');
[lambda6,fun6,El(2),Ef(2)] = hybric(N(2),0,1,udl_6');
[lambda7,fun7,El(3),Ef(3)] = hybric(N(3),0,1,udl_7');
[lambda8,fun8,El(4),Ef(4)] = hybric(N(4),0,1,udl_8');
[lambda9,fun9,El(5),Ef(5)] = hybric(N(5),0,1,udl_9');
%[lambda10,fun10,El(6),Ef(6)] = hybric(N(6),0,1,udl_10');
%[lambda10,fun10,El(5),Ef(5)] = hybric(N(5),0,1,udl');

end
