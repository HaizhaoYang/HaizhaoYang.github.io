function [lambda,fun] = eigen(ne,a,b)
lambda=1*pi^2;
h=(b-a)/ne;
x=(a:h:b)';
s=size(x,1);
fun=zeros(s,1);
for i=1:1:s
    fun(i,1)=sin(pi*(x(i)-1)); % u = sin(pi(x-1))
end
end

