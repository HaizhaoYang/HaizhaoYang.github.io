function [v] = normlize(v,A)
norm=sqrt(v'*A*v);
v=v/norm;
end

