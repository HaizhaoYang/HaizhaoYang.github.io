function [lambda,fun,errlam,errfun] = hybric(ne,a,b,u0)
ca=-1;
cc=1;

[minlambda,eigenfun]=eigen(ne,a,b);
eigenfun=funcnormlize(-eigenfun);

nnpe=2;
nn=(nnpe-1)*ne+1;
dofpn=1;
sdof=nn*dofpn;
[nodcoor,ean]=femmesh(ne,nn,a,b,nnpe);
dldof=size(u0,1);

ek=femek_P1(nodcoor,ean,ne,nnpe,ca);
K=femMatrix(ek,ne,sdof,nnpe);
K=fembcM_D(K,sdof);

em=femelm_P1(nodcoor,ean,ne,nnpe,cc);
M=femMatrix(em,ne,sdof,nnpe);
M=fembcM_D(M,sdof);

u0(1,1)=0;
u0(dldof,1)=0;
u0=normlize(u0,M);
lam=(u0'*K*u0)/(u0'*M*u0);

[e1,e2]=eigMatrixError(minlambda,eigenfun,lam,u0,M);
E1=zeros(11,1);
E1(1,1)=e1;
E2=zeros(11,1);
E2(1,1)=e2;

o=0;
e=1;
eps=((b-a)/ne)^2;

while e > eps && o<10
    F=lam*M*u0;
    uh=K\F;
    lam=(uh'*K*uh)/(uh'*M*uh);
    e=MatrixError(uh,u0,M)/sqrt(u0'*M*u0);
    [e1,e2]=eigMatrixError(minlambda,eigenfun,lam,normlize(uh,M),M);
    %[e1,e2]=eigMatrixError(minlambda,eigenfun,lam,uh,M);
    u0=uh;
    o=o+1;
    E1(o+1,1)=e1;
    E2(o+1,1)=e2;
end
disp(o);

%fun=uh;
fun=normlize(uh,M);
lambda=lam;
[errlam,errfun]=eigMatrixError(minlambda,eigenfun,lambda,fun,M);

disp(errlam);
disp(errfun);

%E1=E1(1:o+1,1);
%E2=E2(1:o+1,1);
%disp(E1);
%disp(E2);

end

