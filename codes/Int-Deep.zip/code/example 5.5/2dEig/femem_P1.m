function [ em ] = femem_P1(p,t,gne,nnpe)
em=zeros(nnpe*gne,nnpe);
for i=1:1:gne
    in1=t(1,i);
    in2=t(2,i);
    in3=t(3,i);
    x1=p(in1,1);
    x2=p(in2,1);
    x3=p(in3,1);
    y1=p(in1,2);
    y2=p(in2,2);
    y3=p(in3,2);
    S=det([1 x1 y1;1 x2 y2;1 x3 y3])/2;
    m11=1/12;
    m12=1/24;
    m13=1/24;
    m21=m12;
    m22=1/12;
    m23=1/24;
    m31=m13;
    m32=m23;
    m33=1/12;
    emc=2*S*[m11,m12,m13;m21,m22,m23;m31,m32,m33];
    iesi=nnpe*(i-1);
    em(iesi+1:nnpe*i,1:nnpe)=emc;
end


