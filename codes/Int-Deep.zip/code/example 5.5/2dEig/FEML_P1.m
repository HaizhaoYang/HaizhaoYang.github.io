function [lambda,uh,errlam,errfun] = FEML_P1(ne,a,b,c,d,lam,u0)
ca=-1;

[minlambda,eigenfun]=eigen(ne,a,b);
eigenfun=funcnormlize(eigenfun);

[p,e,t]=femmesh(ne,a,b,c,d);
gne=size(t,2);
nnpe=size(t,1);
nn=(ne+1)*(ne+1);
dofpn=1;
sdof=nn*dofpn;

ek=femek_P1(p,t,gne,nnpe,ca);
K=femMatrix(t,ek,gne,sdof,nnpe);
em=femem_P1(p,t,gne,nnpe);
M=femMatrix(t,em,gne,sdof,nnpe);
[K,M]=femMbc_D(K,M,e);

index=e(1,:)';
u0(index,1)=0;
u0=normlize(u0,M);

% ef=femefl_P1(p,t,gne,nnpe,u0,lam);
% F=femVector(t,ef,gne,sdof,nnpe);
% [F]=femVbc_D(F,e);
F=lam*M*u0;
uh=K\F;
%uh=normlize(uh,M);
lambda=(uh'*K*uh)/(uh'*M*uh);

[errlam,errfun]=MatrixError(minlambda,eigenfun,lambda,normlize(uh,M),M);
disp(errlam);
disp(errfun);

end