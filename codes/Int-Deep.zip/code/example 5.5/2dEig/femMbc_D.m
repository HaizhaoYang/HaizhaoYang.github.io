function [ K,M ] = femMbc_D(K,M,e)
s=size(e,2);
for i=1:1:s
    index=e(1,i);
    K(index,:)=0;
    K(index,index)=1;
    M(index,:)=0;
    M(index,index)=1;
end
end
