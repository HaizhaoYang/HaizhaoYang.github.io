function [ ef ] = femefl_P1(p,t,gne,nnpe,u0,lam)
ef=zeros(nnpe*gne,1);
for i=1:1:gne
    in1=t(1,i);
    in2=t(2,i);
    in3=t(3,i);
    x1=p(in1,1);
    x2=p(in2,1);
    x3=p(in3,1);
    y1=p(in1,2);
    y2=p(in2,2);
    y3=p(in3,2);
    u1=u0(in1);
    u2=u0(in2);
    u3=u0(in3);
    S=det([1 x1 y1;1 x2 y2;1 x3 y3])/2;
    %f = lam*(u1phi1+u2phi2+u3phi3)
    iesi=nnpe*(i-1);
    ef(iesi+1,1)=2*S*(u1/12+u2/24+u3/24);
    ef(iesi+2,1)=2*S*(u1/24+u2/12+u3/24);
    ef(iesi+3,1)=2*S*(u1/24+u2/24+u3/12);
end
ef=lam*ef;
end

