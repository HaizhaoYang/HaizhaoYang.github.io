function [lambda,fun] = eigen(ne,a,b)
lambda=2*pi^2;
h=(b-a)/ne;
x=(a:h:b)';
s=size(x,1);
fun=zeros(s*s,1);
for j=1:1:s
    for i=1:1:s
        fun(i+(j-1)*s,1)=sin(pi*(x(i)-1))*sin(pi*(x(j)-1)); % u = sin(pi(x-1))sin(pi(y-1));
    end
end

end

