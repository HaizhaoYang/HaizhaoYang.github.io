import math
import numpy as np
from numpy import linalg
import numpy.random as npr
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import scipy.io as sio
import matplotlib.pyplot as plt
import time

torch.set_default_tensor_type('torch.DoubleTensor')

"""
define neutral network 
"""

class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(2, m)
        self.fc2 = nn.Linear(m, m)
        
        self.fc3 = nn.Linear(m, m)
        self.fc4 = nn.Linear(m, m)
        
        self.fc5 = nn.Linear(m, m)
        self.fc6 = nn.Linear(m, m)
        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc3(y)
        y = F.relu(y**3)
        y = self.fc4(y)
        y = F.relu(y**3)
        y = y+s
        
        s=y
        y = self.fc5(y)
        y = F.relu(y**3)
        y = self.fc6(y)
        y = F.relu(y**3)
        y = y+s

        output = self.outlayer(y)
        return output
    

"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner1 = npr.rand(BatchSize,d)
        self.inner2 = npr.rand(BatchSize,d)

    def __getitem__(self, index):
        P = self.inner1[index,:]
        R = self.inner2[index,:]
        return P,R

    def __len__(self):
        return min(self.inner1.shape[0],self.inner2.shape[0])


"""
define function 
"""    
def truthvalue(h): 
    points = np.arange(0, 1+h, h)
    s = len(points)
    u = np.zeros(s*s)
    for j in range(s):
        for i in range(s):
            u[i+j*s] = np.sin(math.pi*(points[i]-1.))*np.sin(math.pi*(points[j]-1.))      
    return u

def absolute_err(u,uh): 
    e1 = uh - u
    ab_err = np.max(abs(e1))
    return ab_err

def numericalvalue(h):
    points = np.arange(0, 1+h, h)
    s = len(points)
    uh = np.zeros(s*s)
    P = np.zeros(2)
    for j in range(s):
        for i in range(s):
            P[0] = points[i]
            P[1] = points[j]
            x_input = torch.tensor(P).cuda()
            uh[i+j*s] = P[0]*(1-P[0])*P[1]*(1-P[1])*model(x_input).data
    return uh
    

if __name__ == '__main__':   
    m = 50
    h = 2**(-7)
    d = 2
    beta = 100
    
    epoch = 400
    
    learning_rate = 1e-3
    
    BATCH_SIZE = 1024
    
    Ix = torch.zeros([2,m]).cuda()
    Ix[0,0] = 1
    Ix[1,1] = 1
    
    model = ResNet(m).cuda()
#    model.load_state_dict(torch.load('2deigen_ResNet.pth'))
    
    u=truthvalue(h)
    eigvalue = d*math.pi**2
    
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999), eps=1e-8)
    
    print("2d Eigenvalue ResNet 6 50")
    tstart=time.time()
    
    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),
                                      batch_size = BATCH_SIZE,shuffle=False,
                                      num_workers=1, drop_last= False)
                                      
        for step,batch_p in enumerate(data_loader): 
            pin = batch_p[0].cuda()
            ppt = batch_p[1].cuda()
            
            tx = pin[:,0]
            x = tx.reshape([tx.size()[0],1])
            ty = pin[:,1]
            y = ty.reshape([ty.size()[0],1])
            x.requires_grad = True
            y.requires_grad = True
            batch_pin = torch.cat((x,y),1).cuda()
            
            txx = ppt[:,0]
            xx = txx.reshape([txx.size()[0],1])
            tyy = ppt[:,1]
            yy = tyy.reshape([tyy.size()[0],1])
            xx.requires_grad = True
            yy.requires_grad = True
            batch_ppt = torch.cat((xx,yy),1).cuda()
            
            x0 = torch.tensor([0.5,0.5]).cuda()
            
            uin_out = model(batch_pin)
            upt_out = model(batch_ppt)
               
            v = torch.ones(uin_out.shape).cuda()
            ux = torch.autograd.grad(uin_out,x,grad_outputs=v,create_graph=True)[0]
            uy = torch.autograd.grad(uin_out,y,grad_outputs=v,create_graph=True)[0]
            
            vx=(1-2*x)*y*(1-y)*uin_out+x*(1-x)*y*(1-y)*ux
            vy=(1-2*y)*x*(1-x)*uin_out+x*(1-x)*y*(1-y)*uy
            
            int_in1 = (vx**2+vy**2).mean()
            int_in2 = ((xx*(1-xx)*yy*(1-yy)*upt_out)**2).mean()

            loss_in = int_in1/int_in2
            loss_pt = beta*(1./16.*model(x0)-1.)**2
            
            loss = loss_in + loss_pt
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

    torch.save(model.state_dict(), '2deigen_ResNet_6_50.pth')
    tend=time.time()
    print("deel learning time",tend-tstart)

    uh = numericalvalue(h)
    print(absolute_err(u,uh))

    sio.savemat('eigenfunc_6_50',mdict={'udl':uh})
#    sio.savemat('EigFun8',mdict={'udl8':uh})

