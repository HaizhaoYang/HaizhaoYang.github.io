function [lambda,fun,errlam,errfun] = DRFEM(ne,a,b,c,d,u0)
ca=-1;

[minlambda,eigenfun]=eigen(ne,a,b);
eigenfun=funcnormlize(eigenfun);

[p,e,t]=femmesh(ne,a,b,c,d);
gne=size(t,2);
nnpe=size(t,1);
nn=(ne+1)*(ne+1);
dofpn=1;
sdof=nn*dofpn;

ek=femek_P1(p,t,gne,nnpe,ca);
K=femMatrix(t,ek,gne,sdof,nnpe);
em=femem_P1(p,t,gne,nnpe);
M=femMatrix(t,em,gne,sdof,nnpe);
[K,M]=femMbc_D(K,M,e);

index=e(1,:)';
u0(index,1)=0;
u0=normlize(u0,M);
lam=(u0'*K*u0)/(u0'*M*u0);

[e1,e2]=eigMatrixError(minlambda,eigenfun,lam,u0,M);
E1=zeros(11,1);
E1(1,1)=e1;
E2=zeros(11,1);
E2(1,1)=e2;

o=0;
e=e2;
eps=((b-a)/ne)*((d-c)/ne);

while e > eps && o<10
    F=lam*M*u0;
    uh=K\F;
    lam=(uh'*K*uh)/(uh'*M*uh);
    e=sqrt((uh-u0)'*M*(uh-u0))/sqrt(u0'*M*u0);
    [e1,e2]=eigMatrixError(minlambda,eigenfun,lam,normlize(uh,M),M);
    u0=uh;
    o=o+1;
    E1(o+1,1)=e1;
    E2(o+1,1)=e2;
end
disp(o);

%fun=uh;
fun=normlize(uh,M);
lambda=lam;
[errlam,errfun]=eigMatrixError(minlambda,eigenfun,lambda,fun,M);
disp(errlam);
disp(errfun);

%E1=E1(1:o+1,1);
%E2=E2(1:o+1,1);
%disp(E1);
%disp(E2);


end

