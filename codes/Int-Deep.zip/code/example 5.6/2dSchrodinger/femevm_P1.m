function [ evm ] = femevm_P1(p,t,gne,nnpe)
evm=zeros(nnpe*gne,nnpe);
for i=1:1:gne
    in1=t(1,i);
    in2=t(2,i);
    in3=t(3,i);
    x1=p(in1,1);
    x2=p(in2,1);
    x3=p(in3,1);
    y1=p(in1,2);
    y2=p(in2,2);
    y3=p(in3,2);
    S=det([1 x1 y1;1 x2 y2;1 x3 y3])/2;
    v1=Vfunc(x1,y1);
    v2=Vfunc(x2,y2);
    v3=Vfunc(x3,y3);    
    
    vm11=1/20*v1+1/60*v2+1/60*v3;
    vm12=1/60*v1+1/60*v2+1/120*v3;
    vm13=1/60*v1+1/120*v2+1/60*v3;
    vm21=vm12;
    vm22=1/60*v1+1/20*v2+1/60*v3;
    vm23=1/120*v1+1/60*v2+1/60*v3;
    vm31=vm13;
    vm32=vm23;
    vm33=1/60*v1+1/60*v2+1/20*v3;
    evmc=[vm11,vm12,vm13;vm21,vm22,vm23;vm31,vm32,vm33]*2*S;

%     x12=(x1+x2)/2;
%     x23=(x2+x3)/2;
%     x13=(x1+x3)/2;
%     y12=(y1+y2)/2;
%     y23=(y2+y3)/2;
%     y13=(y1+y3)/2;
%     v12=Vfunc(x12,y12);
%     v13=Vfunc(x13,y13);
%     v23=Vfunc(x23,y23);    
%     vm11=1/4*v12+1/4*v13;
%     vm12=1/4*v12;
%     vm13=1/4*v13;
%     vm21=vm12;
%     vm22=1/4*v12+1/4*v23;
%     vm23=1/4*v23;
%     vm31=vm13;
%     vm32=vm23;
%     vm33=1/4*v23+1/4*v13;
%     evmc=[vm11,vm12,vm13;vm21,vm22,vm23;vm31,vm32,vm33]*S/3;
    
    iesi=nnpe*(i-1);
    evm(iesi+1:nnpe*i,1:nnpe)=evmc;
end


