function [err] = MatrixError(eigfun,uh,A)
errfun=eigfun-uh;
err=sqrt(errfun'*A*errfun);

end

