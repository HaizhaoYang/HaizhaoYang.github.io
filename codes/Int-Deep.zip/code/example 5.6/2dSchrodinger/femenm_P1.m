function [ enm ] = femenm_P1(p,t,gne,nnpe,beta,u0)
enm=zeros(nnpe*gne,nnpe);
for i=1:1:gne
    in1=t(1,i);
    in2=t(2,i);
    in3=t(3,i);
    u1=u0(in1);
    u2=u0(in2);
    u3=u0(in3);
    x1=p(in1,1);
    x2=p(in2,1);
    x3=p(in3,1);
    y1=p(in1,2);
    y2=p(in2,2);
    y3=p(in3,2);
    S=det([1 x1 y1;1 x2 y2;1 x3 y3])/2;
    
    nm11=1/20*u1^2+1/60*u2^2+1/60*u3^2;
    nm12=1/60*u1^2+1/60*u2^2+1/120*u3^2;
    nm13=1/60*u1^2+1/120*u2^2+1/60*u3^2;
    nm21=nm12;
    nm22=1/60*u1^2+1/20*u2^2+1/60*u3^2;
    nm23=1/120*u1^2+1/60*u2^2+1/60*u3^2;
    nm31=nm13;
    nm32=nm23;
    nm33=1/60*u1^2+1/60*u2^2+1/20*u3^2;
    enmc=beta*[nm11,nm12,nm13;nm21,nm22,nm23;nm31,nm32,nm33]*2*S;
    
%     u12=(u1+u2)/2;
%     u13=(u1+u3)/2;
%     u23=(u2+u3)/2;
%     m11=1/4*u12^2+1/4*u13^2;
%     m12=1/4*u12^2; 
%     m13=1/4*u13^2;  
%     m21=m12;
%     m22=1/4*u12^2+1/4*u23^2;
%     m23=1/4*u23^2;
%     m31=m13;  
%     m32=m23;
%     m33=1/4*u13^2+1/4*u23^2;
%     enmc=beta*[m11,m12,m13;m21,m22,m23;m31,m32,m33]*S/3;

    iesi=nnpe*(i-1);
    enm(iesi+1:nnpe*i,1:nnpe)=enmc;
end


