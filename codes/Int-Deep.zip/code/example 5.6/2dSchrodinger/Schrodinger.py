import math
import numpy as np
from numpy import linalg
import numpy.random as npr
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import scipy.io as sio
import matplotlib.pyplot as plt
import time
from scipy.stats import norm

torch.set_default_tensor_type('torch.DoubleTensor')

#torch.manual_seed(1)
"""
define neutral network 
"""

class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(2, m)
        self.fc2 = nn.Linear(m, m)
        
        #self.fc3 = nn.Linear(m, m)
        #self.fc4 = nn.Linear(m, m)
        
        #self.fc5 = nn.Linear(m, m)
        #self.fc6 = nn.Linear(m, m)
        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        #s=y
        #y = self.fc3(y)
        #y = F.relu(y**3)
        #y = self.fc4(y)
        #y = F.relu(y**3)
        #y = y+s
        
        #s=y
        #y = self.fc5(y)
        #y = F.relu(y**3)
        #y = self.fc6(y)
        #y = F.relu(y**3)
        #y = y+s
        
        output = self.outlayer(y)
        return output

"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner1 = npr.rand(BatchSize,d)
        self.inner2 = npr.rand(BatchSize,d)
        self.inner3 = npr.rand(BatchSize,d)

    def __getitem__(self, index):
        P = self.inner1[index,:]
        Q = self.inner2[index,:]
        R = self.inner3[index,:]
        return P,Q,R

    def __len__(self):
        return min(self.inner1.shape[0],self.inner2.shape[0],self.inner3.shape[0])

"""
define function 
"""
def numericalvalue(h):
    points = np.arange(0, 1+h, h)
    s = len(points)
    uh = np.zeros(s*s)
    P = np.zeros(2)
    for j in range(s):
        for i in range(s):
            P[0] = points[i]
            P[1] = points[j]
            x_input = torch.tensor(P).cuda()
            uh[i+j*s] = P[0]*(1-P[0])*P[1]*(1-P[1])*model(x_input)
    return uh


def V(x):
    indx = (x[:,0]<=0.5)
    indy = (x[:,1]<=0.5)
    v = (norm.pdf(x[:,0],0.25,1)*indx)*(norm.pdf(x[:,1],0.25,1)*indy)+(norm.pdf(x[:,0],0.75,1)*(1-indx))*(norm.pdf(x[:,1],0.25,1)*indy) \
      + (norm.pdf(x[:,0],0.25,1)*indx)*(norm.pdf(x[:,1],0.75,1)*(1-indy))+(norm.pdf(x[:,0],0.75,1)*(1-indx))*(norm.pdf(x[:,1],0.75,1)*(1-indy))
    return v

def VX(h):
    points = np.arange(0, 1+h, h)
    s=len(points)
    vx = np.zeros(s*s)
    P = np.zeros(2)
    for j in range(s):
        for i in range(s):
            P[0] = points[i]
            P[1] = points[j]
            indx = (P[0]<=0.5)
            indy = (P[1]<=0.5)
            v = (norm.pdf(P[0],0.25,1)*indx)*(norm.pdf(P[1],0.25,1)*indy)+(norm.pdf(P[0],0.75,1)*(1-indx))*(norm.pdf(P[1],0.25,1)*indy) \
              + (norm.pdf(P[0],0.25,1)*indx)*(norm.pdf(P[1],0.75,1)*(1-indy))+(norm.pdf(P[0],0.75,1)*(1-indx))*(norm.pdf(P[1],0.75,1)*(1-indy))
            vx[i+j*s] = v
    return vx
    

if __name__ == '__main__':   
    m = 10
    h = 2**(-7)
    d = 2
    beta = 10
    gamma =100
    
    epoch = 400
    
    learning_rate = 1e-3
    
    BATCH_SIZE = 1024
    
    Ix = torch.zeros([2,m]).cuda()
    Ix[0,0] = 1
    Ix[1,1] = 1

    model = ResNet(m).cuda()
#    model.load_state_dict(torch.load('2d_schrodinger_ResNet_ref.pth',torch.device('cpu')))
#    model.load_state_dict(torch.load('2d_schrodinger_ResNet.pth',torch.device('cpu')))

    optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999), eps=1e-8)
                      
    print("2d Schrodinger 2 10")

    tstart=time.time()
    
    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),batch_size = BATCH_SIZE,
                                      shuffle=False,num_workers=1, drop_last= False)
                                      
        for step,batch_p in enumerate(data_loader): 
            pin = batch_p[0].cuda()
            ppt1 = batch_p[1].cuda()
            ppt2 = batch_p[2].cuda()
            
            tx = pin[:,0]
            x = tx.reshape([tx.size()[0],1])
            ty = pin[:,1]
            y = ty.reshape([ty.size()[0],1])
            x.requires_grad = True
            y.requires_grad = True
            batch_pin = torch.cat((x,y),1)
            
            tx1 = ppt1[:,0]
            x1 = tx1.reshape([tx1.size()[0],1])
            ty1 = ppt1[:,1]
            y1 = ty1.reshape([ty1.size()[0],1])
            x1.requires_grad = True
            y1.requires_grad = True
            batch_ppt1 = torch.cat((x1,y1),1)
                        
            tx2 = ppt2[:,0]
            x2 = tx2.reshape([tx2.size()[0],1])
            ty2 = ppt2[:,1]
            y2 = ty2.reshape([ty2.size()[0],1])
            x2.requires_grad = True
            y2.requires_grad = True
            batch_ppt2 = torch.cat((x2,y2),1)
        
            uin_out = x*(1-x)*y*(1-y)*model(batch_pin)
            upt_out1 = x1*(1-x1)*y1*(1-y1)*model(batch_ppt1)
            upt_out2 = x2*(1-x2)*y2*(1-y2)*model(batch_ppt2)
            
            batch_pin_cpu=batch_pin.cpu()
            EP=V(batch_pin_cpu.detach().numpy())
            EP = torch.tensor(EP).cuda()
     
            ux = torch.autograd.grad(uin_out,x,torch.ones(uin_out.shape).cuda(),create_graph=True)[0]
            uy = torch.autograd.grad(uin_out,y,torch.ones(uin_out.shape).cuda(),create_graph=True)[0]
    
            int_inl = (ux**2+uy**2 + EP*uin_out**2).mean()
            int_innl = (0.5*beta*uin_out**4).mean()
            int_in2 = (upt_out1**2).mean()
            int_in3 = (upt_out2**2).mean()

            loss = int_inl/int_in2 + int_innl/(int_in2*int_in3) + gamma*(1./16.*model(torch.tensor([0.5,0.5]).cuda())-1.)**2
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step() 

    torch.save(model.state_dict(), '2d_schrodinger_ResNet 2 10.pth')
#    torch.save(model.state_dict(), '2d_schrodinger_ResNet_ref.pth')

    tend=time.time()
    print("deel learning time",tend-tstart)

    points = np.arange(0, 1+h, h)
    s = len(points)
    px=torch.zeros(s*s,1).cuda()
    py=torch.zeros(s*s,1).cuda()
    for j in range(s):
        for i in range(s):
            px[i+j*s] = points[i]
            py[i+j*s] = points[j]
    px = px.reshape([px.size()[0],1])
    py = py.reshape([py.size()[0],1])
    px.requires_grad = True
    py.requires_grad = True
    points_input = torch.cat((px,py),1)
    points_v=VX(h)

    fh = px*(1-px)*py*(1-py)*model(points_input)
    fx=torch.autograd.grad(fh,px,torch.ones(fh.shape).cuda(),create_graph=True)[0]
    fy=torch.autograd.grad(fh,py,torch.ones(fh.shape).cuda(),create_graph=True)[0]
    lam = ((fx**2 +fy**2 + torch.tensor(VX(h)).cuda()*fh**2).mean()) /((fh**2).mean()) \
            + ((beta*fh**4).mean())/((fh**2).mean())**2
    print("lam:",lam)


    uh = fh.cpu()
    lam=lam.cpu()
    #plt.plot(uh.data)
    #plt.show()

#    sio.savemat('eigen_sol_ref',mdict={'udl_ref':uh})

    sio.savemat('eig_sol_2_10',mdict={'udl':uh.detach().numpy()})
    
  
  
