function [El,Ef] = test()

load('eigfunc4.mat');
load('eigfunc5.mat');
load('eigfunc6.mat');
load('eigfunc7.mat');
load('eigfunc8.mat');


n=(4:1:8);
N=2.^n;
El=zeros(5,1);
Ef=zeros(5,1);

[lambda4,fun4,El(1),Ef(1)] = DRFEM(N(1),0,1,0,1,udl_4');
[lambda5,fun5,El(2),Ef(2)] = DRFEM(N(2),0,1,0,1,udl_5');
[lambda6,fun6,El(3),Ef(3)] = DRFEM(N(3),0,1,0,1,udl_6');
[lambda7,fun7,El(4),Ef(4)] = DRFEM(N(4),0,1,0,1,udl_7');
[lambda8,fun8,El(5),Ef(5)] = DRFEM(N(5),0,1,0,1,udl_8');

end
