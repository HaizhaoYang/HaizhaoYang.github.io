function [lambda,fun,res] = hybric3(ne,a,b,c,d,u0)
ca=-1;
beta=10;

[p,e,t]=femmesh(ne,a,b,c,d);
gne=size(t,2);
nnpe=size(t,1);
nn=(ne+1)*(ne+1);
dofpn=1;
sdof=nn*dofpn;

ek=femek_P1(p,t,gne,nnpe,ca);
K=femMatrix(t,ek,gne,sdof,nnpe);
K=femMbc_D(K,e);

em=femem_P1(p,t,gne,nnpe);
M=femMatrix(t,em,gne,sdof,nnpe);
M=femMbc_D(M,e);

evm=femevm_P1(p,t,gne,nnpe);
VM=femMatrix(t,evm,gne,sdof,nnpe);
VM=femMbc_D(VM,e);

%[lamb,func]= ref(ne);
%func=normlize(func,M);
u0=normlize(u0,M);

enm=femenm_P1(p,t,gne,nnpe,beta,u0);
NM=femMatrix(t,enm,gne,sdof,nnpe);
NM=femMbc_D(NM,e);

lam=(u0'*(K+VM+NM)*u0)/(u0'*M*u0);
disp(lam);

%disp(MatrixError(func,u0,M));
%disp(abs(lamb-lam));

o=0;
ee=1;
eps=((b-a)/ne)*((d-c)/ne);

Res=zeros(11,1);
Res(1,1)=checkfem(K,VM,NM,M,lam,u0);
disp(Res(1,1));

while ee > eps && o<10
    F=lam*M*u0-NM*u0;
    uh=(K+VM)\F;
    uh=normlize(uh,M);
    enm=femenm_P1(p,t,gne,nnpe,beta,u0);
    NM=femMatrix(t,enm,gne,sdof,nnpe);
    NM=femMbc_D(NM,e);
    lam=(uh'*(K+VM+NM)*uh)/(uh'*M*uh);
    ee=MatrixError(uh,u0,M)/sqrt(u0'*M*u0);
    u0=uh;
    o=o+1;
    Res(o+1,1)=checkfem(K,VM,NM,M,lam,u0);
end
disp(o);

%toc

fun=normlize(uh,M);
lambda=lam;

Res=Res(1:o+1,1);
disp(Res);
res=Res(o+1,1);
disp(res);
disp(lambda)

end

