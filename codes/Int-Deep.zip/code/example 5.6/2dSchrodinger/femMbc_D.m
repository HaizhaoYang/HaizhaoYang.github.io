function [ A ] = femMbc_D(A,e)
s=size(e,2);
for i=1:1:s
    index=e(1,i);
    A(index,:)=0;
    A(index,index)=1;
end
end
