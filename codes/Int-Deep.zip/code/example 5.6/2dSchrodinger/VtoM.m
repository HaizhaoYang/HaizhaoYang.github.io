function [U] = VtoM(u)
s=size(u,1);
s=sqrt(s);
U=zeros(s,s);
for i=1:1:s
    for j=1:1:s
        U(i,j)=u((i-1)*s+j,1);
    end
end

end

