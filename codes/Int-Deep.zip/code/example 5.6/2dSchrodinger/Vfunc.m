function [v] = Vfunc(x,y)
if x<=0.5
    if y<=0.5
        v=mvnpdf([x,y],[0.25,0.25],eye(2));
    else
        v=mvnpdf([x,y],[0.25,0.75],eye(2));
    end
else
    if y<=0.5
        v=mvnpdf([x,y],[0.75,0.25],eye(2));
    else
        v=mvnpdf([x,y],[0.75,0.75],eye(2));
    end
end

end

