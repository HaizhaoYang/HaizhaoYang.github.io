function [lamb,func] = ref(ne)
h=1024/ne;
load('eigen_sol_ref.mat')
lamb=lam_ref;
func=udl_ref(1:h:1025);

end

