function [Res] = testeig()

load('eigen_sol_5.mat');
load('eigen_sol_6.mat');
load('eigen_sol_7.mat');
load('eigen_sol_8.mat');
load('eigen_sol_9.mat');


n=(5:1:10);
N=2.^n;
Res=zeros(5,1);

% [lambda5,fun5,Res(1)] = hybric3(N(1),0,1,udl_5);
% [lambda6,fun6,Res(2)] = hybric3(N(2),0,1,udl_6);
% [lambda7,fun7,Res(3)] = hybric3(N(3),0,1,udl_7);
% [lambda8,fun8,Res(4)] = hybric3(N(4),0,1,udl_8);
% [lambda9,fun9,Res(5)] = hybric3(N(5),0,1,udl_9);

[lambda5,fun5,Res(1)] = Newton(N(1),0,1,udl_5);
[lambda6,fun6,Res(2)] = Newton(N(2),0,1,udl_6);
[lambda7,fun7,Res(3)] = Newton(N(3),0,1,udl_7);
[lambda8,fun8,Res(4)] = Newton(N(4),0,1,udl_8);
[lambda9,fun9,Res(5)] = Newton(N(5),0,1,udl_9);
end
