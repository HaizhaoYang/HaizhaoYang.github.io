function [ elm ] = femelm_P1(nodcoor,ean,ne,nnpe)
elm=zeros(nnpe*ne,nnpe);
for i=1:1:ne
    nl=ean(i,1);
    nr=ean(i,2);
    len=nodcoor(nr)-nodcoor(nl);
    ema=[2,1;1,2]*len/6;
    iesi=nnpe*(i-1);
    elm(iesi+1:nnpe*i,1:nnpe)=ema;
end
end

