function [lambda,fun,res] = hybric3(ne,a,b,u0)
ca=-1;
beta=10;

h=(b-a)/ne;
gauss=normpdf((0:h:0.5),0.25);
V=repmat(gauss(1,1:ne/2),[1,2]);
V=[V,gauss(1,ne/2+1)];

nnpe=2;
nn=(nnpe-1)*ne+1;
dofpn=1;
sdof=nn*dofpn;
[nodcoor,ean]=femmesh(ne,nn,a,b,nnpe);

ek=femek_P1(nodcoor,ean,ne,nnpe,ca);
K=femMatrix(ek,ne,sdof,nnpe);
K=fembcM_D(K,sdof);

em=femelm_P1(nodcoor,ean,ne,nnpe);
M=femMatrix(em,ne,sdof,nnpe);
M=fembcM_D(M,sdof);

evm=femevm_P1(nodcoor,ean,ne,nnpe,V);
VM=femMatrix(evm,ne,sdof,nnpe);
VM=fembcM_D(VM,sdof);

[lamb,func]= ref(ne);
func=normlize(func,M);
u0=normlize(u0,M);

enm=femenm_P1(nodcoor,ean,ne,nnpe,beta,u0);
NM=femMatrix(enm,ne,sdof,nnpe);
NM=fembcM_D(NM,sdof);

lam=(u0'*(K+VM+NM)*u0)/(u0'*M*u0);
disp(lam)

disp(MatrixError(func,u0,M));
disp(abs(lamb-lam));

o=0;
e=1;
eps=h^2;

Res=zeros(6,1);
Res(1,1)=checkfem(K,VM,NM,M,lam,u0);
%disp(Res(1,1));

while e > eps && o<6
    F=lam*M*u0-NM*u0;
    uh=(K+VM)\F;
    uh=normlize(uh,M);
    enm=femenm_P1(nodcoor,ean,ne,nnpe,beta,uh);
    NM=femMatrix(enm,ne,sdof,nnpe);
    NM=fembcM_D(NM,sdof);
    lam=(uh'*(K+VM+NM)*uh)/(uh'*M*uh);
    e=MatrixError(uh,u0,M)/sqrt(u0'*M*u0);
    u0=uh;
    o=o+1;
    Res(o+1,1)=checkfem(K,VM,NM,M,lam,u0);
end
disp(o);

fun=normlize(uh,M);
lambda=lam;
disp(lambda)

disp(MatrixError(func,fun,M));
disp(abs(lamb-lambda));

Res=Res(1:o+1,1);
res=Res(o+1,1);
disp(Res);
% disp(res);

end

