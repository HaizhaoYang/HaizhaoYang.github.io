function [ evm ] = femevm_P1(nodcoor,ean,ne,nnpe,V)
evm=zeros(nnpe*ne,nnpe);
for i=1:1:ne
    nl=ean(i,1);
    nr=ean(i,2);
    xl=nodcoor(nl);
    xr=nodcoor(nr);
    vl=V(nl);
    vr=V(nr);
    len=xr-xl;
    emc=zeros(2,2);   
    emc(1,1)=vl*len/4+vr*len/12;
    emc(1,2)=vl*len/12+vr*len/12;
    emc(2,1)=vl*len/12+vr*len/12;
    emc(2,2)=vl*len/12+vr*len/4;
    iesi=nnpe*(i-1);
    evm(iesi+1:nnpe*i,1:nnpe)=emc;
end
end

