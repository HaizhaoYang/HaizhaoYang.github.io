import math
import numpy as np
from numpy import linalg
import numpy.random as npr
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import Dataset
import torch.optim as optim
import scipy.io as sio
import matplotlib.pyplot as plt
import time
from scipy.stats import norm

torch.set_default_tensor_type('torch.DoubleTensor')

"""
define neutral network 
"""

class ResNet(nn.Module):
    def __init__(self, m):
        super(ResNet, self).__init__()
        self.fc1 = nn.Linear(1, m)
        self.fc2 = nn.Linear(m, m)
        
        #self.fc3 = nn.Linear(m, m)
        #self.fc4 = nn.Linear(m, m)
        
        #self.fc5 = nn.Linear(m, m)
        #self.fc6 = nn.Linear(m, m)
        
        self.outlayer = nn.Linear(m, 1,bias = False)

    def forward(self, x):
        s = x@Ix
        y = self.fc1(x)
        y = F.relu(y**3)
        y = self.fc2(y)
        y = F.relu(y**3)
        y = y+s
        
        #s=y
        #y = self.fc3(y)
        #y = F.relu(y**3)
        #y = self.fc4(y)
        #y = F.relu(y**3)
        #y = y+s
        
        #s=y
        #y = self.fc5(y)
        #y = F.relu(y**3)
        #y = self.fc6(y)
        #y = F.relu(y**3)
        #y = y+s
        
        output = self.outlayer(y)
        return output
    

"""
define data 
"""
class EuclidPoints(Dataset):
    def __init__(self, d, BatchSize):
        self.inner1 = npr.rand(BatchSize,d)
        self.inner2 = npr.rand(BatchSize,d)
        self.inner3 = npr.rand(BatchSize,d)

    def __getitem__(self, index):
        P = self.inner1[index,:]
        Q = self.inner2[index,:]
        R = self.inner3[index,:]
        return P,Q,R

    def __len__(self):
        return min(self.inner1.shape[0],self.inner2.shape[0],self.inner3.shape[0])


"""
define function 
"""    

def numericalvalue(h):
    points = np.arange(0, 1+h, h)
    x_input=torch.tensor(points).cuda()
    x_input=torch.reshape(x_input,[int(1/h)+1,1])
    uh=x_input*(1.-x_input)*model(x_input)
    return uh


def V(x):
    ind = (x<=0.5)
    v=norm.pdf(x,0.25,1)*ind + norm.pdf(x,0.75,1)*(1.0-ind)
    return v

def VX(h):
    points = np.arange(0, 1+h, h)
    vx = np.zeros([len(points),1])
    for i in range(len(points)):
        vx[i] = V(points[i])
    return vx
    

if __name__ == '__main__':
    m = 50
    h = 2**(-9)
    d = 1
    beta = 10
    gamma =100
    
    epoch = 400
    
    learning_rate = 1e-3
    
    BATCH_SIZE = 512
    
    Ix = torch.zeros([1,m]).cuda()
    Ix[0,0] = 1

    model = ResNet(m).cuda()
#    model.load_state_dict(torch.load('1d_schrodinger_ResNet.pth',torch.device('cpu')))

    optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999), eps=1e-8)
    
    print("1d Schrodinger 2 50")

    tstart=time.time()
    
    for k in range(epoch):
        data_loader = data.DataLoader(dataset=EuclidPoints(d,BATCH_SIZE),batch_size = BATCH_SIZE,
                                      shuffle=False,num_workers=1, drop_last= False)
                                      
        for step,batch_p in enumerate(data_loader):
            batch_pin = batch_p[0].cuda()
            batch_ppt1 = batch_p[1].cuda()
            batch_ppt2 = batch_p[2].cuda()
            
            batch_pin.requires_grad = True
            batch_ppt1.requires_grad = True
            batch_ppt2.requires_grad = True
                        
            uin_out = batch_pin*(1-batch_pin)*model(batch_pin)
            upt_out1 = batch_ppt1*(1-batch_ppt1)*model(batch_ppt1)
            upt_out2 = batch_ppt2*(1-batch_ppt2)*model(batch_ppt2)
            
            batch_pin_cpu=batch_pin.cpu()
            EP=V(batch_pin_cpu.detach().numpy())
            EP = torch.tensor(EP).cuda()
            
            ux = torch.autograd.grad(uin_out,batch_pin,torch.ones(uin_out.shape).cuda(),create_graph=True)[0]
    
            int_inl = (ux**2 + EP*uin_out**2).mean()
            int_innl = (0.5*beta*uin_out**4).mean()
            int_in2 = (upt_out1**2).mean()
            int_in3 = (upt_out2**2).mean()

            loss = int_inl/int_in2 + int_innl/(int_in2*int_in3) + gamma*(0.25*model(torch.tensor([0.5]).cuda())-1.)**2

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

    torch.save(model.state_dict(), '1d_schrodinger_ResNet 2 50.pth')
           
    tend=time.time()
    print("deel learning time",tend-tstart)
        
    points = np.arange(0, 1+h, h)
    x_input=torch.tensor(points).cuda()
    x_input=torch.reshape(x_input,[int(1/h)+1,1])
    x_input.requires_grad  = True
    uh=x_input*(1-x_input)*model(x_input)
    uhx=torch.autograd.grad(uh,x_input,torch.ones(uh.shape).cuda(),create_graph=True)[0]
    lam = ((uhx**2 + torch.tensor(VX(h)).cuda()*uh**2 + beta*uh**4).mean())/((uh**2).mean())
    print("lam:",lam)
   
    
#    uh = numericalvalue(h)
    uhcpu=uh.cpu()

    sio.savemat('eig_sol_2_50',mdict={'udl':uhcpu.detach().numpy()})
