function [lambda,fun,res] = hybric1(ne,a,b,u0)
ca=-1;
beta=10;

h=(b-a)/ne;
gauss=normpdf((0:h:0.5),0.25);
V=repmat(gauss(1,1:ne/2),[1,2]);
V=[V,gauss(1,ne/2+1)];

nnpe=2;
nn=(nnpe-1)*ne+1;
dofpn=1;
sdof=nn*dofpn;
[nodcoor,ean]=femmesh(ne,nn,a,b,nnpe);

ek=femek_P1(nodcoor,ean,ne,nnpe,ca);
K=femMatrix(ek,ne,sdof,nnpe);
K=fembcM_D(K,sdof);

em=femelm_P1(nodcoor,ean,ne,nnpe);
M=femMatrix(em,ne,sdof,nnpe);
M=fembcM_D(M,sdof);

evm=femevm_P1(nodcoor,ean,ne,nnpe,V);
VM=femMatrix(evm,ne,sdof,nnpe);
VM=fembcM_D(VM,sdof);

u0=normlize(u0,M);

enm=femenm_P1(nodcoor,ean,ne,nnpe,beta,u0);
NM=femMatrix(enm,ne,sdof,nnpe);
NM=fembcM_D(NM,sdof);

lam=(u0'*(K+VM+NM)*u0)/(u0'*M*u0);
disp(lam)

Res=zeros(11,1);
Res(1,1)=checkfem(K,VM,NM,M,lam,u0);
disp(Res(1,1));

o=0;
e=1;
eps=h^2;

while e > eps && o<10
    A=K+VM+NM;
    [U,L]=eig(A,M);
    uh=U(:,1);
    lam=L(1,1);
    e=MatrixError(uh,u0,M)/sqrt(u0'*M*u0);
    u0=normlize(uh,M);
    o=o+1;
    enm=femenm_P1(nodcoor,ean,ne,nnpe,beta,u0);
    NM=femMatrix(enm,ne,sdof,nnpe);
    NM=fembcM_D(NM,sdof);
    Res(o+1,1)=checkfem(K,VM,NM,M,lam,u0);
end
disp(o);

lambda=lam;
fun=normlize(uh,M);

Res=Res(1:o+1,1);
%disp(Res);
res=Res(o+1,1);
disp(lambda)

end

