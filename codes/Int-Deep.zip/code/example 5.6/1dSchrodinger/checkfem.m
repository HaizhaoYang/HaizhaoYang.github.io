function [res] = checkfem(K,VM,NM,M,lam,uh)
e=K*uh+VM*uh+NM*uh-lam*M*uh;
%res=sqrt(e'*M*e);
res=norm(e);
end

