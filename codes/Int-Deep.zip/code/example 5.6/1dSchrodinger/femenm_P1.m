function [ enm ] = femenm_P1(nodcoor,ean,ne,nnpe,beta,u0)
enm=zeros(nnpe*ne,nnpe);
for i=1:1:ne
    nl=ean(i,1);
    nr=ean(i,2);
    xl=nodcoor(nl);
    xr=nodcoor(nr);
    ul=u0(nl);
    ur=u0(nr);
    len=xr-xl;
    emc=zeros(2,2);    
    
    emc(1,1)=ul^2*len/4+ur^2*len/12;
    emc(1,2)=ul^2*len/12+ur^2*len/12;
    emc(2,1)=ul^2*len/12+ur^2*len/12;
    emc(2,2)=ul^2*len/12+ur^2*len/4;
    
    emc=emc*beta;
    iesi=nnpe*(i-1);
    enm(iesi+1:nnpe*i,1:nnpe)=emc;
end
end
