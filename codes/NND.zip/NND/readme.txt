These codes are for the implementation of the deflation method solving PDEs with multiple solutions.

Files to be run:

main_Painleve.py: the main script to implement least square method to solve the Painleve's equation in the paper, getting the first solution;

main_Painleve_deflation.py: the main script to implement the deflation method to solve the Painleve's equation in the paper, getting new solutions; (Note: need to input the ID of the old solutions to be deflated in Line 107)