import tensorflow as tf
import numpy as np

def identity_block(input_tensor, kernel_size, filters, stage, block):
		"""
		The identity block has no conv layer at shortcut

		# Inputs
			input_tensor: input tensor
			kernel_size: default 3, is the size of the kernel
			filters: list of integers, for the channels of 3 conv layer at main path
			stage: integer, is the stage label, for name generating
			block: 'a', 'b', ..., is the current block label for generating layer names

		# Returns
			Output tensor for the block
		"""

		filters1, filters2, filters3 = filters
		
		# Block 1
		x = tf.keras.layers.Conv2D(filters1, (1,1))(input_tensor)
		x = tf.keras.layers.LeakyReLU()(x)
		x = tf.layers.BatchNormalization()(x)
		
		# Block 2
		x = tf.keras.layers.Conv2D(filters2, kernel_size, padding='same')(x)
	    x = tf.keras.layers.LeakyReLU()(x)
		x = tf.layers.BatchNormalization()(x)

		# Block 3
		x = tf.keras.layers.Conv2D(filters3, (1,1))(x)
	    x = tf.keras.layers.LeakyReLU()(x)
	    x = tf.layers.BatchNormalization()(x)
		
		x = tf.keras.layers.add([x, input_tensor])
		x = tf.keras.layers.Activation('relu')(x)

		return x

def conv_block(input_tensor, kernel_size, filters, stage, block, strides=(2, 2)):
		"""
		The block with a conv layer at shortcut

		"""
		
		filters1, filters2, filters3 = filters

		# Block 1
	    x = tf.keras.layers.Conv2D(filters1, (1,1), strides=strides)(input_tensor)
	    x = tf.keras.layers.LeakyReLU()(x)
	    x = tf.layers.BatchNormalization()(x)

	    # Block 2
	    x = tf.keras.layers.Conv2D(filters2, kernel_size, padding='same')(x)
	    x = tf.keras.layers.LeakyReLU()(x)
	    x = tf.layers.BatchNormalization()(x)

	    # Block 3
	    x = tf.keras.layers.Conv2D(filters3, (1,1))(x)
	    x = tf.keras.layers.LeakyReLU()(x)
	    x = tf.layers.BatchNormalization()(x)

		# Conv at Shortcut
		shortcut = tf.keras.layers.Conv2D(filters3, (1,1), strides=strides)(input_tensor)
		shortcut = tf.keras.layers.LeakyReLU()(shortcut)
		shortcut = tf.layers.BatchNormalization()(shortcut)

	    x = tf.keras.layers.add([x, shortcut])
	    x = tf.keras.layers.Activation('relu')(x)

	    return x

def conv_transpose_block(input_tensor, kernel_size, filters, stage, block, strides=(2, 2)):
        """
        The block with a conv layer at shortcut

        """

        filters1, filters2, filters3 = filters

        # Block 1
        x = tf.keras.layers.Conv2DTranspose(filters1, (1,1), strides=strides)(input_tensor)
        x = tf.keras.layers.LeakyReLU()(x)
        x = tf.layers.BatchNormalization()(x)

        # Block 2
        x = tf.keras.layers.Conv2DTranspose(filters2, kernel_size, padding='same')(x)
        x = tf.keras.layers.LeakyReLU()(x)
		x = tf.layers.BatchNormalization()(x)

        # Block 3
        x = tf.keras.layers.Conv2DTranspose(filters3, (1,1))(x)
        x = tf.keras.layers.LeakyReLU()(x)
        x = tf.layers.BatchNormalization()(x)

        # Conv at Shortcut
        shortcut = tf.keras.layers.Conv2DTranspose(filters3, (1,1), strides=strides)(input_tensor)
		shortcut = tf.keras.layers.LeakyReLU()(shortcut)
        shortcut = tf.layers.BatchNormalization()(shortcut)

        x = tf.keras.layers.add([x, shortcut])
        x = tf.keras.layers.Activation('relu')(x)

        return x

### Update the shapes accordingly
VECTOR_LEN = 8514
INPUT_SHAPE = [-1, 258, 33, 1]

def decoder(input, output, scope):
	with tf.variable_scope(scope, reuse=tf.AUTO_REUSE):
		# Define the model
       		# Convolution Layer 1
		print(scope)
		print(input.shape)
		x = conv_transpose_block(input, 3, [128, 128, 64], stage=1, block='a', strides=(2,2))
		
		print(x.shape)
        	# Convolution Layer 2
		x = conv_transpose_block(x, 3, [64, 64, 32], stage=2, block='a', strides=(2,2))
		
		print(x.shape)
		# Convolution Layer 3
		x = conv_transpose_block(x, 3, [32, 32, 1], stage=3, block='a', strides=(2,2))
		
		print(x.shape)
		x = tf.reshape(x, shape=[-1, 10560])
		x = tf.layers.dense(x, output)

		print(x.shape)

    return x

def encoder(input, scope):
    with tf.variable_scope(scope, reuse=tf.AUTO_REUSE):
        # Define the model
		print(scope)
		print(input.shape)
		x = tf.reshape(input, shape=INPUT_SHAPE)
		
		print(x.shape)
        # Convolution Layer 1
        x = conv_block(x, 3, [16, 16, 32], stage=1, block='a', strides=(2,2))
		
		print(x.shape)
    	# Convolution Layer 2
        x = conv_block(x, 3, [32, 32, 64], stage=2, block='a', strides=(2,2))

		print(x.shape)
        # Convolution Layer 3
        x = conv_block(x, 3, [64, 64, 128], stage=3, block='a', strides=(2,2))

		print(x.shape)

    return x

def discriminator(input, scope):
    with tf.variable_scope(scope, reuse=tf.AUTO_REUSE):
        # Define the model
		print(scope)
		print(input.shape)
        x = tf.reshape(input, shape=INPUT_SHAPE)
		
		print(x.shape)
        # Convolution Layer 1
        x = conv_block(x, 3, [16, 16, 32], stage=1, block='a', strides=(2,2))
		
		print(x.shape)
        # Convolution Layer 2
        x = conv_block(x, 3, [32, 32, 64], stage=2, block='a', strides=(2,2))

		print(x.shape)
        # Convolution Layer 3
        x = conv_block(x, 3, [64, 64, 128], stage=3, block='a', strides=(2,2))
		
		print(x.shape)
		x = tf.reshape(x, shape= [-1, 33 * 5 * 128])
		x = tf.layers.dense(x, 1)
		x = tf.keras.layers.Activation('sigmoid')(x)
        	
		print(x.shape)

	return x
