## This README describes the included files

main_XXX.py contains the main files used for training Baseline AE (ae), CASS (aae) and CASS with Cross Adversarial Training (aae_c).

It is supported using helper python file trains_XXX.py respectively, and models/blocks_small.py contains the model design used for the Encoder, Decoder and Discriminator

samples folder will be where the training and testing data is included. Files are labelled according to:

Audio Signal:

mix_s.npy -> Training Input Mixture signal
bass_s.npy -> Training Bass component signal
sax_s.npy -> Training Sax component signal

stft_mix_s.npy -> Training Input Mixture signal (STFT)
stft_bass_s.npy -> Training Bass component signal (STFT)
stft_sax_s.npy -> Training Sax component signal (STFT)

mix_test_s.npy -> Testing Input Mixture signal
bass_test_s.npy -> Testing Bass component signal
sax_test_s.npy -> Testing Sax component signal

stft_mix_test_s.npy -> Testing Input Mixture signal (STFT)
stft_bass_test_s.npy -> Testing Bass component signal (STFT)
stft_sax_test_s.npy -> Testing Sax component signal (STFT)

#######

Usage Instructions:

ensure requirements are installed according to requirements.txt

run main_XXX.py

#######
