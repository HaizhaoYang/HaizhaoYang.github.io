import tensorflow as tf
import numpy as np
from models import blocks_small as M

### Loss Functions ###
def MSELoss(prediction, true):
	return tf.losses.mean_squared_error(true, prediction, weights=0.9)

def BCELoss(prediction, true, weights=1.0):
	return tf.losses.sigmoid_cross_entropy(prediction, true, weights=weights)

def real_data_target(size):
	return tf.ones(size)

def fake_data_target(size):
	return tf.zeros(size)

### Create Network ###
def make_adversarial_autoencoder(num_networks, decodersize, encoderscopes, decoderscopes, discriminatorscopes, learning_rate):
	placeholder_x = []
	placeholder_y = []
	placeholder_z = []
	encoders = []
	decoders = []
	discriminators = []
	discriminators_ = []
	enc_losses = []
	disc_real_losses = []
	e_optimizers = []
	d_real_optimizers = []

	for i in range(num_networks):
		X = tf.placeholder("float32", [None, decodersize])
		Y = tf.placeholder("float32", [None, decodersize])
		Z = tf.placeholder("float32", [None, decodersize])
		
		enc = M.encoder(X, encoderscopes[i])
		dec = M.decoder(enc, decodersize, decoderscopes[i])
		disc = M.discriminator(Z, discriminatorscopes[i])
		disc_ = M.discriminator(dec, discriminatorscopes[i])

		encoder_variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=encoderscopes[i])
		decoder_variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=decoderscopes[i])
		discriminator_variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=discriminatorscopes[i])

		# Train Encoder
		enc_loss = MSELoss(dec, Y)
		gen_loss = BCELoss(disc_, real_data_target(tf.shape(disc_)), weights=0.1)
		enc_loss_op = tf.reduce_mean(enc_loss+gen_loss)
		e_optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
		e_train_op = e_optimizer.minimize(enc_loss_op,
        		                        var_list=encoder_variables+decoder_variables)

		# Train Discriminator for real_data
		disc_real_loss = BCELoss(disc, real_data_target(tf.shape(disc)), weights=0.5)
		disc_fake_loss = BCELoss(disc_, fake_data_target(tf.shape(disc_)), weights=0.5)
		disc_real_loss_op = tf.reduce_mean(disc_real_loss+disc_fake_loss)
		d_real_optimizer = tf.train.AdamOptimizer(learning_rate=0.1*learning_rate)
		d_real_train_op = d_real_optimizer.minimize(disc_real_loss_op,
        		                        var_list=discriminator_variables)

		encoders.append(enc)
		decoders.append(dec)
		discriminators.append(disc)
		discriminators_.append(disc_)

		enc_losses.append(enc_loss_op)
		disc_real_losses.append(disc_real_loss_op)

		e_optimizers.append(e_train_op)
		d_real_optimizers.append(d_real_train_op)

		placeholder_x.append(X)
		placeholder_y.append(Y)
		placeholder_z.append(Z)

	return encoders, decoders, discriminators, discriminators_, enc_losses, disc_real_losses, e_optimizers, d_real_optimizers, placeholder_x, placeholder_y, placeholder_z

 
