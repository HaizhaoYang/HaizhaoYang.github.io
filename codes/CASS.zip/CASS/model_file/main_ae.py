### Our Dataset Class
import tensorflow as tf
import numpy as np
from models import blocks_small as M
import trains_ae as T

print("==== Load the data files =====")

mix = np.float32(np.load('./samples/mix_s.npy'))
bass = np.float32(np.load('./samples/bass_s.npy'))
sax = np.float32(np.load('./samples/sax_s.npy'))

stft_mix = np.float32(np.load('./samples/stft_mix_s.npy'))
stft_bass = np.float32(np.load('./samples/stft_bass_s.npy'))
stft_sax = np.float32(np.load('./samples/stft_sax_s.npy'))

mix_test = np.float32(np.load('./samples/mix_test_s.npy'))
bass_test = np.float32(np.load('./samples/bass_test_s.npy'))
sax_test = np.float32(np.load('./samples/sax_test_s.npy'))

stft_mix_test = np.float32(np.load('./samples/stft_mix_test_s.npy'))
stft_bass_test = np.float32(np.load('./samples/stft_bass_test_s.npy'))
stft_sax_test = np.float32(np.load('./samples/stft_sax_test_s.npy'))

ACTUAL_SHAPE = (258, 33)
VECTOR_LEN = 8514
BATCH_SIZE = 50
EPOCH = 50000
NUM_NETWORKS = 2

print("===== Data files loaded successfully =====")

print("===== Creating dataset =====")
dataset = tf.data.Dataset.range(mix.shape[0]).repeat().batch(BATCH_SIZE)

iter = dataset.make_one_shot_iterator()

INDEX = iter.get_next()

print("===== Setting up Neural Network =====")

encoderscopes = ['Encoder_1', 'Encoder_2']
decoderscopes = ['Decoder_1', 'Decoder_2']
learning_rate = tf.placeholder("float32", shape=())

encoders, decoders, enc_losses, e_optimizers, placeholder_x, placeholder_y = T.make_autoencoder(NUM_NETWORKS, VECTOR_LEN, encoderscopes, decoderscopes, learning_rate)

saver = tf.train.Saver(tf.trainable_variables())

print("===== Begin Training =====")

with tf.Session() as sess:
	devices = sess.list_devices()
	print("===== Available Devices =====")
	print(devices)
	sess.run(tf.global_variables_initializer())	

	error1 = []
	error2 = []		

	t_error1 = []
	t_error2 = []

	train_error1 = []
	train_error2 = []

	# Restore save points
        saver.restore(sess, "./results/ae/AEModel.ckpt")
        train_error1 = np.load("./results/ae/t_bass_error.npy").tolist()
        train_error2 = np.load("./results/ae/t_sax_error.npy").tolist()
        error1 = np.load("./results/ae/bass_error.npy").tolist()
        error2 = np.load("./results/ae/sax_error.npy").tolist()
        t_error1 = np.load("./results/ae/e_bass_error.npy").tolist()
        t_error2 = np.load("./results/ae/e_sax_error.npy").tolist()

	lr = 0.00001

	for i in range(EPOCH+1):
		index = INDEX.eval()

                x = stft_mix[index]
                y = stft_bass[index]
                z = stft_sax[index]

                # Train Encoder
                b_error1, _ = sess.run([enc_losses[0], e_optimizers[0]], feed_dict={placeholder_x[0]: x, placeholder_y[0]: y, learning_rate: lr})
                b_error2, _ = sess.run([enc_losses[1], e_optimizers[1]], feed_dict={placeholder_x[1]: x, placeholder_y[1]: z, learning_rate: lr})
	
		if i % 100 == 0:
			#lr *= 0.999

			results_b = sess.run(decoders[0], feed_dict={placeholder_x[0]: stft_mix_test})
	
			results_s = sess.run(decoders[1], feed_dict={placeholder_x[1]: stft_mix_test})
			
			train_results_b = sess.run(decoders[0], feed_dict={placeholder_x[0]: stft_mix[:1000]})

                        train_results_s = sess.run(decoders[1], feed_dict={placeholder_x[1]: stft_mix[:1000]})

			np.save("./results/ae/train_bass_result", train_results_b)
                        np.save("./results/ae/train_sax_result", train_results_s)

			# Compute the error
			b_result = []
			s_result = []

			for i in range(stft_bass_test.shape[0]):
				b_result.append(np.linalg.norm(stft_bass_test[i]-results_b[i], ord=2))
				s_result.append(np.linalg.norm(stft_sax_test[i]-results_s[i], ord=2))

			b_error = np.average(np.array(b_result))
			s_error = np.average(np.array(s_result))

			error1.append(b_error)
			error2.append(s_error)

			b_t_result = []
                        s_t_result = []

                        for i in range(stft_mix[:1000].shape[0]):
                                b_t_result.append(np.linalg.norm(stft_bass[i]-train_results_b[i], ord=2))
                                s_t_result.append(np.linalg.norm(stft_sax[i]-train_results_s[i], ord=2))

                        b_t_error = np.average(np.array(b_t_result))
                        s_t_error = np.average(np.array(s_t_result))

                        train_error1.append(b_t_error)
                        train_error2.append(s_t_error)

			np.save("./results/ae/t_bass_error", np.array(train_error1))
                        np.save("./results/ae/t_sax_error", np.array(train_error2))

			t_error1.append(b_error1)
			t_error2.append(b_error2)

			np.save("./results/ae/bass_result", results_b)
			np.save("./results/ae/sax_result", results_s)
			
			np.save("./results/ae/bass_error", np.array(error1))
			np.save("./results/ae/sax_error", np.array(error2))

			np.save("./results/ae/e_bass_error", np.array(t_error1))
                        np.save("./results/ae/e_sax_error", np.array(t_error2))
			
			saver.save(sess, "./results/ae/AEModel.ckpt")

		print("Epoch: ", i)
		print(b_error, s_error)
	
