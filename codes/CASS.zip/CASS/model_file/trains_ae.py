import tensorflow as tf
import numpy as np
from models import blocks_small as M

### Loss Functions ###
def MSELoss(prediction, true):
	return tf.pow(prediction - true, 2)

def BCELoss(prediction, true):
	return tf.losses.sigmoid_cross_entropy(prediction, true)

def real_data_target(size):
	return tf.ones(size)

def fake_data_target(size):
	return tf.zeros(size)

### Create Network ###
def make_autoencoder(num_networks, decodersize, encoderscopes, decoderscopes, learning_rate):
	placeholder_x = []
	placeholder_y = []
	encoders = []
	decoders = []
	enc_losses = []
	e_optimizers = []

	for i in range(num_networks):
		X = tf.placeholder("float32", [None, decodersize])
		Y = tf.placeholder("float32", [None, decodersize])
		
		enc = M.encoder(X, encoderscopes[i])
		dec = M.decoder(enc, decodersize, decoderscopes[i])

		encoder_variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=encoderscopes[i])
		decoder_variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=decoderscopes[i])

		# Train Encoder
		enc_loss = MSELoss(dec, Y)
		enc_loss_op = tf.reduce_mean(enc_loss)
		e_optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
		e_train_op = e_optimizer.minimize(enc_loss_op,
        		                        var_list=encoder_variables+decoder_variables)

		encoders.append(enc)
		decoders.append(dec)

		enc_losses.append(enc_loss_op)

		e_optimizers.append(e_train_op)

		placeholder_x.append(X)
		placeholder_y.append(Y)

	return encoders, decoders, enc_losses, e_optimizers, placeholder_x, placeholder_y

 
