This Folder includes code to generate sample data for training and testing.

####### USAGE

Audio:

1) Download Bach 10 dataset and unzip in directory Audio\

2) Modify parameters at gen_train_samples.py, gen_test_samples.py to select the song folders to generate train and test samples.

3) Run both files.

4) To use the dataset, place the files in model folder samples, make sure names of files correspond accordingly to the README and main_XXX.py

ECG:

1) Follow Generate Samples.ipynb

2) To use the dataset, place the files in model folder samples, make sure names of files correspond accordingly to the README and main_XXX.py

