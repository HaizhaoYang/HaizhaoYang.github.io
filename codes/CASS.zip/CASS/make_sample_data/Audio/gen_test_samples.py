import soundfile as sf
import numpy as np
import os
import scipy.signal as signal

ROOT = os.getcwd()
NUM_SAMPLES = 1000
NUM_SAMPLES_PER = 1000
CHUNK = 4096 # 1 second = 44100 fs

## List the file names here, as well as update NUM_SAMPLES = total number, NUM_SAMPLES_PER = number of samples per music
FILE_NAME = ['01-AchGottundHerr']

train = []

## Read file
def readfile(root, folder_name, file_name):
    FILE = root + '/Bach10_v1.1/' + folder_name + '/' + file_name +'.wav'
    return sf.read(FILE, dtype='float32')

## Helper functions
def pre_process(data):
    return (data*500)+50*np.ones(shape=data.shape)

def post_process(data):
    return (data-50*np.ones(shape=data.shape))/500

def generate_training_samples(num_samples_per):
    mix = []
    bass = []
    sax = []    
    for i in range(len(FILE_NAME)):
        
        # Read the file
        print('Reading file ', FILE_NAME[i])
        #mix_data, mix_fs = readfile(ROOT, FILE_NAME[i], FILE_NAME[i])
        bass_data, bass_fs = readfile(ROOT, FILE_NAME[i], FILE_NAME[i] + '-bassoon')
        #clar_data, clar_fs = readfile(ROOT, FILE_NAME[i], FILE_NAME[i] + '-clarinet')
        sax_data, sax_fs = readfile(ROOT, FILE_NAME[i], FILE_NAME[i] + '-saxphone')
        #vio_data, vio_fs = readfile(ROOT, FILE_NAME[i], FILE_NAME[i] + '-violin')
        mix_data = 0.5*(bass_data + sax_data)
        
        start_points = np.random.randint(0, high=mix_data.shape[0]-CHUNK, size=num_samples_per)
        
        for j in start_points:
            mix.append(pre_process(mix_data[j:j+CHUNK]))
            bass.append(pre_process(bass_data[j:j+CHUNK]))
            sax.append(pre_process(sax_data[j:j+CHUNK]))
    return np.array(mix), np.array(bass), np.array(sax)

print('Generating Testing Samples')

mix, bass, sax = generate_training_samples(NUM_SAMPLES_PER)

np.save('mix_test_s',mix)
np.save('bass_test_s',bass)
np.save('sax_test_s',sax)

def short_time_fourier_transform(v):
    ft = np.array(signal.stft(v,fs=500)[2])
    r_ft = np.zeros(ft.shape)
    i_ft = np.zeros(ft.shape)
    for j in range(len(r_ft)):
        for k in range(len(r_ft[j])):
            r_ft[j][k] = ft[j][k].real
            i_ft[j][k] = ft[j][k].imag
    ft = np.concatenate((r_ft,i_ft))
    return np.reshape(ft,ft.shape[0]*ft.shape[1]), ft.shape

print("===== Load the files =====")

stft_mix = []
stft_bass = []
stft_sax = []

shape = 0
print("===== Begin Generating Dataset =====")
for i in range(NUM_SAMPLES):

    temp_mix, shape = short_time_fourier_transform(mix[i])
    temp_bass, _ = short_time_fourier_transform(bass[i])
    temp_sax, _ = short_time_fourier_transform(sax[i])

    stft_mix.append(temp_mix)
    stft_bass.append(temp_bass)
    stft_sax.append(temp_sax)

stft_mix = np.array(stft_mix)
stft_bass = np.array(stft_bass)
stft_sax = np.array(stft_sax)

np.save('stft_mix_test_s',stft_mix)
np.save('stft_bass_test_s',stft_bass)
np.save('stft_sax_test_s',stft_sax)


print("===== Finished Loading files =====")

print("Actual Shape: ", shape)
print("Vector Length: ", stft_mix[0].shape[0])

ACTUAL_SHAPE = shape
VECTOR_LEN = stft_mix[0].shape[0]

print("Complete!")
