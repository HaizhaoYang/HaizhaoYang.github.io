These codes are for the implementation of SelectNet method solving PDEs.

Files to be run:

main_6_2_1.py: the main script to implement SelectNet and basic models to solve the problem in Section 6.2.1 in the paper.
