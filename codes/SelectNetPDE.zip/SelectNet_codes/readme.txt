These codes are for the implementation of SelectNet method solving PDEs.

Files to be run:

1.main.py: the main script to implement SelectNet and basic models
change the "problem" information in Line 19 for different cases, where
problem_6_1_1 is for Section 6.1.1 in the paper,
problem_6_1_2 is for Section 6.1.2 in the paper,
problem_6_2_1 is for Section 6.2.1 in the paper,
problem_6_2_2 is for Section 6.2.2 in the paper,
problem_6_3 is for Section 6.3 in the paper.

2.main_01_weighting: the main script to implement the 0-1 weighting method
(this is used in Section 6.1.1)

3.handle_data.py: the plot error and loss curves
(input the result IDs in Line 12 and 19)
