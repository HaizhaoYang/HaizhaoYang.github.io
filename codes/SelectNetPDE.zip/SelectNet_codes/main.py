# the main codes for the residual method to solve PDEs

import torch
from torch import Tensor, optim
import numpy
from numpy import zeros, sum, sqrt, linspace, absolute
from useful_tools import generate_uniform_points_in_cube, generate_uniform_points_in_cube_time_dependent,\
    generate_uniform_points_on_cube, generate_uniform_points_on_cube_time_dependent,\
    generate_uniform_points_in_sphere, generate_uniform_points_in_sphere_time_dependent,\
    generate_uniform_points_on_sphere, generate_uniform_points_on_sphere_time_dependent,\
    generate_uniform_annular_points_in_sphere_time_dependent, generate_uniform_annular_points_on_sphere_time_dependent,\
    generate_uniform_annular_points_in_sphere, generate_learning_rates
import network_setting 
import SelectNet_setting 
from matplotlib.pyplot import plot, show, clf, pause, semilogy, title, xlabel, subplot, xlim, ylim, figure
import pickle
import time

from problem_6_1_2 import spatial_dimension, true_solution, if_true_solution_given, Du, Du_ft, Bu_ft, f, g, h0, h1, domain_shape, domain_parameter, time_dependent_type, time_interval, FD_step

TensorType = 'Double'
torch.manual_seed(1) 
numpy.random.seed(1)
if TensorType == 'Double':
    torch.set_default_tensor_type('torch.cuda.DoubleTensor')
elif TensorType == 'Float':
    torch.set_default_tensor_type('torch.cuda.FloatTensor')

########### Set parameters #############
method = 'S' # choose methods: B(basic), S(SelectNet), RS (reversed SelectNet)
d = spatial_dimension()  # dimension of problem
L = 3 # depth of the solution network
m = 100  # number of nodes in each layer of solution network
n_epoch = 20000  # number of outer iterations
N_inside_train = 10000 # number of trainning sampling points inside the domain in each epoch (batch size)
n_update_each_batch = 1 # number of iterations in each epoch (for the same batch of points)
lrseq = generate_learning_rates(-3,-6,n_epoch,0.999,1000)

lambda_term = 1
if method == 'S' or method == 'RS':
    m_sn = 20   #number of nodes in each layer of the selection network
    penalty_parameter = 0.01
    maxvalue_sn = 5  # upper bound for the selection net
    minvalue_sn = 0.8  # lower bound for the selection net
    lr_sn = 0.0001  # learning rate for the selection net
    n_update_each_batch_sn = 1
    loss_sn1_threshold = 1e-8  # stopping criteria for training the selection net1 (inside the domain)
    loss_sn2_threshold = 1e-8  # stopping criteria for training the selection net2 (boudanry or initial)
    selectnet_initial_constant = 1.0  # if selectnet is initialized as constant one
activation = 'ReLU3'  # activation function for the solution net
boundary_control = 'homo_unit_sphere'  # if the solution net architecture satisfies the boundary condition automatically 
initial_control = 'none'  # if the solution net architecture satisfies the initial condition automatically 
h_Du_t = FD_step()  # time length for computing the first derivative of t by finite difference (for the hyperbolic equations)
initial_constant = 'none' # initial value for the solution network
flag_preiteration_by_small_lr = False  # If pre iteration by small learning rates
lr_pre = 1e-3
n_update_each_batch_pre = 1
loss_type = 'residual' # 'residual' for least square residual and 'Ritz' for Ritz energy functional
sphere_sampling_type = 'uniform_annular' # 'uniform', 'uniform_annular' 
test_type = 'uniform_annular' # 'uniform', 'uniform_annular' 

########### Problem parameters   #############
FD_step = FD_step()
time_dependent_type = time_dependent_type()   ## If this is a time-dependent problem
domain_shape = domain_shape()  ## the shape of domain 
if domain_shape == 'cube':  
    domain_intervals = domain_parameter(d)
    R = []
elif domain_shape == 'sphere':
    R = domain_parameter(d)
    domain_intervals = []
if not time_dependent_type == 'none':    
    time_interval = time_interval()
    T0 = time_interval[0]
    T1 = time_interval[1]
else: 
    time_interval = []
    T0 = []
    T1 = []
    
########### Interface parameters #############
flag_compute_loss_each_epoch = True # if compute loss after each epoch
n_epoch_show_info = max([round(n_epoch/50),1]) # how many epoch will it show information
flag_show_plot = False # if show plot during the training
flag_output_results = True # if save the results as files in current directory
if method == 'S' or method == 'RS':
    flag_show_sn_info = False
flag_temp_save = False

if if_true_solution_given() == True: # if we need to compute the error
    N_test = 10000 # number of testing points
    flag_l2error = True
    flag_maxerror = False
    flag_givenpts_l2error = True
    flag_givenpts_maxerror = False
    if flag_givenpts_l2error == True or flag_givenpts_maxerror == True:
        if time_dependent_type == 'none':
            given_pts = generate_uniform_points_in_sphere(d,0.1,10000)
            givenpts_info = 'given_pts = generate_uniform_points_in_sphere(d,0.1,10000)'
        else:
            given_pts = zeros((1,d+1))
    
    
########### Depending parameters #############
if method == 'B':
    if time_dependent_type == 'none':
        u_net = network_setting.network(d, m, L, activation_type = activation, boundary_control_type = boundary_control, initial_constant = initial_constant)
    else:
        u_net = network_setting.network_time_depedent(d, m, L, activation_type = activation, boundary_control_type = boundary_control, initial_constant = initial_constant)
if method == 'S' or method == 'RS':
    if time_dependent_type == 'none':
        u_net = SelectNet_setting.network(d, m, L, activation_type = activation, boundary_control_type = boundary_control, initial_constant = initial_constant)
    else:
        u_net = SelectNet_setting.network_time_depedent(d, m, L, activation_type = activation, boundary_control_type = boundary_control, initial_constant = initial_constant)
    if time_dependent_type == 'none':
        select_net1 = SelectNet_setting.selection_network(d,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant) # selection_network inside the domain
        select_net2 = SelectNet_setting.selection_network(d,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant)  # selection_network for initial and boudanry conditions
    else:
        select_net1 = SelectNet_setting.selection_network(d+1,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant)  # selection_network for initial and boudanry conditions
        select_net2 = SelectNet_setting.selection_network(d+1,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant)  # selection_network for initial and boudanry conditions

if u_net.if_boundary_controlled == False:
    flag_boundary_term_in_loss = True  # if loss function has the boundary residual
else:
    flag_boundary_term_in_loss = False
if time_dependent_type == 'none':
    flag_initial_term_in_loss = False  # if loss function has the initial residual
else:
    if u_net.if_initial_controlled == False:
        flag_initial_term_in_loss = True
    else:
        flag_initial_term_in_loss = False
if flag_boundary_term_in_loss == True or flag_initial_term_in_loss == True:
    flag_IBC_in_loss = True  # if loss function has the boundary/initial residual
    N_IBC_train = 0  # number of boundary and initial training points
else:
    flag_IBC_in_loss = False
if flag_boundary_term_in_loss == True:
    if domain_shape == 'cube':
        if d == 1 and time_dependent_type == 'none':
            N_each_face_train = 1
        else:
            N_each_face_train = max([1,int(round(N_inside_train/2/d))]) # number of sampling points on each domain face when training
        N_boundary_train = 2*d*N_each_face_train
    elif domain_shape == 'sphere':
        if d == 1 and time_dependent_type == 'none':
            N_boundary_train = 2
        else:
            N_boundary_train = N_inside_train # number of sampling points on each domain face when training
    N_IBC_train = N_IBC_train + N_boundary_train
else:
    N_each_face_train = 0
    N_boundary_train = 0
if flag_initial_term_in_loss == True:          
    N_initial_train = max([1,int(round(N_inside_train/d))]) # number of sampling points on each domain face when training
    N_IBC_train = N_IBC_train + N_initial_train

if not time_dependent_type == 'none':   
    def Du_t_ft(model, tensor_x_batch):
        h = 0.01 # step length ot compute derivative
        s = torch.zeros(tensor_x_batch.shape[0])
        ei = torch.zeros(tensor_x_batch.shape)
        ei[:,0] = 1
        s = (3*model(tensor_x_batch+2*h*ei)-4*model(tensor_x_batch+h*ei)+model(tensor_x_batch))/2/h
        return s
    
#################### Start ######################
optimizer = optim.Adam(u_net.parameters(),lr=lrseq[0])
if method == 'S' or method == 'RS':
    optimizer_sn1 = optim.Adam(select_net1.parameters(),lr=lr_sn)
    if flag_IBC_in_loss == True:
        optimizer_sn2 = optim.Adam(select_net2.parameters(),lr=lr_sn)

lossseq = zeros((n_epoch,))
resseq = zeros((n_epoch,))
l2errorseq = zeros((n_epoch,))
maxerrorseq = zeros((n_epoch,))
givenpts_l2errorseq = zeros((n_epoch,))
givenpts_maxerrorseq = zeros((n_epoch,))

if if_true_solution_given() == True:
    if time_dependent_type == 'none':
        if domain_shape == 'cube':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_cube(domain_intervals,N_test)    
        elif domain_shape == 'sphere':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_sphere(d,R,N_test)  
            elif test_type == 'uniform_annular':
                x_test = generate_uniform_annular_points_in_sphere(d,R,10,round(N_test/10))
    else:
        if domain_shape == 'cube':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_cube_time_dependent(domain_intervals,time_interval,N_test) 
        elif domain_shape == 'sphere':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_sphere_time_dependent(d,R,time_interval,N_test)
            elif test_type == 'uniform_annular':
                x_test = generate_uniform_annular_points_in_sphere_time_dependent(d,R,time_interval,10,round(N_test/10))

############ Precomputation ############
if if_true_solution_given() == True:
    if flag_l2error == True:
        u_x_test = true_solution(x_test)
        u_l2norm_x_test = sqrt(sum(u_x_test**2)/x_test.shape[0])
    if flag_maxerror == True:
        u_x_test = true_solution(x_test)
        u_maxnorm_x_test = numpy.max(absolute(u_x_test))
    if flag_givenpts_l2error == True:
        u_givenpts = true_solution(given_pts)
        u_l2norm_givenpts = sqrt(sum(u_givenpts**2)/given_pts.shape[0])
    if flag_givenpts_maxerror == True:
        u_givenpts = true_solution(given_pts)
        u_maxnorm_givenpts = numpy.max(absolute(u_givenpts))       
           
############ Plot ###############
if flag_show_plot == True:
    figure(figsize=(10,5))
    N_plot = 1000
    if time_dependent_type == 'none':
        x_plot = zeros((N_plot,d))
        if domain_shape == 'cube':
            x_plot[:,0] = linspace(domain_intervals[0,0],domain_intervals[0,1],N_plot)
        elif domain_shape == 'sphere':
            x_plot[:,0] = linspace(-R,R,N_plot)
    else:
        x_plot = zeros((N_plot,d+1))
        x_plot[:,0] = linspace(T0,T1,N_plot)
    subplot(1,2,1)
    plot(x_plot[:,0],u_net.predict(x_plot),'r')
    if if_true_solution_given() == True:
        plot(x_plot[:,0],true_solution(x_plot),'b')
    title('Iteration: 0')
    xlabel('First component of plotting points')
    subplot(1,2,2)
    show()
    pause(1)
    
############ Local Time ###############    
localtime = time.localtime(time.time())
time_text = str(localtime.tm_mon)+'_'+str(localtime.tm_mday)+'_'+str(localtime.tm_hour)+'_'+str(localtime.tm_min)

# Training
k = 0       
while k < n_epoch:
    ## generate training and testing data (the shape is (N,d)) or (N,d+1) 
    ## label 1 is for the points inside the domain, 2 is for those on the bondary or at the initial time    
    if time_dependent_type == 'none':
        if domain_shape == 'cube':
            x1_train = generate_uniform_points_in_cube(domain_intervals,N_inside_train)
            if flag_IBC_in_loss == True:
                x2_train = generate_uniform_points_on_cube(domain_intervals,N_each_face_train)        
        elif domain_shape == 'sphere':
            if sphere_sampling_type == 'uniform':
                x1_train = generate_uniform_points_in_sphere(d,R,N_inside_train)
            elif sphere_sampling_type == 'uniform_annular':
                x1_train = generate_uniform_annular_points_in_sphere(d,R,10,round(N_inside_train/10))           
            if flag_IBC_in_loss == True:
                x2_train = generate_uniform_points_on_sphere(d,R,N_boundary_train)
    else:
        if domain_shape == 'cube':
            x1_train = generate_uniform_points_in_cube_time_dependent(domain_intervals,time_interval,N_inside_train)
            if flag_IBC_in_loss == True:
                # x2_train for boudanry samplings; x3_train for initial samplings
                x2_train, x3_train = generate_uniform_points_on_cube_time_dependent(domain_intervals,time_interval,N_each_face_train,N_initial_train)     
        elif domain_shape == 'sphere':
            if sphere_sampling_type == 'uniform':
                x1_train = generate_uniform_points_in_sphere_time_dependent(d,R,time_interval,N_inside_train)
            elif sphere_sampling_type == 'uniform_annular':
                x1_train = generate_uniform_annular_points_in_sphere_time_dependent(d,R,time_interval,10,round(N_inside_train/10))
            if flag_IBC_in_loss == True:
                # x2_train for boudanry samplings; x3_train for initial samplings
                if flag_boundary_term_in_loss == False:
                    if sphere_sampling_type == 'uniform':
                        [], x3_train = generate_uniform_points_on_sphere_time_dependent(d,R,time_interval,0,N_initial_train)
                    elif sphere_sampling_type == 'uniform_annular':
                        [], x3_train = generate_uniform_annular_points_on_sphere_time_dependent(d,R,time_interval,0,10,round(N_initial_train/10))
                elif flag_initial_term_in_loss == False:
                    if sphere_sampling_type == 'uniform':
                        x2_train, [] = generate_uniform_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,0)
                    elif sphere_sampling_type == 'uniform_annular':
                        x2_train, [] = generate_uniform_annular_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,0,0)
                else:
                    if sphere_sampling_type == 'uniform':
                        x2_train, x3_train = generate_uniform_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,N_initial_train)
                    elif sphere_sampling_type == 'uniform_annular':
                        x2_train, x3_train = generate_uniform_annular_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,10,round(N_initial_train/10))
        
    tensor_x1_train = Tensor(x1_train)
    tensor_x1_train.requires_grad=False
    tensor_f1_train = Tensor(f(x1_train))
    tensor_f1_train.requires_grad=False
    if flag_boundary_term_in_loss == True:
        tensor_x2_train = Tensor(x2_train)
        tensor_x2_train.requires_grad=False
        tensor_g2_train = Tensor(g(x2_train))
        tensor_g2_train.requires_grad=False
        
    if flag_initial_term_in_loss == True:
        tensor_x3_train = Tensor(x3_train)
        tensor_x3_train.requires_grad=False
        if time_dependent_type == 'parabolic' or time_dependent_type == 'hyperbolic':
            # h0 for u(x,0) = h0(x)
            tensor_h03_train = Tensor(h0(x3_train))
            tensor_h03_train.requires_grad=False
        if time_dependent_type == 'hyperbolic':
            # h1 for u_t(x,0) = h1(x)
            tensor_h13_train = Tensor(h1(x3_train))
            tensor_h13_train.requires_grad=False
           
    ## Set learning rate
    for param_group in optimizer.param_groups:
        if flag_preiteration_by_small_lr == True and k == 0:
            param_group['lr'] = lr_pre
        else:
            param_group['lr'] = lrseq[k]
        
    ## Train the selection net inside the domain
    if method == 'S' or method == 'RS':
        const_tensor_loss_term_x1_train = (Du_ft(u_net,tensor_x1_train)-tensor_f1_train)**2
        old_loss = 1e5
        for i_update_sn in range(n_update_each_batch_sn):
            ## Compute the loss  
            if method == 'S':
                loss_sn = -1/torch.sum(const_tensor_loss_term_x1_train)*torch.sum((select_net1(tensor_x1_train)*const_tensor_loss_term_x1_train)) + 1/penalty_parameter*(1/N_inside_train*torch.sum(select_net1(tensor_x1_train))-1).pow(2)
            elif method == 'RS':
                loss_sn = 1/torch.sum(const_tensor_loss_term_x1_train)*torch.sum((select_net1(tensor_x1_train)*const_tensor_loss_term_x1_train)) + 1/penalty_parameter*(1/N_inside_train*torch.sum(select_net1(tensor_x1_train))-1).pow(2)
            ## Show information
            if flag_show_sn_info == True:
                if i_update_sn%10 == 0:
                    print("select_net1: ",end='')
                    temp = (1/N_inside_train*torch.sum(select_net1(tensor_x1_train))-1).pow(2)
                    if method == 'S':
                       print("i_update_sn = %d, loss_sn = %6.3f, penalty term = %6.3f" %(i_update_sn,-loss_sn.item(),temp.item()))
                    elif method == 'RS':
                       print("i_update_sn = %d, loss_sn = %6.3f, penalty term = %6.3f" %(i_update_sn,loss_sn.item(),temp.item()))
            ## If loss_sn is stable, then break
            if abs(loss_sn.item()-old_loss)<loss_sn1_threshold:
                break
            old_loss = loss_sn.item()
            ## Update the network
            optimizer_sn1.zero_grad()
            loss_sn.backward(retain_graph=False)
            optimizer_sn1.step()
            
    ## Train the selection net on the boudnary or on the initial slice
    if method == 'S' or method == 'RS':
        if flag_IBC_in_loss == True:
            if flag_boundary_term_in_loss == True:
                const_tensor_residual_square_x2_train = (Bu_ft(u_net,tensor_x2_train)-tensor_g2_train)**2
            if flag_initial_term_in_loss == True:
                const_tensor_residual_square_x3_train = (u_net(tensor_x3_train)-tensor_h03_train)**2
            old_loss = 1e5
            for i_update_sn in range(n_update_each_batch_sn):
                ## Compute the loss  
                loss_sn = Tensor([0])
                tensor_IBC_sum_term = Tensor([0])
                if flag_boundary_term_in_loss == True:
                    if method == 'S':
                        loss_sn = loss_sn - 1/torch.sum(const_tensor_residual_square_x2_train)*torch.sum((select_net2(tensor_x2_train)*const_tensor_residual_square_x2_train)) 
                    elif method == 'RS':
                        loss_sn = loss_sn + 1/torch.sum(const_tensor_residual_square_x2_train)*torch.sum((select_net2(tensor_x2_train)*const_tensor_residual_square_x2_train))
                    tensor_IBC_sum_term = tensor_IBC_sum_term + torch.sum(select_net2(tensor_x2_train))
                if flag_initial_term_in_loss == True:
                    if method == 'S':
                        loss_sn = loss_sn - 1/torch.sum(const_tensor_residual_square_x3_train)*torch.sum((select_net2(tensor_x3_train)*const_tensor_residual_square_x3_train)) 
                    elif method == 'RS':
                        loss_sn = loss_sn + 1/torch.sum(const_tensor_residual_square_x3_train)*torch.sum((select_net2(tensor_x3_train)*const_tensor_residual_square_x3_train)) 
                    tensor_IBC_sum_term = tensor_IBC_sum_term + torch.sum(select_net2(tensor_x3_train))
                
                loss_sn = loss_sn + 1/penalty_parameter*(1/N_IBC_train*tensor_IBC_sum_term-1).pow(2)
                ## Show information
                if flag_show_sn_info == True:
                    if i_update_sn%10 == 0:
                        print("select_net2: ",end='')
                        temp = (1/N_IBC_train*tensor_IBC_sum_term-1).pow(2)
                        if method == 'S':
                           print("i_update_sn = %d, loss_sn = %6.3f, penalty term = %6.3f" %(i_update_sn,-loss_sn.item(),temp.item()))
                        elif method == 'RS':
                           print("i_update_sn = %d, loss_sn = %6.3f, penalty term = %6.3f" %(i_update_sn,loss_sn.item(),temp.item()))
                ## If loss_sn is stable, then break
                if abs(loss_sn.item()-old_loss)<loss_sn2_threshold:
                    break
                old_loss = loss_sn.item()
                ## Update the network
                optimizer_sn2.zero_grad()
                loss_sn.backward(retain_graph=True)
                optimizer_sn2.step()
        
    ## Train the solution net
    if method == 'S' or method == 'RS':
        const_tensor_sn_x1_train = select_net1(tensor_x1_train)
        if flag_boundary_term_in_loss == True:
            const_tensor_sn2_x2_train = select_net2(tensor_x2_train)
        if flag_initial_term_in_loss == True:
            const_tensor_sn2_x3_train = select_net2(tensor_x3_train)
            
    if flag_preiteration_by_small_lr == True and k == 0:
        temp = n_update_each_batch_pre
    else:
        temp = n_update_each_batch
    for i_update in range(temp):
        if flag_compute_loss_each_epoch == True or i_update == 0:
            ## Compute the loss  
            if method == 'B':
                loss1 = 1/N_inside_train*torch.sum((Du_ft(u_net,tensor_x1_train)-tensor_f1_train)**2)
            elif method == 'S' or method == 'RS':
                loss1 = 1/N_inside_train*torch.sum(const_tensor_sn_x1_train*(Du_ft(u_net,tensor_x1_train)-tensor_f1_train)**2)
            loss = loss1

            if flag_IBC_in_loss == True:
                loss2 = Tensor([0])
                if flag_boundary_term_in_loss == True:
                    if method == 'B':
                        loss2 = loss2 + torch.sum((Bu_ft(u_net,tensor_x2_train)-tensor_g2_train)**2)
                    elif method == 'S' or method == 'RS':
                        loss2 = loss2 + torch.sum(const_tensor_sn2_x2_train*(Bu_ft(u_net,tensor_x2_train)-tensor_g2_train)**2)
                if flag_initial_term_in_loss == True:
                    if method == 'B':
                        loss2 = loss2 + torch.sum((u_net(tensor_x3_train)-tensor_h03_train)**2)
                    elif method == 'S' or method == 'RS':
                        loss2 = loss2 + torch.sum(const_tensor_sn2_x3_train*(u_net(tensor_x3_train)-tensor_h03_train)**2)
                    if time_dependent_type == 'hyperbolic':
                            loss2 = loss2 + torch.sum((Du_t_ft(u_net,tensor_x3_train)-tensor_h13_train)**2)
                loss2 = lambda_term/N_IBC_train*loss2
                loss = loss1 + loss2

        ## Update the network
        optimizer.zero_grad()
        loss.backward(retain_graph=not flag_compute_loss_each_epoch)
        optimizer.step()
            
    # Save loss and L2 error
    lossseq[k] = loss.item()
    if if_true_solution_given() == True:
        if flag_l2error == True:
            l2error = sqrt(sum((u_net.predict(x_test) - u_x_test)**2)/x_test.shape[0])/u_l2norm_x_test
            l2errorseq[k] = l2error
        if flag_maxerror == True:
            maxerror = numpy.max(absolute(u_net.predict(x_test) -u_x_test))/u_maxnorm_x_test
            maxerrorseq[k] = maxerror
        if flag_givenpts_l2error == True:
            givenpts_l2error = sqrt(sum((u_net.predict(given_pts) - u_givenpts)**2)/given_pts.shape[0])/u_l2norm_givenpts
            givenpts_l2errorseq[k] = givenpts_l2error
        if flag_givenpts_maxerror == True:
            givenpts_maxerror = numpy.max(absolute(u_net.predict(given_pts) -u_givenpts))/u_maxnorm_givenpts
            givenpts_maxerrorseq[k] = givenpts_maxerror
    resseq[k] = sqrt(1/N_inside_train*sum((Du(u_net,x1_train)-f(x1_train))**2))
    
    ## Show information
    if k%n_epoch_show_info==0:
        if flag_compute_loss_each_epoch:
            print("epoch = %d, loss = %2.6f" %(k,loss.item()), end='')
        else:
            print("epoch = %d" % k, end='')
        if if_true_solution_given() == True:
            if flag_l2error == True:
                print(", l2 error = %2.6e" % l2error, end='')
            if flag_maxerror == True:
                print(", max error = %2.6e" % maxerror, end='')
            if flag_givenpts_l2error == True:
                print(", givenpts l2 error = %2.3e" % givenpts_l2error, end='')
            if flag_givenpts_maxerror == True:
                print(", givenpts max error = %2.3e" % givenpts_maxerror, end='')
        else:
            print("residual = %2.3e" % resseq[k], end='')
        if method == 'S':
            print(", max(select_net(x1_train)) = %2.3e" % numpy.max(select_net1.predict(x1_train)), end='')	
        print("\n")
        
        if flag_show_plot == True:
            clf()
            subplot(1,2,1)
            plot(x_plot[:,0],u_net.predict(x_plot),'r')
            if if_true_solution_given() == True:
                plot(x_plot[:,0],true_solution(x_plot),'b')
            if method == 'S' or method == 'RS':
                plot(x_plot[:,0],select_net1.predict(x_plot),'g')
            title('Iteration: '+str(k))
            xlabel('First component of plotting points')
            subplot(1,2,2)
            if flag_givenpts_l2error == True or flag_givenpts_maxerror == True:
                semilogy(range(0,k+1,n_epoch_show_info),givenpts_l2errorseq[range(0,k+1,n_epoch_show_info)],'b')
            else:   
                semilogy(range(0,k+1,n_epoch_show_info),l2errorseq[range(0,k+1,n_epoch_show_info)],'b')
            semilogy(range(0,k+1,n_epoch_show_info),resseq[range(0,k+1,n_epoch_show_info)],'r')
            xlim([0,n_epoch])
            ylim([1e-3,10])
            xlabel('Iterations')
            show()
            pause(0.02)
            
        if flag_temp_save == True:    
            #save the temp data
            torch.save(u_net.state_dict(),'networkpara_temp_'+time_text+'.pkl')
            if method == 'S' or method == 'RS':
                torch.save(select_net1.state_dict(),'select_network1para_temp_'+time_text+'.pkl')
                if flag_IBC_in_loss == True:
                    torch.save(select_net2.state_dict(),'select_network2para_temp_'+time_text+'.pkl')
            main_file_name = 'file_name'
            data = {'main_file_name':main_file_name,\
                                        'ID':time_text,\
                                        'N_inside_train':N_inside_train,\
                                        'activation':activation,\
                                        'boundary_control':boundary_control,\
                                        'd':d,\
                                        'domain_shape':domain_shape,\
                                        'domain_intervals':domain_intervals,\
                                        'givenpts_l2errorseq':givenpts_l2errorseq,\
                                        'givenpts_maxerrorseq':givenpts_maxerrorseq,\
                                        'h_Du_t':h_Du_t,\
                                        'initial_constant':initial_constant ,\
                                        'l2errorseq':l2errorseq,\
                                        'lambda_term':lambda_term,\
                                        'lossseq':lossseq,\
                                        'loss_type':loss_type,\
                                        'lrseq':lrseq,\
                                        'm':m,\
                                        'method':method,\
                                        'n_update_each_batch_pre':n_update_each_batch_pre,\
                                        'L':L,\
                                        'maxerrorseq':maxerrorseq,\
                                        'n_epoch':n_epoch,\
                                        'n_update_each_batch':n_update_each_batch,\
                                        'R':R,\
                                        'resseq':resseq,\
                                        'sphere_sampling_type':sphere_sampling_type,\
                                        'time_dependent_type':time_dependent_type,\
                                        'time_interval':time_interval,\
                                        'T0':T0,\
                                        'T1':T1,\
                                        'TensorType':TensorType,\
                                        'test_type':test_type,\
                                        'FD_step':FD_step,\
                                        }
            if method == 'S' or method == 'RS':
                data['loss_sn1_threshold'] = loss_sn1_threshold
                data['loss_sn2_threshold'] = loss_sn2_threshold
                data['lr_sn'] = lr_sn
                data['m_sn'] = m_sn
                data['maxvalue_sn'] = maxvalue_sn
                data['minvalue_sn'] = minvalue_sn
                data['n_update_each_batch_sn'] = n_update_each_batch_sn
                data['penalty_parameter'] = penalty_parameter
                data['selectnet_initial_constant'] = selectnet_initial_constant
            if if_true_solution_given() == True:
                if flag_l2error == True:
                    data['u_l2norm_x_test'] = u_l2norm_x_test
                if flag_maxerror == True:
                    data['u_maxnorm_x_test'] = u_maxnorm_x_test
                if flag_givenpts_l2error == True:
                    data['u_l2norm_givenpts'] = u_l2norm_givenpts
                    data['givenpts_info'] = givenpts_info
                if flag_givenpts_maxerror == True:
                    data['u_maxnorm_givenpts'] = u_maxnorm_givenpts    
                
            filename = 'result_temp_d_'+str(d)+'_'+time_text+'.data'
            file = open(filename, 'wb')
            pickle.dump(data, file)
            file.close()
            
    if flag_preiteration_by_small_lr == True and k == 0:
        flag_start_normal_training = True
        if flag_givenpts_l2error == True and givenpts_l2error>1.0:
            flag_start_normal_training = False
        if flag_start_normal_training == True:
            k = 1
    else:
        k = k + 1

# Save u_net
if flag_output_results == True:    
    localtime = time.localtime(time.time())
    time_text = str(localtime.tm_mon)+'_'+str(localtime.tm_mday)+'_'+str(localtime.tm_hour)+'_'+str(localtime.tm_min)
    torch.save(u_net.state_dict(),'networkpara_'+time_text+'.pkl')
    if method == 'S' or method == 'RS':
        torch.save(select_net1.state_dict(),'select_networkpara_'+time_text+'.pkl')

# Output results
if flag_output_results == True:    
    #save the data
    main_file_name = 'file_name'
    data = {'main_file_name':main_file_name,\
                                'ID':time_text,\
                                'N_inside_train':N_inside_train,\
                                'activation':activation,\
                                'boundary_control':boundary_control,\
                                'd':d,\
                                'domain_shape':domain_shape,\
                                'domain_intervals':domain_intervals,\
                                'flag_preiteration_by_small_lr':flag_preiteration_by_small_lr,\
                                'givenpts_l2errorseq':givenpts_l2errorseq,\
                                'givenpts_maxerrorseq':givenpts_maxerrorseq,\
                                'h_Du_t':h_Du_t,\
                                'initial_constant':initial_constant ,\
                                'l2errorseq':l2errorseq,\
                                'lambda_term':lambda_term,\
                                'lossseq':lossseq,\
                                'loss_type':loss_type,\
                                'lrseq':lrseq,\
                                'm':m,\
                                'method':method,\
                                'L':L,\
                                'maxerrorseq':maxerrorseq,\
                                'n_epoch':n_epoch,\
                                'n_update_each_batch':n_update_each_batch,\
                                'R':R,\
                                'resseq':resseq,\
                                'sphere_sampling_type':sphere_sampling_type,\
                                'time_dependent_type':time_dependent_type,\
                                'time_interval':time_interval,\
                                'T0':T0,\
                                'T1':T1,\
                                'TensorType':TensorType,\
                                'test_type':test_type,\
                                'FD_step':FD_step
                                }
    if method == 'S' or method == 'RS':
        data['loss_sn1_threshold'] = loss_sn1_threshold
        data['loss_sn2_threshold'] = loss_sn2_threshold
        data['lr_sn'] = lr_sn
        data['m_sn'] = m_sn
        data['maxvalue_sn'] = maxvalue_sn
        data['minvalue_sn'] = minvalue_sn
        data['n_update_each_batch_sn'] = n_update_each_batch_sn
        data['penalty_parameter'] = penalty_parameter
        data['selectnet_initial_constant'] = selectnet_initial_constant
    if if_true_solution_given() == True:
        if flag_l2error == True:
            data['u_l2norm_x_test'] = u_l2norm_x_test
        if flag_maxerror == True:
            data['u_maxnorm_x_test'] = u_maxnorm_x_test
        if flag_givenpts_l2error == True:
            data['u_l2norm_givenpts'] = u_l2norm_givenpts
            data['givenpts_info'] = givenpts_info
        if flag_givenpts_maxerror == True:
            data['u_maxnorm_givenpts'] = u_maxnorm_givenpts       
    
    filename = 'result_d_'+str(d)+'_'+time_text+'.data'
    file = open(filename, 'wb')
    pickle.dump(data, file)
    file.close()
    

# empty the GPU memory
torch.cuda.empty_cache()
