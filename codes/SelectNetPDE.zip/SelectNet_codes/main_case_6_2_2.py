# the main codes for various methods to solve PDEs

import torch
from torch import Tensor, optim
import numpy
from numpy import zeros, sum, sqrt, linspace, absolute
from useful_tools import generate_uniform_points_in_cube, generate_uniform_points_in_cube_time_dependent,\
    generate_uniform_points_on_cube, generate_uniform_points_on_cube_time_dependent,\
    generate_uniform_points_in_sphere, generate_uniform_points_in_sphere_time_dependent,\
    generate_uniform_points_on_sphere, generate_uniform_points_on_sphere_time_dependent,\
    generate_uniform_annular_points_in_sphere_time_dependent, generate_uniform_annular_points_on_sphere_time_dependent,\
    generate_uniform_annular_points_in_sphere, generate_learning_rates
from selection_network_setting import selection_network
from matplotlib.pyplot import plot, imshow, show, clf, pause, semilogy, title, xlabel, ylabel, subplot, xlim, ylim, figure, savefig
import pickle
import time

from problem_case_6_2_2 import spatial_dimension, true_solution, if_true_solution_given, Du, Du_ft, Bu_ft, f, g, h0, h1, domain_shape, domain_parameter, time_dependent_type, time_interval, FD_step

TensorType = 'Float'
seed = 1
torch.manual_seed(seed) 
numpy.random.seed(seed)
if TensorType == 'Double':
    torch.set_default_tensor_type('torch.cuda.DoubleTensor')
elif TensorType == 'Float':
    torch.set_default_tensor_type('torch.cuda.FloatTensor')
    
if time_dependent_type() == 'none':
    import network_setting as network_file
else:
    import network_time_dependent_setting  as network_file
    
########### Set parameters ############# 
d = spatial_dimension()  # dimension of problem
L = 3 # depth of the solution network
m = 100  # number of nodes in each layer of solution network
activation = 'ReLU3'  # activation function for the solution net
boundary_control = 'none'  # if the solution net architecture satisfies the boundary condition automatically 
initial_control = 'none'  # if the solution net architecture satisfies the initial condition automatically 
initial_constant = 0.0 # initial value for the solution network
n_epoch = 10000  # number of outer iterations
N_inside_train = 1000 # number of trainning sampling points inside the domain in each epoch (batch size)
lrseq = generate_learning_rates(-3,-5,n_epoch,0.999,1000) # learning rates
n_update_each_batch = 1 # number of iterations in each epoch (for the same batch of points)
lambda_term = 1
flag_preiteration_by_small_lr = False  # If pre iteration by small learning rates
lr_pre = 1e-3
n_update_each_batch_pre = 1
sphere_sampling_type = 'uniform' # 'uniform', 'uniform_annular' 
test_type = 'uniform' # 'uniform', 'uniform_annular' 

##############  Basic  ##############
flag_basic = True
lrseq_B = lrseq

########### SelectNet ################
flag_SelectNet = True
lrseq_S = lrseq
m_sn = 20   #number of nodes in each layer of the selection network
penalty_parameter = 0.01
maxvalue_sn = 5  # upper bound for the selection net
minvalue_sn = 0.5  # lower bound for the selection net
lr_sn = 0.0001  # learning rate for the selection net
loss_sn1_threshold = 1e-8  # stopping criteria for training the selection net1 (inside the domain)
loss_sn2_threshold = 1e-8  # stopping criteria for training the selection net2 (boudanry or initial)
selectnet_initial_constant = 1.0  # initialized value for the selection net

########### Problem parameters   #############
h = FD_step()  # time length for computing derivatives 
time_dependent_type = time_dependent_type()   ## If this is a time-dependent problem
domain_shape = domain_shape()  ## the shape of domain 
if domain_shape == 'cube':  
    domain_intervals = domain_parameter(d)
    R = []
elif domain_shape == 'sphere':
    R = domain_parameter(d)
    domain_intervals = []
if not time_dependent_type == 'none':    
    time_interval = time_interval()
    T0 = time_interval[0]
    T1 = time_interval[1]
else: 
    time_interval = []
    T0 = []
    T1 = []
    
########### Interface parameters #############
n_epoch_show_info = max([round(n_epoch/100),1]) # how many epoch will it show information
flag_show_plot = False # if show plot during the training
flag_output_results = False # if save the results as files in current directory

if if_true_solution_given() == True: # if we need to compute the error
    N_test = 10000 # number of testing points
    flag_l2error = True
    flag_maxerror = True
    flag_givenpts_l2error = False
    flag_givenpts_maxerror = False
    if flag_givenpts_l2error == True or flag_givenpts_maxerror == True:
        if time_dependent_type == 'none':
            given_pts = generate_uniform_points_in_sphere(d,0.1,10000)
            givenpts_info = 'given_pts = generate_uniform_points_in_sphere(d,0.1,10000)'
        else:
            given_pts = zeros((1,d+1))
    
    
########### Depending parameters #############
if flag_basic == True:
    u_net_B = network_file.network(d, m, L, activation_type = activation, boundary_control_type = boundary_control, initial_constant = initial_constant)
    torch.save(u_net_B.state_dict(),'temp.pkl')
if flag_SelectNet == True:
    u_net_S = network_file.network(d, m, L, activation_type = activation, boundary_control_type = boundary_control, initial_constant = initial_constant)
    u_net_S.load_state_dict(torch.load('temp.pkl'))
    if time_dependent_type == 'none':
        select_net1 = selection_network(d,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant) # selection_network inside the domain
    else:
        select_net1 = selection_network(d+1,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant)  # selection_network for initial and boudanry conditions
    if time_dependent_type == 'none':
        select_net2 = selection_network(d,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant)  # selection_network for initial and boudanry conditions
    else:
        select_net2 = selection_network(d+1,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant)  # selection_network for initial and boudanry conditions

if boundary_control == 'none':
    flag_boundary_term_in_loss = True  # if loss function has the boundary residual
else:
    flag_boundary_term_in_loss = False
if time_dependent_type == 'none':
    flag_initial_term_in_loss = False  # if loss function has the initial residual
else:
    if initial_control == 'none':
        flag_initial_term_in_loss = True
    else:
        flag_initial_term_in_loss = False
if flag_boundary_term_in_loss == True or flag_initial_term_in_loss == True:
    flag_IBC_in_loss = True  # if loss function has the boundary/initial residual
    N_IBC_train = 0  # number of boundary and initial training points
else:
    flag_IBC_in_loss = False
if flag_boundary_term_in_loss == True:
    if domain_shape == 'cube':
        if d == 1 and time_dependent_type == 'none':
            N_each_face_train = 1
        else:
            N_each_face_train = max([1,int(round(N_inside_train/2/d))]) # number of sampling points on each domain face when training
        N_boundary_train = 2*d*N_each_face_train
    elif domain_shape == 'sphere':
        if d == 1 and time_dependent_type == 'none':
            N_boundary_train = 2
        else:
            N_boundary_train = N_inside_train # number of sampling points on each domain face when training
    N_IBC_train = N_IBC_train + N_boundary_train
else:
    N_each_face_train = 0
    N_boundary_train = 0
if flag_initial_term_in_loss == True:          
    N_initial_train = max([1,int(round(N_inside_train/d))]) # number of sampling points on each domain face when training
    N_IBC_train = N_IBC_train + N_initial_train

if not time_dependent_type == 'none':   
    def Du_t_ft(model, tensor_x_batch):
        h = 0.001 # step length ot compute derivative
        s = torch.zeros(tensor_x_batch.shape[0])
        ei = torch.zeros(tensor_x_batch.shape)
        ei[:,0] = 1
        s = (3*model(tensor_x_batch+2*h*ei)-4*model(tensor_x_batch+h*ei)+model(tensor_x_batch))/2/h
        return s
    
#################### Start ######################
if flag_basic == True:
    optimizer_B = optim.Adam(u_net_B.parameters(),lr=lrseq_B[0])
    lossseq_B = zeros((n_epoch+1,))
    l2errorseq_B = zeros((n_epoch+1,))
    maxerrorseq_B = zeros((n_epoch+1,))
    givenpts_l2errorseq_B = zeros((n_epoch+1,))
    givenpts_maxerrorseq_B = zeros((n_epoch+1,))
if flag_SelectNet == True:
    optimizer_S = optim.Adam(u_net_S.parameters(),lr=lrseq_S[0])
    optimizer_sn1 = optim.Adam(select_net1.parameters(),lr=lr_sn)
    optimizer_sn2 = optim.Adam(select_net2.parameters(),lr=lr_sn)
    lossseq_S = zeros((n_epoch+1,))
    l2errorseq_S = zeros((n_epoch+1,))
    maxerrorseq_S = zeros((n_epoch+1,))
    givenpts_l2errorseq_S = zeros((n_epoch+1,))
    givenpts_maxerrorseq_S = zeros((n_epoch+1,))
    
if if_true_solution_given() == True:
    if time_dependent_type == 'none':
        if domain_shape == 'cube':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_cube(domain_intervals,N_test)    
        elif domain_shape == 'sphere':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_sphere(d,R,N_test)  
            elif test_type == 'uniform_annular':
                x_test = generate_uniform_annular_points_in_sphere(d,R,10,round(N_test/10))
    else:
        if domain_shape == 'cube':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_cube_time_dependent(domain_intervals,time_interval,N_test) 
        elif domain_shape == 'sphere':
            if test_type == 'uniform':
                x_test = generate_uniform_points_in_sphere_time_dependent(d,R,time_interval,N_test)
            elif test_type == 'uniform_annular':
                x_test = generate_uniform_annular_points_in_sphere_time_dependent(d,R,time_interval,10,round(N_test/10))

############ Precomputation ############
if if_true_solution_given() == True:
    if flag_l2error == True:
        u_x_test = true_solution(x_test)
        u_l2norm_x_test = sqrt(sum(u_x_test**2)/x_test.shape[0])
    if flag_maxerror == True:
        u_x_test = true_solution(x_test)
        u_maxnorm_x_test = numpy.max(absolute(u_x_test))
    if flag_givenpts_l2error == True:
        u_givenpts = true_solution(given_pts)
        u_l2norm_givenpts = sqrt(sum(u_givenpts**2)/given_pts.shape[0])
    if flag_givenpts_maxerror == True:
        u_givenpts = true_solution(given_pts)
        u_maxnorm_givenpts = numpy.max(absolute(u_givenpts))        
           
if flag_show_plot == True:
    figure(figsize=(10,5))
    N_plot = 1000
    if time_dependent_type == 'none':
        x_plot = zeros((N_plot,d))
        if domain_shape == 'cube':
            x_plot[:,0] = linspace(domain_intervals[0,0],domain_intervals[0,1],N_plot)
        elif domain_shape == 'sphere':
            x_plot[:,0] = linspace(-R,R,N_plot)
    else:
        x_plot = zeros((N_plot,d+1))
        x_plot[:,0] = linspace(T0,T1,N_plot)
    clf()
    subplot(1,2,1)
    xlim([0,n_epoch])
    ylim([1e-3,10])
    xlabel('Iterations')
    subplot(1,2,2)
    plot(x_plot[:,0],u_net_S.predict(x_plot),'r')
    plot(x_plot[:,0],select_net1.predict(x_plot),'r--')
    show()
    pause(0.02)
    
############ Local Time ###############    
localtime = time.localtime(time.time())
time_text = str(localtime.tm_mon)+'_'+str(localtime.tm_mday)+'_'+str(localtime.tm_hour)+'_'+str(localtime.tm_min)

# Training
k = 1
        
while k <= n_epoch:
    ## generate training and testing data (the shape is (N,d)) or (N,d+1) 
    ## label 1 is for the points inside the domain, 2 is for those on the bondary or at the initial time    
    if time_dependent_type == 'none':
        if domain_shape == 'cube':
            x1_train = generate_uniform_points_in_cube(domain_intervals,N_inside_train)
            if flag_IBC_in_loss == True:
                x2_train = generate_uniform_points_on_cube(domain_intervals,N_each_face_train)        
        elif domain_shape == 'sphere':
            if sphere_sampling_type == 'uniform':
                x1_train = generate_uniform_points_in_sphere(d,R,N_inside_train)
            elif sphere_sampling_type == 'uniform_annular':
                x1_train = generate_uniform_annular_points_in_sphere(d,R,10,round(N_inside_train/10))           
            if flag_IBC_in_loss == True:
                x2_train = generate_uniform_points_on_sphere(d,R,N_boundary_train)
    else:
        if domain_shape == 'cube':
            x1_train = generate_uniform_points_in_cube_time_dependent(domain_intervals,time_interval,N_inside_train)
            if flag_IBC_in_loss == True:
                # x2_train for boudanry samplings; x3_train for initial samplings
                x2_train, x3_train = generate_uniform_points_on_cube_time_dependent(domain_intervals,time_interval,N_each_face_train,N_initial_train)     
        elif domain_shape == 'sphere':
            if sphere_sampling_type == 'uniform':
                x1_train = generate_uniform_points_in_sphere_time_dependent(d,R,time_interval,N_inside_train)
            elif sphere_sampling_type == 'uniform_annular':
                x1_train = generate_uniform_annular_points_in_sphere_time_dependent(d,R,time_interval,10,round(N_inside_train/10))
            if flag_IBC_in_loss == True:
                # x2_train for boudanry samplings; x3_train for initial samplings
                if flag_boundary_term_in_loss == False:
                    if sphere_sampling_type == 'uniform':
                        [], x3_train = generate_uniform_points_on_sphere_time_dependent(d,R,time_interval,0,N_initial_train)
                    elif sphere_sampling_type == 'uniform_annular':
                        [], x3_train = generate_uniform_annular_points_on_sphere_time_dependent(d,R,time_interval,0,10,round(N_initial_train/10))
                elif flag_initial_term_in_loss == False:
                    if sphere_sampling_type == 'uniform':
                        x2_train, [] = generate_uniform_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,0)
                    elif sphere_sampling_type == 'uniform_annular':
                        x2_train, [] = generate_uniform_annular_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,0,0)
                else:
                    if sphere_sampling_type == 'uniform':
                        x2_train, x3_train = generate_uniform_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,N_initial_train)
                    elif sphere_sampling_type == 'uniform_annular':
                        x2_train, x3_train = generate_uniform_annular_points_on_sphere_time_dependent(d,R,time_interval,N_boundary_train,10,round(N_initial_train/10))
        
    tensor_x1_train = Tensor(x1_train)
    tensor_x1_train.requires_grad=False
    tensor_f1_train = Tensor(f(x1_train))
    tensor_f1_train.requires_grad=False
    if flag_boundary_term_in_loss == True:
        tensor_x2_train = Tensor(x2_train)
        tensor_x2_train.requires_grad=False
        tensor_g2_train = Tensor(g(x2_train))
        tensor_g2_train.requires_grad=False
        
    if flag_initial_term_in_loss == True:
        tensor_x3_train = Tensor(x3_train)
        tensor_x3_train.requires_grad=False
        if time_dependent_type == 'parabolic' or time_dependent_type == 'hyperbolic':
            # h0 for u(x,0) = h0(x)
            tensor_h03_train = Tensor(h0(x3_train))
            tensor_h03_train.requires_grad=False
        if time_dependent_type == 'hyperbolic':
            # h1 for u_t(x,0) = h1(x)
            tensor_h13_train = Tensor(h1(x3_train))
            tensor_h13_train.requires_grad=False
           
    ## Set learning rate
    if flag_preiteration_by_small_lr == True and k == 1:
        if flag_basic == True:
            for param_group in optimizer_B.param_groups:
                param_group['lr'] = lr_pre
        if flag_SelectNet == True:
            for param_group in optimizer_S.param_groups:
                param_group['lr'] = lr_pre
    else:
        if flag_basic == True:
            for param_group in optimizer_B.param_groups:
                param_group['lr'] = lrseq_B[k-1]
        if flag_SelectNet == True:
            for param_group in optimizer_S.param_groups:
                param_group['lr'] = lrseq_S[k-1]
        
    ## Train selention net
    if flag_SelectNet == True:
        max_select_net1_x1_train = numpy.max(select_net1.predict(x1_train))
        ## Train the selection net inside the domain
        const_tensor_loss_term_x1_train = (Du_ft(u_net_S,tensor_x1_train)-tensor_f1_train)**2
        ## Compute the loss  
        loss_sn = -1/torch.sum(const_tensor_loss_term_x1_train)*torch.sum((select_net1(tensor_x1_train)*const_tensor_loss_term_x1_train)) + 1/penalty_parameter*(1/N_inside_train*torch.sum(select_net1(tensor_x1_train))-1).pow(2)
        ## Update the network
        optimizer_sn1.zero_grad()
        loss_sn.backward(retain_graph=False)
        optimizer_sn1.step()
            
        ## Train the selection net on the boudnary or on the initial slice
        if flag_IBC_in_loss == True :
            if u_net_S.boundary_control_type == 'none':
                if flag_boundary_term_in_loss == True:
                    const_tensor_residual_square_x2_train = (Bu_ft(u_net_S,tensor_x2_train)-tensor_g2_train)**2
                if flag_initial_term_in_loss == True:
                    const_tensor_residual_square_x3_train = (u_net_S(tensor_x3_train)-tensor_h03_train)**2
                ## Compute the loss  
                loss_sn = Tensor([0])
                tensor_IBC_sum_term = Tensor([0])
                if flag_boundary_term_in_loss == True:
                    loss_sn = loss_sn - 1/torch.sum(const_tensor_residual_square_x2_train)*torch.sum((select_net2(tensor_x2_train)*const_tensor_residual_square_x2_train)) 
                    tensor_IBC_sum_term = tensor_IBC_sum_term + torch.sum(select_net2(tensor_x2_train))
                if flag_initial_term_in_loss == True:
                    loss_sn = loss_sn - 1/torch.sum(const_tensor_residual_square_x3_train)*torch.sum((select_net2(tensor_x3_train)*const_tensor_residual_square_x3_train)) 
                    tensor_IBC_sum_term = tensor_IBC_sum_term + torch.sum(select_net2(tensor_x3_train)) 
                loss_sn = loss_sn + 1/penalty_parameter*(1/N_IBC_train*tensor_IBC_sum_term-1).pow(2)
                ## Update the network
                optimizer_sn2.zero_grad()
                loss_sn.backward(retain_graph=True)
                optimizer_sn2.step()
                
    if flag_preiteration_by_small_lr == True and k == 1:
        temp = n_update_each_batch_pre
    else:
        temp = n_update_each_batch
    for i_update in range(temp):
        ## Basic least square
        if flag_basic == True:
            loss1_B = 1/N_inside_train*torch.sum((Du_ft(u_net_B,tensor_x1_train)-tensor_f1_train)**2)
            loss_B = loss1_B
            if flag_IBC_in_loss == True:
                loss2_B = Tensor([0])
                if flag_boundary_term_in_loss == True:
                    loss2_B = loss2_B + torch.sum((Bu_ft(u_net_B,tensor_x2_train)-tensor_g2_train)**2)
                if flag_initial_term_in_loss == True:
                    loss2_B = loss2_B + torch.sum((u_net_B(tensor_x3_train)-tensor_h03_train)**2)
                    if time_dependent_type == 'hyperbolic':
                        loss2_B = loss2_B + torch.sum((Du_t_ft(u_net_B,tensor_x3_train)-tensor_h13_train)**2)
                loss2_B = lambda_term/N_IBC_train*loss2_B
                loss_B = loss1_B + loss2_B
            # Plot initial loss and error
            if k == 1 and i_update == 0:
                print('Epoch = 0,')
                lossseq_B[0] = loss_B.item()
                if if_true_solution_given() == True:
                    if flag_l2error == True:
                        l2error_B = sqrt(sum((u_net_B.predict(x_test) - u_x_test)**2)/x_test.shape[0])/u_l2norm_x_test
                        l2errorseq_B[0] = l2error_B
                    if flag_maxerror == True:
                        maxerror_B = numpy.max(absolute(u_net_B.predict(x_test) -u_x_test))/u_maxnorm_x_test
                        maxerrorseq_B[0] = maxerror_B
                    if flag_givenpts_l2error == True:
                        givenpts_l2error_B = sqrt(sum((u_net_B.predict(given_pts) - u_givenpts)**2)/given_pts.shape[0])/u_l2norm_givenpts
                        givenpts_l2errorseq_B[0] = givenpts_l2error_B
                    if flag_givenpts_maxerror == True:
                        givenpts_maxerror_B = numpy.max(absolute(u_net_B.predict(given_pts) -u_givenpts))/u_maxnorm_givenpts
                        givenpts_maxerrorseq_B[0] = givenpts_maxerror_B
                print("Basic:     loss = %2.3e, " %(loss_B.item()), end='')
                if flag_IBC_in_loss == True:
                    print("loss1 = %2.3e, loss2 = %2.3e, " %(loss1_B.item(),loss2_B.item()), end='')
    
                if if_true_solution_given() == True:
                    if flag_l2error == True:
                        print("l2 error = %2.3e" %(l2error_B), end='')
                    if flag_maxerror == True:
                        print(", max error = %2.3e" %(maxerror_B), end='')
                    if flag_givenpts_l2error == True:
                        print(", givenpts l2 error = %2.3e" %(givenpts_l2error_B), end='')
                    if flag_givenpts_maxerror == True:
                        print(", givenpts max error = %2.3e" %(givenpts_maxerror_B), end='')
                    print(" ")
        
                ## Update the network
                optimizer_B.zero_grad()
                loss_B.backward(retain_graph=False)
                optimizer_B.step()

        ## SelectNet least square
        if flag_SelectNet == True:
            const_tensor_sn_x1_train = select_net1(tensor_x1_train)
            if flag_boundary_term_in_loss == True:
                const_tensor_sn2_x2_train = select_net2(tensor_x2_train)
            if flag_initial_term_in_loss == True:
                const_tensor_sn2_x3_train = select_net2(tensor_x3_train)
            loss1_S = 1/N_inside_train*torch.sum(const_tensor_sn_x1_train*(Du_ft(u_net_S,tensor_x1_train)-tensor_f1_train)**2)
            loss_S = loss1_S
            if flag_IBC_in_loss == True:
                loss2_S = Tensor([0])
                if flag_boundary_term_in_loss == True:
                    loss2_S = loss2_S + torch.sum(const_tensor_sn2_x2_train*(Bu_ft(u_net_S,tensor_x2_train)-tensor_g2_train)**2)
                if flag_initial_term_in_loss == True:
                    loss2_S = loss2_S + torch.sum(const_tensor_sn2_x3_train*(u_net_S(tensor_x3_train)-tensor_h03_train)**2)
                    if time_dependent_type == 'hyperbolic':
                        loss2_S = loss2_S + torch.sum((Du_t_ft(u_net_S,tensor_x3_train)-tensor_h13_train)**2)
                loss2_S = lambda_term/N_IBC_train*loss2_S
                loss_S = loss1_S + loss2_S

            # Plot initial loss and error
            if k == 1 and i_update == 0:
                lossseq_S[0] = loss_S.item()
                if if_true_solution_given() == True:
                    if flag_l2error == True:
                        l2error_S = sqrt(sum((u_net_S.predict(x_test) - u_x_test)**2)/x_test.shape[0])/u_l2norm_x_test
                        l2errorseq_S[0] = l2error_S
                    if flag_maxerror == True:
                        maxerror_S = numpy.max(absolute(u_net_S.predict(x_test) -u_x_test))/u_maxnorm_x_test
                        maxerrorseq_S[0] = maxerror_S
                    if flag_givenpts_l2error == True:
                        givenpts_l2error_S = sqrt(sum((u_net_S.predict(given_pts) - u_givenpts)**2)/given_pts.shape[0])/u_l2norm_givenpts
                        givenpts_l2errorseq_S[0] = givenpts_l2error_S
                    if flag_givenpts_maxerror == True:
                        givenpts_maxerror_S = numpy.max(absolute(u_net_S.predict(given_pts) -u_givenpts))/u_maxnorm_givenpts
                        givenpts_maxerrorseq_S[0] = givenpts_maxerror_S
    
                print("SelectNet: loss = %2.3e, " %(loss_S.item()), end='')
                if flag_IBC_in_loss == True:
                    print("loss1 = %2.3e, loss2 = %2.3e, " %(loss1_S.item(),loss2_S.item()), end='')
                if if_true_solution_given() == True:
                    if flag_l2error == True:
                        print("l2 error = %2.3e" %(l2error_S), end='')
                    if flag_maxerror == True:
                        print(", max error = %2.3e" %(maxerror_S), end='')
                    if flag_givenpts_l2error == True:
                        print(", givenpts l2 error = %2.3e" %(givenpts_l2error_S), end='')
                    if flag_givenpts_maxerror == True:
                        print(", givenpts max error = %2.3e" %(givenpts_maxerror_S), end='')
                    print(" ")
                print(" ")

            ## Update the network
            optimizer_S.zero_grad()
            loss_S.backward(retain_graph=False)
            optimizer_S.step()

    # Save loss and L2 error for basic
    if flag_basic == True:
        lossseq_B[k] = loss_B.item()
        if if_true_solution_given() == True:
            if flag_l2error == True:
                l2error_B = sqrt(sum((u_net_B.predict(x_test) - u_x_test)**2)/x_test.shape[0])/u_l2norm_x_test
                l2errorseq_B[k] = l2error_B
            if flag_maxerror == True:
                maxerror_B = numpy.max(absolute(u_net_B.predict(x_test) -u_x_test))/u_maxnorm_x_test
                maxerrorseq_B[k] = maxerror_B
            if flag_givenpts_l2error == True:
                givenpts_l2error_B = sqrt(sum((u_net_B.predict(given_pts) - u_givenpts)**2)/given_pts.shape[0])/u_l2norm_givenpts
                givenpts_l2errorseq_B[k] = givenpts_l2error_B
            if flag_givenpts_maxerror == True:
                givenpts_maxerror_B = numpy.max(absolute(u_net_B.predict(given_pts) -u_givenpts))/u_maxnorm_givenpts
                givenpts_maxerrorseq_B[k] = givenpts_maxerror_B
    # Save loss and L2 error for SelectNet
    if flag_SelectNet == True:
        lossseq_S[k] = loss_S.item()
        if if_true_solution_given() == True:
            if flag_l2error == True:
                l2error_S = sqrt(sum((u_net_S.predict(x_test) - u_x_test)**2)/x_test.shape[0])/u_l2norm_x_test
                l2errorseq_S[k] = l2error_S
            if flag_maxerror == True:
                maxerror_S = numpy.max(absolute(u_net_S.predict(x_test) -u_x_test))/u_maxnorm_x_test
                maxerrorseq_S[k] = maxerror_S
            if flag_givenpts_l2error == True:
                givenpts_l2error_S = sqrt(sum((u_net_S.predict(given_pts) - u_givenpts)**2)/given_pts.shape[0])/u_l2norm_givenpts
                givenpts_l2errorseq_S[k] = givenpts_l2error_S
            if flag_givenpts_maxerror == True:
                givenpts_maxerror_S = numpy.max(absolute(u_net_S.predict(given_pts) -u_givenpts))/u_maxnorm_givenpts
                givenpts_maxerrorseq_S[k] = givenpts_maxerror_S

    ## Show information
    if k%n_epoch_show_info==0:
        print("Epoch = %d" %k)
        if flag_basic == True:
            print("Basic:     loss = %2.3e, " %(loss_B.item()), end='')
            if flag_IBC_in_loss == True:
                print("loss1 = %2.3e, loss2 = %2.3e, " %(loss1_B.item(),loss2_B.item()), end='')
            if if_true_solution_given() == True:
                if flag_l2error == True:
                    print("l2 error = %2.3e" %(l2error_B), end='')
                if flag_maxerror == True:
                    print(", max error = %2.3e" %(maxerror_B), end='')
                if flag_givenpts_l2error == True:
                    print(", givenpts l2 error = %2.3e" %(givenpts_l2error_B), end='')
                if flag_givenpts_maxerror == True:
                    print(", givenpts max error = %2.3e" %(givenpts_maxerror_B), end='')
            print('')
        if flag_SelectNet == True:
            print("SelectNet: loss = %2.3e, " %(loss_S.item()), end='')
            if flag_IBC_in_loss == True:
                print("loss1 = %2.3e, loss2 = %2.3e, " %(loss1_S.item(),loss2_S.item()), end='')
            if if_true_solution_given() == True:
                if flag_l2error == True:
                    print("l2 error = %2.3e" %(l2error_S), end='')
                if flag_maxerror == True:
                    print(", max error = %2.3e" %(maxerror_S), end='')
                if flag_givenpts_l2error == True:
                    print(", givenpts l2 error = %2.3e" %(givenpts_l2error_S), end='')
                if flag_givenpts_maxerror == True:
                    print(", givenpts max error = %2.3e" %(givenpts_maxerror_S), end='')
            print(" ")
        
        print(" ")
        if flag_show_plot == True:
            clf()
            subplot(1,3,1)
            if flag_basic == True:
                if flag_l2error == True:
                    semilogy(range(0,k+1,n_epoch_show_info),l2errorseq_B[range(0,k+1,n_epoch_show_info)],'b')
            if flag_SelectNet == True:
                if flag_l2error == True:
                    semilogy(range(0,k+1,n_epoch_show_info),l2errorseq_S[range(0,k+1,n_epoch_show_info)],'r') 
            xlim([0,n_epoch])
            ylim([1e-3,10])
            xlabel('Iterations')
            subplot(1,3,2)
            temp = Du(select_net1,x_plot)-f(x_plot)
            plot(x_plot[:,0],temp,'r')
            plot(x_plot[:,0],select_net1.predict(x_plot),'r--')
            subplot(1,3,3)
            imshow(select_net1.predict(x_test).reshape((100,100)))
            show()
            pause(0.02)
            
    if flag_preiteration_by_small_lr == True and k == 1:
        flag_start_normal_training = True
        if flag_givenpts_l2error == True and (givenpts_l2error_B>1.0 or givenpts_l2error_S>1.0):
            flag_start_normal_training = False
        if flag_start_normal_training == True:
            k = 1
    else:
        k = k + 1

# Save u_net
if flag_output_results == True:    
    localtime = time.localtime(time.time())
    time_text = str(localtime.tm_mon)+'_'+str(localtime.tm_mday)+'_'+str(localtime.tm_hour)+'_'+str(localtime.tm_min)

# Output results
if flag_output_results == True:    
    #save the data
    data = {'ID':time_text,\
                                'seed':seed,\
                                'N_inside_train':N_inside_train,\
                                'activation':activation,\
                                'boundary_control':boundary_control,\
                                'd':d,\
                                'domain_shape':domain_shape,\
                                'domain_intervals':domain_intervals,\
                                'flag_preiteration_by_small_lr':flag_preiteration_by_small_lr,\
                                'h':h,\
                                'initial_constant':initial_constant ,\
                                'lambda_term':lambda_term,\
                                'm':m,\
                                'L':L,\
                                'n_epoch':n_epoch,\
                                'n_update_each_batch':n_update_each_batch,\
                                'R':R,\
                                'sphere_sampling_type':sphere_sampling_type,\
                                'time_dependent_type':time_dependent_type,\
                                'time_interval':time_interval,\
                                'T0':T0,\
                                'T1':T1,\
                                'TensorType':TensorType,\
                                'test_type':test_type,\
                                }
    if flag_basic == True:
        data['lrseq_B'] = lrseq_B     
        data['lossseq_B'] = lossseq_B
        data['givenpts_l2errorseq_B'] = givenpts_l2errorseq_B
        data['givenpts_maxerrorseq_B'] = givenpts_maxerrorseq_B
        data['l2errorseq_B'] = l2errorseq_B
        data['maxerrorseq_B'] = maxerrorseq_B     
        
    if flag_SelectNet == True:
        data['lrseq_S'] = lrseq_S   
        data['loss_sn1_threshold'] = loss_sn1_threshold
        data['loss_sn2_threshold'] = loss_sn2_threshold
        data['lr_sn'] = lr_sn
        data['m_sn'] = m_sn
        data['maxvalue_sn'] = maxvalue_sn
        data['minvalue_sn'] = minvalue_sn
        data['penalty_parameter'] = penalty_parameter
        data['selectnet_initial_constant'] = selectnet_initial_constant
        data['lossseq_S'] = lossseq_S
        data['givenpts_l2errorseq_S'] = givenpts_l2errorseq_S
        data['givenpts_maxerrorseq_S'] = givenpts_maxerrorseq_S
        data['l2errorseq_S'] = l2errorseq_S
        data['maxerrorseq_S'] = maxerrorseq_S
        
    if if_true_solution_given() == True:
        if flag_l2error == True:
            data['u_l2norm_x_test'] = u_l2norm_x_test
        if flag_maxerror == True:
            data['u_maxnorm_x_test'] = u_maxnorm_x_test
        if flag_givenpts_l2error == True:
            data['u_l2norm_givenpts'] = u_l2norm_givenpts
            data['givenpts_info'] = givenpts_info
        if flag_givenpts_maxerror == True:
            data['u_maxnorm_givenpts'] = u_maxnorm_givenpts       
    
    filename = 'result_d_'+str(d)+'_'+time_text+'.data'
    file = open(filename, 'wb')
    pickle.dump(data, file)
    file.close()
    

# empty the GPU memory
torch.cuda.empty_cache()
