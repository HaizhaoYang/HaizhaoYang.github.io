from numpy import zeros, linspace, array, meshgrid, sqrt, absolute
from matplotlib.pyplot import figure, plot, semilogy, xlabel, ylabel, tight_layout, title, show
import pickle
import scipy.io
import torch
from mpl_toolkits.mplot3d import Axes3D


####################
figure(figsize=(4,3))
d = 10
ID = 'input ID'
filename = 'result_d_'+str(d)+'_'+ID+'.data'
data=pickle.load(open(filename, 'rb'))
print("d=%2.0d, %s, lr: %2.1e - %2.1e, l2_error = %4.3e, givenpts_l2_error = %4.3e" %(data['d'],data['method'],data['lrseq'][0],data['lrseq'][-1],data['l2errorseq'][-1],data['givenpts_l2errorseq'][-1]))
givenpts_l2errorseq = data['givenpts_l2errorseq']
indices = range(0,givenpts_l2errorseq.shape[0])
semilogy(linspace(1,len(givenpts_l2errorseq),len(indices)),givenpts_l2errorseq[indices],'r',linewidth=0.5)
ID = 'input ID' 
filename = 'result_d_'+str(d)+'_'+ID+'.data'
data=pickle.load(open(filename, 'rb'))
print("d=%2.0d, %s, lr: %2.1e - %2.1e, l2_error = %4.3e, givenpts_l2_error = %4.3e" %(data['d'],data['method'],data['lrseq'][0],data['lrseq'][-1],data['l2errorseq'][-1],data['givenpts_l2errorseq'][-1]))
givenpts_l2errorseq = data['givenpts_l2errorseq']
indices = range(0,givenpts_l2errorseq.shape[0])
semilogy(linspace(1,len(givenpts_l2errorseq),len(indices)),givenpts_l2errorseq[indices],'b',linewidth=0.5)
xlabel('Iterations')
ylabel('$\ell^2$ error')
tight_layout()

