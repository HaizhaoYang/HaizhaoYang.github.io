# the main codes for the residual method to solve PDEs

import torch
from torch import Tensor, optim
import numpy
from numpy import zeros, sum, sqrt, absolute, pi, sin, cos
from useful_tools import generate_uniform_points_in_sphere, generate_uniform_points_on_sphere, generate_uniform_annular_points_in_sphere, generate_learning_rates
import FNN_setting 
import SelectNet_setting 
import pickle
import time

TensorType = 'Double'
torch.manual_seed(1) 
numpy.random.seed(1)
if TensorType == 'Double':
    torch.set_default_tensor_type('torch.cuda.DoubleTensor')
elif TensorType == 'Float':
    torch.set_default_tensor_type('torch.cuda.FloatTensor')
    
h = 0.01 # step length ot compute derivative

# the dimension in space
d = 10

# define the true solution for numpy array (N sampling points of d variables)
def true_solution(x_batch):
    temp = absolute(1-sqrt(numpy.sum(x_batch**2,1)))
    u = sin(pi/2*temp**(2.5))
    return u

# the point-wise Du: Input x is a sampling point of d variables ; Output is a numpy vector which means the result of Du(x))
def Du(model,x_batch):
    s = zeros(x_batch.shape[0])
    for i in range(x_batch.shape[1]):  
        ei = zeros(x_batch.shape)
        ei[:,i] = 1
        s = s - 1/h*((1+0.5*numpy.sum((x_batch+0.5*h*ei)**2, 1))*((model.predict(x_batch+h*ei)-model.predict(x_batch))/h)\
                      - (1+0.5*numpy.sum((x_batch-0.5*h*ei)**2, 1))*((model.predict(x_batch)-model.predict(x_batch-h*ei))/h))
    return s

# the point-wise Du: Input x is a batch of sampling points of d variables (tensor) ; Output is tensor vector which means the result of Du(x))
def Du_ft(model,tensor_x_batch):
    s = torch.zeros(tensor_x_batch.shape[0])
    s.requires_grad=False   
    for i in range(tensor_x_batch.shape[1]):  
        ei = torch.zeros(tensor_x_batch.shape)
        ei.requires_grad=False   
        ei[:,i] = 1
        s = s - 1/h*((1+0.5*torch.sum((tensor_x_batch+0.5*h*ei)**2, 1))*((model(tensor_x_batch+h*ei)-model(tensor_x_batch))/h)\
                      - (1+0.5*torch.sum((tensor_x_batch-0.5*h*ei)**2, 1))*((model(tensor_x_batch)-model(tensor_x_batch-h*ei))/h))
    return s

# define the right hand function for numpy array (N sampling points of d variables)
def f(x_batch):
    r = sqrt(numpy.sum(x_batch**2,1))
    temp = absolute(1-r)
    inner_part = pi/2*temp**(2.5)
    Laplace_u = -5*pi*(x_batch.shape[1]-1)/4/r*cos(inner_part)*temp**(1.5)-25*pi*pi/16*sin(inner_part)*(1-r)**3+15*pi/8*cos(inner_part)*temp**0.5
    f = 5*pi*r/4*cos(inner_part)*temp**(1.5)-(1+0.5*r**2)*Laplace_u
    return f

# compute a(x)|grad u(x)|^2 at a batch of points x (tensor)
def a_grad_u_square(model, x_batch):
    s = zeros(x_batch.shape[0])  
    for i in range(x_batch.shape[1]):  
        ei = zeros(x_batch.shape) 
        ei[:,i] = 1
        s = s + ((model.predict(x_batch+h*ei)-model.predict(x_batch-h*ei))/2/h)**2
    return (1+0.5*numpy.sum((x_batch)**2, 1))*s

# compute a(x)|grad u(x)|^2 at a batch of points x (tensor)
def a_grad_u_square_ft(model, tensor_x_batch):
    s = torch.zeros(tensor_x_batch.shape[0])
    s.requires_grad=False   
    for i in range(tensor_x_batch.shape[1]):  
        ei = torch.zeros(tensor_x_batch.shape)
        ei.requires_grad=False   
        ei[:,i] = 1
        s = s + ((model(tensor_x_batch+h*ei)-model(tensor_x_batch-h*ei))/2/h)**2
    return (1+0.5*torch.sum((tensor_x_batch)**2, 1))*s

# the point-wise Bu for tensor (N sampling points of d variables)
def Bu_ft(model,tensor_x_batch):
    return model(tensor_x_batch)

# define the boundary value g for numpy array (N sampling points of d variables)
def g(x_batch):
    return zeros((x_batch.shape[0],))

# radius of the domain
R = 1

########### Set parameters #############
method = 'B' # choose methods: B(basic), S(SelectNet), RS (reversed SelectNet)
L = 3 # depth of the solution network
m = 100  # number of nodes in each layer of solution network
n_epoch = 20000  # number of outer iterations
N_inside_train = 10000 # number of trainning sampling points inside the domain in each epoch (batch size)
N_boundary_train = 10000 # number of trainning sampling points on the boundary in each epoch (batch size)
n_update_each_batch = 1 # number of iterations in each epoch (for the same batch of points)
lrseq = generate_learning_rates(-3,-6,n_epoch,0.999,1000)

lambda_term = 10
if method == 'S':
    m_sn = 20   #number of nodes in each layer of the selection network
    penalty_parameter = 0.01
    maxvalue_sn = 5  # upper bound for the selection net
    minvalue_sn = 0.8  # lower bound for the selection net
    lr_sn = 0.0001  # learning rate for the selection net
    n_update_each_batch_sn = 1
    loss_sn1_threshold = 1e-8  # stopping criteria for training the selection net1 (inside the domain)
    loss_sn2_threshold = 1e-8  # stopping criteria for training the selection net2 (boudanry or initial)
    selectnet_initial_constant = 1.0  # if selectnet is initialized as constant one
activation = 'ReLU3'  # activation function for the solution net
initial_constant = 'none' # initial value for the solution network
sphere_sampling_type = 'uniform_annular' # 'uniform', 'uniform_annular' 
test_type = 'uniform_annular' # 'uniform', 'uniform_annular' 

########### Interface parameters #############
n_epoch_show_info = max([round(n_epoch/100),1]) # how many epoch will it show information
flag_show_plot = False # if show plot during the training
flag_output_results = False # if save the results as files in current directory
if method == 'S':
    flag_show_sn_info = False

N_test = 10000 # number of testing points
flag_l2error = True
flag_maxerror = False
    
########### Depending parameters #############
if method == 'B':
    u_net = FNN_setting.network(d, m, L, activation_type = activation)
if method == 'S':
    u_net = SelectNet_setting.network(d, m, L, activation_type = activation)
    select_net1 = SelectNet_setting.selection_network(d,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant) # selection_network inside the domain
    select_net2 = SelectNet_setting.selection_network(d,m_sn,maxvalue_sn,minvalue_sn, initial_constant = selectnet_initial_constant)  # selection_network for initial and boudanry conditions


#################### Start ######################
optimizer = optim.Adam(u_net.parameters(),lr=lrseq[0])
if method == 'S':
    optimizer_sn1 = optim.Adam(select_net1.parameters(),lr=lr_sn)
    optimizer_sn2 = optim.Adam(select_net2.parameters(),lr=lr_sn)

lossseq = zeros((n_epoch,))
resseq = zeros((n_epoch,))
l2errorseq = zeros((n_epoch,))
maxerrorseq = zeros((n_epoch,))
givenpts_l2errorseq = zeros((n_epoch,))
givenpts_maxerrorseq = zeros((n_epoch,))

if test_type == 'uniform':
    x_test = generate_uniform_points_in_sphere(d,R,N_test)  
elif test_type == 'uniform_annular':
    x_test = generate_uniform_annular_points_in_sphere(d,R,10,round(N_test/10))

############ Precomputation ############
if flag_l2error == True:
    u_x_test = true_solution(x_test)
    u_l2norm_x_test = sqrt(sum(u_x_test**2)/x_test.shape[0])
if flag_maxerror == True:
    u_x_test = true_solution(x_test)
    u_maxnorm_x_test = numpy.max(absolute(u_x_test))

############ Local Time ###############    
localtime = time.localtime(time.time())
time_text = str(localtime.tm_mon)+'_'+str(localtime.tm_mday)+'_'+str(localtime.tm_hour)+'_'+str(localtime.tm_min)

# Training
k = 0       
while k < n_epoch:
    ## generate training and testing data (the shape is (N,d)) or (N,d+1) 
    ## label 1 is for the points inside the domain, 2 is for those on the bondary or at the initial time    

    if sphere_sampling_type == 'uniform':
        x1_train = generate_uniform_points_in_sphere(d,R,N_inside_train)
    elif sphere_sampling_type == 'uniform_annular':
        x1_train = generate_uniform_annular_points_in_sphere(d,R,10,round(N_inside_train/10))           
    x2_train = generate_uniform_points_on_sphere(d,R,N_boundary_train)
        
    tensor_x1_train = Tensor(x1_train)
    tensor_x1_train.requires_grad=False
    tensor_f1_train = Tensor(f(x1_train))
    tensor_f1_train.requires_grad=False
    tensor_x2_train = Tensor(x2_train)
    tensor_x2_train.requires_grad=False
    tensor_g2_train = Tensor(g(x2_train))
    tensor_g2_train.requires_grad=False
           
    ## Set learning rate
    for param_group in optimizer.param_groups:
        param_group['lr'] = lrseq[k]
        
    ## Train the selection net inside the domain
    if method == 'S':
        const_tensor_loss_term_x1_train = (Du_ft(u_net,tensor_x1_train)-tensor_f1_train)**2
        old_loss = 1e5
        for i_update_sn in range(n_update_each_batch_sn):
            ## Compute the loss  
            if method == 'S':
                loss_sn = -1/torch.sum(const_tensor_loss_term_x1_train)*torch.sum((select_net1(tensor_x1_train)*const_tensor_loss_term_x1_train)) + 1/penalty_parameter*(1/N_inside_train*torch.sum(select_net1(tensor_x1_train))-1).pow(2)
            ## If loss_sn is stable, then break
            if abs(loss_sn.item()-old_loss)<loss_sn1_threshold:
                break
            old_loss = loss_sn.item()
            ## Update the network
            optimizer_sn1.zero_grad()
            loss_sn.backward(retain_graph=False)
            optimizer_sn1.step()
            
    ## Train the selection net on the boudnary or on the initial slice
    if method == 'S':
        const_tensor_residual_square_x2_train = (Bu_ft(u_net,tensor_x2_train)-tensor_g2_train)**2
        old_loss = 1e5
        for i_update_sn in range(n_update_each_batch_sn):
            ## Compute the loss  
            loss_sn = Tensor([0])
            tensor_IBC_sum_term = Tensor([0])
            if method == 'S':
                loss_sn = loss_sn - 1/torch.sum(const_tensor_residual_square_x2_train)*torch.sum((select_net2(tensor_x2_train)*const_tensor_residual_square_x2_train)) 
            tensor_IBC_sum_term = tensor_IBC_sum_term + torch.sum(select_net2(tensor_x2_train))        
            loss_sn = loss_sn + 1/penalty_parameter*(1/N_boundary_train*tensor_IBC_sum_term-1).pow(2)
             ## If loss_sn is stable, then break
            if abs(loss_sn.item()-old_loss)<loss_sn2_threshold:
                break
            old_loss = loss_sn.item()
            ## Update the network
            optimizer_sn2.zero_grad()
            loss_sn.backward(retain_graph=True)
            optimizer_sn2.step()
        
    ## Train the solution net
    if method == 'S':
        const_tensor_sn_x1_train = select_net1(tensor_x1_train)
        const_tensor_sn2_x2_train = select_net2(tensor_x2_train)

    for i_update in range(n_update_each_batch):
        ## Compute the loss  
        if method == 'B':
            loss1 = 1/N_inside_train*torch.sum((Du_ft(u_net,tensor_x1_train)-tensor_f1_train)**2)
        elif method == 'S':
            loss1 = 1/N_inside_train*torch.sum(const_tensor_sn_x1_train*(Du_ft(u_net,tensor_x1_train)-tensor_f1_train)**2)
        loss = loss1

        loss2 = Tensor([0])
        if method == 'B':
            loss2 = loss2 + torch.sum((Bu_ft(u_net,tensor_x2_train)-tensor_g2_train)**2)
        elif method == 'S':
            loss2 = loss2 + torch.sum(const_tensor_sn2_x2_train*(Bu_ft(u_net,tensor_x2_train)-tensor_g2_train)**2)
        loss2 = lambda_term/N_boundary_train*loss2
        loss = loss1 + loss2

        ## Update the network
        optimizer.zero_grad()
        loss.backward(retain_graph=False)
        optimizer.step()
            
    # Save loss and L2 error
    lossseq[k] = loss.item()
    if flag_l2error == True:
        l2error = sqrt(sum((u_net.predict(x_test) - u_x_test)**2)/x_test.shape[0])/u_l2norm_x_test
        l2errorseq[k] = l2error
    if flag_maxerror == True:
        maxerror = numpy.max(absolute(u_net.predict(x_test) -u_x_test))/u_maxnorm_x_test
        maxerrorseq[k] = maxerror
    resseq[k] = sqrt(1/N_inside_train*sum((Du(u_net,x1_train)-f(x1_train))**2))
    
    ## Show information
    if k%n_epoch_show_info==0:
        print("epoch = %d, loss = %2.6f" %(k,loss.item()), end='')
        if flag_l2error == True:
            print(", l2 error = %2.6e" % l2error, end='')
        if flag_maxerror == True:
            print(", max error = %2.6e" % maxerror, end='')
        print("\n")
            
    k = k + 1

# Save u_net
if flag_output_results == True:    
    localtime = time.localtime(time.time())
    time_text = str(localtime.tm_mon)+'_'+str(localtime.tm_mday)+'_'+str(localtime.tm_hour)+'_'+str(localtime.tm_min)
    torch.save(u_net.state_dict(),'networkpara_'+time_text+'.pkl')
    if method == 'S':
        torch.save(select_net1.state_dict(),'select_networkpara_'+time_text+'.pkl')

# Output results
if flag_output_results == True:    
    #save the data
    main_file_name = 'file_name'
    data = {'main_file_name':main_file_name,\
                                'ID':time_text,\
                                'N_inside_train':N_inside_train,\
                                'activation':activation,\
                                'd':d,\
                                'givenpts_l2errorseq':givenpts_l2errorseq,\
                                'givenpts_maxerrorseq':givenpts_maxerrorseq,\
                                'initial_constant':initial_constant ,\
                                'l2errorseq':l2errorseq,\
                                'lambda_term':lambda_term,\
                                'lossseq':lossseq,\
                                'lrseq':lrseq,\
                                'm':m,\
                                'method':method,\
                                'L':L,\
                                'maxerrorseq':maxerrorseq,\
                                'n_epoch':n_epoch,\
                                'n_update_each_batch':n_update_each_batch,\
                                'R':R,\
                                'resseq':resseq,\
                                'sphere_sampling_type':sphere_sampling_type,\
                                'TensorType':TensorType,\
                                'test_type':test_type,\
                                }
    if method == 'S':
        data['loss_sn1_threshold'] = loss_sn1_threshold
        data['loss_sn2_threshold'] = loss_sn2_threshold
        data['lr_sn'] = lr_sn
        data['m_sn'] = m_sn
        data['maxvalue_sn'] = maxvalue_sn
        data['minvalue_sn'] = minvalue_sn
        data['n_update_each_batch_sn'] = n_update_each_batch_sn
        data['penalty_parameter'] = penalty_parameter
        data['selectnet_initial_constant'] = selectnet_initial_constant
    if flag_l2error == True:
        data['u_l2norm_x_test'] = u_l2norm_x_test
    if flag_maxerror == True:
        data['u_maxnorm_x_test'] = u_maxnorm_x_test

    filename = 'result_d_'+str(d)+'_'+time_text+'.data'
    file = open(filename, 'wb')
    pickle.dump(data, file)
    file.close()
    

# empty the GPU memory
torch.cuda.empty_cache()
