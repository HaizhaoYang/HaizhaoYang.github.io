These are the python codes for implementing the SelectNet residual model to solve partial differential equations (time dependent or independent). The PyTorch package and CUDA Toolkit 10.0 are rquired.

Included files:
main.py: the main script file to run the model
network_*.py: the file to define a *-layer network structure for the solutions of time-independent problems(* can be 2,3 or 7)
network_*_time_dependent.py: the file to define a *-layer network structure for the solutions of time-dependent problems(* can be 2,3 or 7)
selection_network_setting.py: the file to define the structure for the selection network
useful_tools.py: the file to define some useful functions needed for implementing the model
solution_Poisson_poly.py: the file define a Poisson problem with its solution being a polynomial
solution_heat_poly.py: the file define a heat problem with its solution being a polynomial
solution_wave_poly.py: the file define a wave problem with its solution being a polynomial

Note:
for main.py
1. In Line 10, use 
"import network_* as network_file" for time-independent problems;
"import network_*_time_dependent as network_file" for time-dependent problems.
* can be 2,3 or 7
(network_7 with ReLU3 activation may cause overflow if the domain boundary is larger than 1)

2. In Line 16, use
"from solution_Poisson_poly import..." for the demo of Poisson equation;
"from solution_heat_poly import..." for the demo of heat equation;
"from solution_wave_poly import..." for the demo of wave equation;


