# SelectNet
code repo for [SelectNet: Learning to Sample from the Wild for Imbalanced Data Training](https://arxiv.org/abs/1905.09872)

### Requirement
* Tensorflow >= 1.10
* Keras >= 2.2

### Usage
Run training.py to excute training

```
python training.py SelectNet --iteration 30 --model res32
```

