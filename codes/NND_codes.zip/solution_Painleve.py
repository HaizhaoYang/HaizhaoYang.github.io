# the solution is mulit-D sin function: u(x,t) = exp(-t)(x1^2-1)*(x2^2-1)*...*(xd^2-1)
import torch 
from numpy import array, prod, sum, zeros, exp, max, log, sqrt
from torch.nn.functional import relu
from torch.nn import Softplus

torch.set_default_tensor_type('torch.cuda.DoubleTensor')
h = 0.001
left = 0
right = 10
scale = 10

right_scaled = right/scale



# the point-wise Du: Input x is a sampling point of d variables ; Output is a numpy vector which means the result of Du(x))
def Du(model,x_batch):
    ei = zeros(x_batch.shape)
    ei[:,0] = 1
    s = (model.predict(x_batch+h*ei)-2*model.predict(x_batch)+model.predict(x_batch-h*ei))/h/h
    s = s - scale*scale*model.predict(x_batch)**2 + scale*scale*scale*x_batch[:,0]
    return s

# the point-wise Du: Input x is a batch of sampling points of d variables (tensor) ; Output is tensor vector which means the result of Du(x))
def Du_ft(model,tensor_x_batch):
    ei = torch.zeros(tensor_x_batch.shape)
    ei[:,0] = 1
    s = (model(tensor_x_batch+h*ei)-2*model(tensor_x_batch)+model(tensor_x_batch-h*ei))/h/h
    s = s - scale*scale*model(tensor_x_batch)**2 + scale*scale*scale*tensor_x_batch[:,0]
    return s

# define the right hand function for numpy array (N sampling points of d variables)
def f(x_batch):
    f = zeros((x_batch.shape[0],1))
    return f

# the point-wise Bu for tensor (N sampling points of d variables)
def Bu_ft(model,tensor_x_batch):
    return model(tensor_x_batch)

# define the boundary value g for numpy array (N sampling points of d variables)
def g(x_batch):
    g = zeros((x_batch.shape[0],))
    indices = x_batch[:,0]<left+0.001
    g[indices] = 0
    indices = x_batch[:,0]>right_scaled-0.001
    g[indices] = sqrt(right)
    return g


# the point-wise h0 numpy array (N sampling points of d variables)
def h0(x_batch):
    return None

# the point-wise h1 for numpy array (N sampling points of d variables)
def h1(x_batch):
    return None


# specify the domain type
def domain_shape():
    return 'cube'

# output the domain parameters
def domain_parameter(d):
    intervals = zeros((d,2))
    for i in range(d):
        intervals[i,:] = array([left,right_scaled])
    return intervals

# If this is a time-dependent problem
def time_dependent_type():
    return 'none'

# output the time interval
def time_interval():
    return None

